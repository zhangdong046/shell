1、所谓sql注入式攻击，就是攻击者把sql命令插入到web表单的输入域或页面请求的查询字符串中，欺骗服务器执行恶意的sql命令。
    1.1、在某些表单中，用户输入的内容直接用来构造（或者影响）动态sql命令，或作为存储过程的输入参数，这类表单易受到sql注入式攻击。
    1.2、解决方法：替换单引号（防止修改sql命令含义），删除用户输入内容中的所有连字符（防止供给制顺利获得访问权限），对于用来执行查询的数据库账户，限制其权限，用存储过程执行所有查询，检查用户输入的合法性，将用户登陆名称、密码等数据加密保存，检查提取数据的查询返回的记录数量。
2、select * from p where num<=all(select num from p);
   select * from p where num in (select num from p group by num having(count(num)>1));//这里可以在分组时仍然能统计出每一组的组内元素数量。
   
3、select * into B from A where 1 = 0;//只复制表结构
   select * into B from A;//拷贝表，带数据
4、select * from student as tmp where (select count(*) from study where studentid = tmp.studentid) between 2 and 3;//!
5、tcp端口：ftp-21,telnet-23,smtp-25,http-80;udp端口：dns-53,snmp(简单网络管理协议)-161，qq-8000/4000
6、ICMP是internet control message protocol,是tcp/ip协议族的一个子协议，用于在ip主机、路由器之间传递控制消息。控制消息是指网络通不通,主机是否可达，路由是否可用等网络本身的消息。
    6.1、ping和路由跟踪tracert命令都是icmp协议工作的过程。
    6.2、icmp协议对于网络安全具有重要意义，其非常容易被用于攻击网络上的路由器和主机。
    6.3、可以利用操作系统规定的icmp数据包最大尺寸不超过64kb这一规定，向主机发出死亡之ping。
    6.4、ping of death的原理是：如果icmp数据尺寸超过64kb上限，主机就会出现内存分配错误，导致tcp/ip堆栈崩溃，导致主机死机。
    6.5、此外，向目标主机长时间，连续，大量地发送icmp数据包，形成icmp风暴，使得目标主机耗费大量的cpu资源。
