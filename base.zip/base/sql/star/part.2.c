1、select A.sno from A,B where A.con = B.cno and B.cname = 'db';
2、select s.sno,s.sname from s,(select sc.sno from sc,c  where sc.cno = c.cno and c.cname in('math','english') group by sno having count(DISTINCT c.cno) = 2)x  where s.sno = x.sno;
3、select s.sno,s.sname,avg(sc.grade) as avggrade from s,sc,(select sno from sc where grade<60 group by sno having count(DISTINCT cno)>=2)x where s.sno = x.sno and sc.sno = x.sno group by s.sno;
4、select s.sname from s,(select sno,grade from sc where cno in (select cno from c where cname='math'))A,(select sno,grade from sc where cno in (select cno from c where cname = 'english'))B where s.sno = A.sno and s.sno = B.sno and A.grade >B.grade;
5、over(partition by...)
    5.1、统计各班成绩第一名的同学信息
        select * from (select name,class,mark,rank()over(partition by class order by mark desc)count from table) where count =1;
        5.1.1、在求第一名成绩的时候，不能用row_number(),因为如果同班有两个并列第一，row_number()只返回一个结果；
        5.1.2、rank()和dense_rank()的区别：
            5.1.2.1、rank()是跳跃排序，有两个第二名时接下来就是第四名；
            5.1.2.2、dense_rank()是连续排序，有两个第二名时仍然跟着第三名。
    5.2、分类统计（并显示信息）
        5.2.1、select a,c,sum(c)over(partition by a) from table;
    5.3、将B栏位值相同的对应的C栏位值加总
        5.3.1、select a,b,c,sum(C)over(partition by b)C_Sum from test;
    5.4、求个人工资占部门工资的百分比：
        5.4.1、select name.dept,sal,sal*100/sum(sal)over(partition by dept)percent from salary;
6、开窗函数指定了分析函数工作的数据窗口大小，这个数据窗口大小可能会随着行的变化而变化。
    6.1、over(order by salary) 按照salary排序进行累计，order by是个默认的开窗函数；
         over(partition by deptno) 按照部门分区
    6.2、over(order by salary range between 5 preceding and 5 following)
