CREATE TABLE Student
(Sno CHAR(9) PRIMARY KEY,
 Sname CHAR(20) UNIQUE,
 Ssex CHAR(2),
 Sage SMALLINT,
 Sdept CHAR(20)
);

DROP TABLE Student;

ALTER TABLE Student ADD S_entrance DATE;

ALTER TABLE Student MODIFY COLUMN Sage INT;
//增加Student表Sname必须取唯一值的约束条件
ALTER TABLE Student ADD UNIQUE(Sname);　

SELECT * FROM Student WHERE Sage BETWEEN 20 ADN 23;//between
SELECT * FROM Student WHERE Sname = 'Bill Gates';//=
SELECT * FROM Student WHERE Sname like '%bill%';//like
SELECT Sname,Ssex FROM Student WHERE Sdept IN('CS','IS','MA');//in
SELECT * FROM Student WHERE Sage IS NULL;//IS NULL

SELECT * FROM Student ORDER BY Sdept,Sage desc;
SELECT * FROM Student LIMIT 1 OFFSET 78;
SELECT * FROM Student LIMIT 75,-1;//检索记录行75-last。
SELECT Sage,count(*) from Student group by Sage having count(*) >1;

SELECT Student.*,SC.* FROM Student,SC WHERE Student.Sno = SC.Sno;
SELECT Student.*,SC.* FROM Student LEFT JOIN SC ON(Student.Sno=SC.sno);//左外连接列出左边表中的所有元组。

INSERT INTO tavle1(field1,field2...)VALUES(value1,value2...);
UPDATE table1 SET field1=value1,field2=value2 WHERE 范围
DELETE FROM table1 WHERE 范围

CREATE UNIQUE INDEX Stusno ON Student(Sno desc);
ALTER TABLE Student DROP INDEX Stusno;

select * from dblink('hostaddr=192.168.0.222 port=5432 dbname=db2 user=postgres password=postgres','select username from people') AS t(username texe);
1、select dblink_connect('connection','hostaddr=192.168.0.222 port=5432 dbname=db2 user=postges password=postgres');
2、select dblink_exec('connection','BEGIN');
3、select dblink_exec('connection','insert*');
4、select dblink_exec('connection','COMMIT');
5、select dblink_disconnect('connection');
