SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
DELIMITER /$

CREATE TABLE IF NOT EXISTS `teststable`(
    `name` varchar(10) DEFAULT NULL,
    `age` smallint(5) DEFAULT NULL,
    PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8/$

INSERT INTO `teststable` (`name`, `age`) VALUES
('云',29),
('清',24),
('海',25),
('天',24)/$

DROP PROCEDURE IF EXISTS PROC_WIFIS/$ 

/*第一个存储过程
OUT方式传入的names会变成null*/
CREATE PROCEDURE PROC_WIFIS( INOUT names varchar(10),INOUT ages smallint(5),OUT counter smallint)
BEGIN

/*if/else*/
    select names;
    select counter;

    IF (ages>25) THEN
        set ages=23;
    ELSEIF (ages<25) THEN
        set ages = ages+1;
    ELSE
        set ages =ages;
    END IF;
    
    set counter = 25;
    INSERT INTO teststable(name,age)VALUES(names,ages);
    SELECT * from teststable ORDER BY age DESC;

END/$

DROP PROCEDURE IF EXISTS PROC_SECOND/$

/*第二个存储过程*/
CREATE PROCEDURE PROC_SECOND( IN name2 varchar(10),IN age2 smallint(5),IN counter2 smallint)
    MODIFIES SQL DATA
BEGIN

/*declare 必须在其他语句之前*/
    declare done integer(1) DEFAULT 0;
    declare cur1 CURSOR FOR SELECT name,age from teststable;
    declare CONTINUE HANDLER FOR NOT FOUND SET done=1;
    select name2;
/*调用*/ 
    call PROC_WIFIS(name2,age2,counter2);

/*loop*/    
    simpleloop:LOOP
        set counter2=counter2-1;
        IF counter2 = 20 THEN
            LEAVE simpleloop;
        END IF;
    END LOOP simpleloop;

/*while*/    
    WHILE counter2 != 25 DO
        set counter2 = counter2+1;
    END WHILE;   

/*repeat*/    
    REPEAT
        set age2 = age2-1;
    UNTIL age2 = 10 END REPEAT;
    
/*CURSOR用于处理多行记录的查询结果*/
    OPEN cur1;
    secondloop:LOOP
        FETCH cur1 INTO name2,age2;
        
        if (age2>20) THEN
            SELECT * FROM teststable where age = age2;
            UPDATE teststable SET age=FUN_FIRST(age2) where age =age2;
            SELECT * from teststable where name = name2;
        end if;
        
        IF done=1 THEN
            LEAVE secondloop;
        END IF;
    END LOOP secondloop; 
    CLOSE cur1;

END/$

/*第一个存储方法*/
DROP FUNCTION IF EXISTS `FUN_FIRST`/$

CREATE FUNCTION `FUN_FIRST`(normals smallint(5))
    RETURNS smallint(5)
    DETERMINISTIC
BEGIN
    DECLARE normalsage smallint(5);
    if (normals >23) then
        set normalsage = normals-1;
    else
        set normalsage = normals+4;
    end if;
    RETURN (normalsage);
END/$

/*第一个触发器
DROP TRIGGER student_trigger/$
CREATE TRIGGER student_trigger
    BEFORE INSERT ON student
    FOR EACH ROW
BEGIN
    IF NEW.student_age<25 THEN
        SET NEW.flag = 'young';
    END IF;
END/$
*/

call PROC_SECOND("景",26,0)/$

DROP TABLE IF EXISTS `teststable`/$
DELIMITER ;
