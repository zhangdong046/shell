#!/bin/bash

HOSTNAME="127.0.0.1"
PORT="3306"
USERNAME="root"
PASSWORD="123"

DBNAME="test"
TBNAME="test_table"

#创建数据库
create_db_sql="create database IF NOT EXISTS ${DBNAME}"
mysql -h${HOSTNAME} -P${PORT} -u${USERNAME} -p${PASSWORD}  -e "${create_db_sql}"

#创建数据表
create_table_sql="create table IF NOT EXISTS ${TBNAME} (name varchar(10),age int(5) default 0)"
mysql -h${HOSTNAME} -P${PORT} -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${create_table_sql}"

#插入数据
insert_sql="insert into ${TBNAME} values('男1号',30)"
mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${insert_sql}"
insert_sql="insert into ${TBNAME} values('海',29)"
mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${insert_sql}"

mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD} ${DBNAME}<./example.sql

#查询
select_sql="select * from ${TBNAME}"
mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${select_sql}"

#删除数据
delete_sql="delete from ${TBNAME}"
drop_sql="drop database $DBNAME"

mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${delete_sql}"
mysql -h${HOSTNAME}   -P${PORT}   -u${USERNAME} -p${PASSWORD}  -e "${drop_sql}"

