#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//结构体和共用体（联合）都是由多个不同的数据类型成员组成，但是在任何同一时刻，共用体中只存放了一个被选中的成员，而结构体的所有成员都存在。
/*
union 共用体名{
    数据类型 成员名;
}变量名;
共用体的用途之一是当数据项使用两种或更多种格式（但不会同时使用）时，可节省空间。共用体占用内存为各成员中占用最大者内存。
*/
/*
共用体union的存放顺序是所有成员都从低地址开始存放（结构体成员也是从低地址开始存放）。
大端存储格式即字数据的高字节存储在低地址中，而字数据的低字节存放在高地址中。
0x4000  0x4001  0x4002  0x4003
0x12    0x34    0x56    0x78
小端存储格式中，低地址中存放的是字数据的低字节，高地址中存放字数据的高字节。
0x4000  0x4001  0x4002  0x4003
0x78    0x56    0x34    0x12
32bit宽的数0x12345678,小端方式和大端方式的区别是字中字节的存储顺序不同，而字与字之间的存储顺序是相同的。
我们常用的X86结构是小端模式。
*/
#define BIG_END 0
#define LITTLE_END 1
union Student{
    int i;
    unsigned char ch[2];
};
int TestByteOrder(){
    short int word = 0x0001;//2byte
    char* byte=(char*)&word;
    return (byte[0]?LITTLE_END:BIG_END);
}
int main(){
    union Student student;//
    student.i = 0x1420;//16进制
    printf("%d,%d\n",student.ch[0],student.ch[1]);//小端存储时候，输出结果：32 20
    if(TestByteOrder()) printf("这里是小端存储！");
    long long a=1,b=2,c=3;
    printf("%d %d %d\n",a,b,c);//函数参数是栈传递，printf函数是最后一个元素先入栈，c先入栈，然后b，a入栈。
/*
long long为8 字节，int为4字节，此时栈是：
 0x01000000 0x00000000 0x02000000 0x00000000 0x03000000 0x00000000//16进制，6处4个8位（4字节）共24字节
左侧为栈顶，右侧为栈底，输出时先输出栈顶，且仅输出4个字节，也就是1，0，2.
*/
    char array[12]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
    short *pshort = (short*)array;
    int* pint=(int*)array;
    long long *pint64=(long long*)array;
    printf("0x%x,0x%x,0x%x,0x%x",*pshort,*(pshort+2),*pint64,*(pint+2));//0x201,0x605,0x4030201,0x8070605！？
/*
小端系统，高字节存放在内存中的高地址处，元素是：0x/00000000/08070605/04030201,以字节为单位存储的。
问题发生在，如果按数据正常的大小范围去读取，就不会把字节内储存顺序一致，字节间储存顺序不一致的数据读错。
*/
    return 0;
}
