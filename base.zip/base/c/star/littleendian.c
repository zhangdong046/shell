#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
大端小端还会影响到位域成员的存放。定义的数据结构中包含bit位域，将以以下规则存放：
1、低字节都存放在地地址;
2、大端模式首先为字段的高bit位分配空间，小端模式首先为字段的低bit位分配空间；
3、大端模式首先存放地址的高bit位，小端模式首先存放地址的低bit位。
struct{
    short bit1:4;//假设bit1为a0a1a2a3
    short bit2:9;
    short bit3:3; 
};
大端模式下内存存放：
bit1(4位，顺序为a0a1a2a3) bit2(高4位) bit2(低5位) bit3(3位)
小端模式下内存存放：
bit2(低4位) bit1(4位，顺序为a3a2a1a0) bit3(3位) bit2(高5位)
*/
struct Test{
    unsigned short int a:5;
    unsigned short int b:5;
    unsigned short int c:6;
};
int main(void){
    struct Test test;
    test.a = 16;
    test.b = 4;
    test.c = 0;
    int i=*(short*)&test;
    printf("%d\n",i);
    return 0;
//0000 00(c)00 100(b)1 0000(a)
//内存中为1001 0000 0000 0000 字节间倒置
}
