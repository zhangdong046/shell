//c++语言通常通过char*/const char*类型的指针来操纵c语言中的风格字符串。
/*
const char* cp="some value";
while(*cp){//’\0‘会被转换为十进制的0输出，这是为什么可以使用while(*cp)的原因
    ++cp;//指针的算数操作，直到到达结束符null为止；
}
//printf语句在输出字符串时，将’\0‘当作字符串的结尾。printf("x=%s\n",p)//指针
*/
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>
int strcmp(const char* str1,const char* str2){
    assert(str1 != NULL&&str2 != NULL);
    int ret = 0;
    while(!(ret=*(unsigned char*)str1-*(unsigned char*)str2)&&*str1){//*(unsigned char*)
        str1++;
        str2++;
    }
    if(ret<0) ret=-1;
    else if(ret>0) ret =1;
    return ret;
}
char*strcpy(char*dest,const char*str){
    assert(dest != NULL&&str != NULL);//debug版本有断言保护，而在release中就会删掉断言。
    char* flag = dest;
    while((*dest++ = *str++)!='\0');
    return flag;
}//并没有指针索引溢出的判断，可能会覆盖不属于自己的内存。
const char* strFind(const char* str1,const char* substr1){//const
    assert(str1 != NULL&&substr1 != NULL);
    int m = strlen(str1);
    int n = strlen(substr1);
    if(m<n) return NULL;
    int i,j;
    for(i =0;i<m-n;i++){
        for(j=0;j<n;j++){
            if(str1[i+j] != substr1[j]) break;
        }
        if(j == n)
            return str1+i;//因为此处返回常指针，gcc要求函数返回值必须为const类型。
    }
    return NULL;
} 
int main(){
    char b[3]={0};//
    printf("%s\n",b);//b[][3]的时候b的类型才为int(*)[3]; 
    strcpy(b,"aa");
    printf("%s\n",b);
    int ret =strcmp(b,b);
    printf("%d\n",ret);
    const char* str1="1234567";
    const char* substr1="456";
    const char* tmp = strFind(str1,substr1);//const
    printf("%s\n",tmp);
    return 0;
}
//void* memcpy(void *dest,const void *src,size_t n);
//从源src所指的内存地址的起始位置开始拷贝n个字节到目标dest所指的内存地址的起始位置中，函数返回dest的指针。
//void *memset(void *s,int ch,size_t n);
