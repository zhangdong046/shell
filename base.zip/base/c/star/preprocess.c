#include<stdio.h>
#include<stdlib.h>
//提供条件编译措施使同一源程序可以根据不同编译条件（参数）产生不同的目标代码，其作用是便于调试和移植。
/*
#if/ifdef/ifndef
#elif
#else
#endif
文件包含需要引入多重包含的问题。
在编写头文件之前，我们需要引入一些额外的预处理器设施。为了避免冲突，预处理变量经常会用大写字母表示
预处理器变量有两种状态：已定义或未定义
*/
#ifndef SALESITEM_H
#define SALESITEM_H
//……
#endif
//在不同的文件中引用一个已经定义过的全局变量，可以用引用头文件的方式，也可以用extern关键字。
//如果用引用头文件方式来引用某个在头文件中声明的全局变量，若你把这个变量写错了,在编译期间会报错，
//如果你使用extern方式引用，犯了同样错误，那么在编译期间不会报错，而在连接期间报错。
/*
1、在语句的控制结构中定义的变量，仅在定义它们的块语句结束前有效。这种变量的作用域限制在语句体内。
    1.1、while(int i=get_num())
             cout<<i<<endl;
         i=0;//error
2、在一个函数内的复合语句中定义的变量只在复合语句中有效。
3、在同一个文件中，当局部变量屏蔽了全局变量，而又想使用全局变量时，有两种方法：
    3.1、一种是使用域操作符”::“,
    3.2、一种是使用”extern“.
*/
int count = 3;
int main(void){
    int i,sum,count = 2;
    for(i=0,sum=0;i<count;i+=2,count++){//l,注意，此处并非在控制结构中定义的变量，但是满足复合语句中定义的变量。
        static int count = 4;//只初始化一次//当static作用于局部变量时，其特点是只进行一次初始化且具有”记忆性“
        count++;//s
        if(i%2 == 0){
            extern int count;
            count++;//g//if语句中的count是main外部的count//extern int count 语句的作用。
            sum+=count;
        }
        sum+=count;//s
    }
    printf("%d %d\n",count,sum);//l
    return 0;
}
/*
类中使用static成员变量而不是全局变量的优点：
1、static成员的名字是在类的作用域中，因此可以避免与其他类的成员或者全局对象名字冲突。
2、可以实施封装。static成员可以是私有成员，而全局对象不可以。
3、通过阅读程序容易看出static成员与特定的类关联，这样可见性可清晰地显示程序员的意图。
*/
//c++中，因为常量在定义后就不能更改，所以定义时必须初始化//const int bufsize = 512;
//在全局作用域声明的const变量是定义该对象的文件的局部变量，此变量只存在于那个文件中，不能被其他文件访问。
//通过指定const变更为extern，就可以在整个程序中访问const对象。
/*
//file1.cpp
extern const int counter = 10;
//file2.cpp
extern const int counter;
for(int index=0;index != counter;++index){}
*/
