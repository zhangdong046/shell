#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
//函数除了返回值类型外，还可以返回指针。函数不能返回指向局部栈变量的指针，这是因为在函数返回后，他们是无效的，而且栈也被清理了。
//可返回的指针是指向堆分配的存储空间的指针或指向静态存储区的指针，在函数返回后它仍然有效。
//栈区（stack）由编译器自动分配释放，存放函数的参数值，局部变量的值等。其操作方式类似于数据结构中的栈，速度较快。
char *strcpy(char* strDest,const char* strSrc)
{
    assert((strDest != NULL)&&(strSrc != NULL));
    char* addr = strDest;
    while((*strDest++ = *strSrc++) != '\0');
    return addr;
}
size_t strlen(const char* s)
{
    assert(s != NULL);
    const char* sc;
    for(sc=s;*sc!='\0';++sc);//长度不计入‘\0’
    return (sc-s);
}
char* strcat(char* s1,const char* s2)
{
    assert((s1 != NULL)&&(s2 != NULL));
    char* addr=s1;
    while(*s1){
        s1++;
    }
    while(*s1++=*s2++);
    return addr;
}
int strcmp(const char* str1,const char* str2)
{
    assert(str1!=NULL&&str2!=NULL);
    int ret = 0;
    while(!(ret=*(unsigned char*)str1-*(unsigned char*)str2)&&*str1){
        str1++;
        str2++;
    }
    if(ret<0) ret=-1;
    else if(ret>0) ret=1;
    return ret;
}
void* memset(void *des,int ch,size_t n)
{
    assert(des != NULL);
    unsigned char *s=des;
    const unsigned char c=ch;
    //设置为unsigned,是因为可能会传来>127的数字
    while(n-->0)
        *s++=c;
    return des;
}
int main(){
//堆区，若程序员不释放，程序结束时由操作系统回收。分配方式似链表，一般速度比较慢，而且容易产生内存碎片。
//char* tmp = (char*)malloc(10);char* tmp =new char[10];（int * a = new int[n];动态声明一维数组，指针指向数组第一个元素。）
    char* tmp = (char*)malloc(10*sizeof(char));
    char* temp = (char*)malloc(10);
    static char p[] = "hello";//数组，非文字常量。但是是位于静态存储区的数组，指针可通过函数返回。
    strcpy(tmp,p);
    printf("%s\n",tmp);
    int length = strlen(tmp);
    printf("%d\n",length);
    memset(temp,'1',1*sizeof(int));//注意关于int ch和size_t n参数的使用。
    printf("%s\n",temp);
    tmp = strcat(tmp,temp);
    printf("%s\n",tmp);
    char* p1="hello1111";//不能使用名称p,previous definition of ‘p’ was here.
    int i = strcmp(tmp,p1);
    printf("%d\n",i);
    free(tmp);
    free(temp);
    return 0;
}
