#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//计算next数组
void get_nextval(char const* ptrn,int plen,int* nextval){
    int i = 0;
    nextval[i] = -1;
    int j= -1;
    while(i<plen-1){
        if(j == -1||ptrn[i] == ptrn[j]){//当j==-1时，后续不会再判断ptrn[-1]。
            ++i;
            ++j;
            if(ptrn[i] != ptrn[j])
                nextval[i] = j;
            else
                nextval[i] = nextval[j];
        }
        else
            j = nextval[j];//j被多次重置为-1，以满足上面j == -1.当且仅当满足ptrn[i]==ptrn[j]时，j++。
    }
}
/*
 abcdeabcdfh
-10000012340 //当j=4以后，j=a[4]//=0;j=a[0]/=-1.回归起点。
或
 00000123400
KMP算法每当一趟匹配过程中出现字符比较不等时，不需要回溯主串，而是利用已经得到的“部分匹配”结果模式
向右“滑动”尽可能远的一段距离后，继续进行比较，且此时不一定是拿模式串的第一位继续比较。此时复杂度为O（M+N）.
*/
int kmp_search(const char* src,int slen,const char* patn,int plen,const int* nextval,int pos){
    int i = pos, j=0;
    while(i < slen&&j < plen){
        printf("(i=%d:j=%d) ",i,j);
        if(j == -1|| src[i] == patn[j]){++i;++j;}
        else j = nextval[j];//next数组元素为0即是返回j=-1.
    }
    if(j >= plen)
        return i-plen;
    else
        return -1;
}
/*
在失配后，并不简单地从目标串的下一个字符开始新一轮的检查，而是依据在检测之前得到的有用信息，直接跳过不必要的检测。
前缀函数，next数组是由匹配串算出的！！！
*/
int main(){
    int nextval[12] ={0};
    int* tmp= (int*)malloc(100*sizeof(int));//stdlib.h
    memset(tmp,0,100*sizeof(int));//string.h
    char* p ="abcdeabcdefa";
    char* s ="abcdeabcdeabcdefa";
    get_nextval(p,12,nextval);
    int i;
    for (i=0;i<12;i++) printf("%d:",nextval[i]);
    printf("\n");
    int k=kmp_search(s,17,p,11,nextval,0);
    printf("\n%d",k);
    free(tmp);
    return 0;
}
