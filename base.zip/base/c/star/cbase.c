#include<stdio.h>
#include<stdlib.h>//g++中malloc需要引入该库文件
#include<iostream>
#include<string.h>
using namespace std;
/*c++定义了一组内置类型对象之间的标准转换，隐式类型转换发生在下列典型情况下
1、混合类型的算数表达式中；
2、用一种类型的表达式赋值给另一种类型的对象；
3、把一个表达式传递给一个函数，调用表达式的类型与形式参数的类型不相同；
4、从一个函数返回一个表达式的类型于返回类型不相同；
    4.1、为防止精度丢失，必要时，类型总是被提升为较宽的类型；
    4.2、所有含有小于整型的有序类型的算数表达式在计算之前其类型都会被转换为整型，在进行整值提升时类型char,signed char,unsigned char和short int都被提升为类型int。
*/
#define SECONDS_PER_YEAR (60*60*24*365)UL//UL表示无符号长整数，预处理器将为你计算常数表达式的值。
#define MIN(A,B) ((A)<=(B)?(A):(B))//括号的使用
struct testa{
    short a1;
    short a2;
    short a3;
}A;

struct testb{
    long a1;
    short a2;
}B;

/*
1、sizeof操作符的一个主要用途是与存储分配和I/O系统那样的例程进行通信；
    1.1、void* malloc（size_t size）;
    1.2、size_t fread(void* ptr,size_t size,size_t nmemb,FILE* stream)
2、用它可以看看某种类型的对象在内存中所占的单元字节。
    2.1、void* memset(void* s,int c,sizeof(s));
3、在动态分配一对象时，可以让系统知道要分配多少内存。
4、便于一些类型的扩充，在windows中有很多结构类就有一个专用的字段用来存放该类型的字节大小。
5、由于操作数的字节数在实现时可能发生变化，建议在涉及操作数字节大小时用sizeof代替常量计算。
6、如果操作数是函数中数组形参或者函数类型的形参，sizeof给出其指针大小。
*/
void func1(){
    cout<<sizeof(A)<<"A:6 ";
    cout<<sizeof(B)<<"B:8 ";
//gcc和g++中文字常量需要这样使用
    const char* ss1 = "0123456789";//deprecated conversion from string constant to ‘char*’ //char* 背后的含义是：给我个字符串，我要修改它，但是字符串常量是不能修改的。
    cout<<sizeof(ss1)<<"ss1:4 ";
    char ss2[] = "0123456789";
    cout<<sizeof(ss2)<<"ss2:11 ";//数组名作为参数传递时，退化为同类型的指针。但是sizeof为运算符，会计算整个对象的内存空间（完整个指针序列，且包含‘\0’）。
    char ss3[100] = "0123456789";
    cout<<sizeof(ss3)<<"ss3:100 ";//注意与strlen的区别。
    char q2[] = "a\n";
    cout<<sizeof(q2)<<"q2:3 ";
    void* str1 = (void*)malloc(100);
    cout<<sizeof(str1)<<"str1:4 ";
    free(str1);
}
/*
1、sizeof操作符的结果类型是size_t,它在头文件中的typedef为unsigned int类型，该类型保证能容纳实现所建立的最大对象的字节大小；
2、sizeof是运算符，strlen是函数；
3、sizeof可以用类型做参数，strlen只能用char*做参数，且必须是以‘\0'结尾的，//short f();printf("%d\n",sizeof(f()));
4、数组做sizeof的参数不退化，传递给strlen就退化为指针；
5、大部分编译程序在编译的时候就把sizeof计算过了，是类型或是变量的长度，这就是sizeof(x)可以用来定义数组维数的原因；
6、strlen的结果要在运行的时候才能计算出来，用来计算字符串的长度，而不是类型所占内存的大小。
7、sizeof后面如果是类型必须加括号，如果是变量名可以不加括号。这是因为sizeof是个操作符而不是个函数；
8、当使用一个结构体类型或变量时，sizeof返回实际的大小。当使用一组静态的空间数组时，sizeof返回全部数组的尺寸。sizeof不能返回被动态分配的数组或外部的数组尺寸。
9、在c++中传递数组永远都是传递指向数组元素的指针，编译器不知道数组的大小。
    9.1、如果想知道数组的大小，进入函数后用memecpy将数组复制出来，长度由另一个形参传进去。
    9.2、fun (unsigned char *p1,int len){unsigned char* buf = new unsigned char[len+1];memcpy(buf,p1,len);}
10、sizeof操作符不能用于函数类型，不完全类型或位字段。
    10.1、不完全类型是指具有未知存储大小数据的数据类型，如未知存储大小的数组类型、未知内容的结构或联合类型，void类型等。
*/

/*
1、sizeof的计算发生在编译时刻，所以它可以被当作常量表达式使用，且会忽略其括号内各种运算，如"sizeof(a++)"中++不执行。
    1.1、sizeof可以对一个表达式求值，编译器根据表达式的最终结果类型来确定大小，一般不会对表达式进行计算。
    1.2、sizeof也可以对一个函数调用求值，其结果是函数返回类型的大小，函数并不会被调用。
2、变量名可以不用括号括住，数据类型必须用括号括住。
3、函数，不能确定类型的表达式以及位域（bit-field）成员不能被计算sizeof值。
    3.1、int foo(){return 1;};sizeof(foo);//函数名称不能被计算sizeof值。
    3.2、void foo2(){}sizeof(foo2());//返回类型为void，不能确定类型的表达式不能被计算sizeof值。
    3.3、struct S{
                     unsigned int f1:1;
                     unsigned int f2:5;
                     unsigned int f3:12;
                 };
        sizeof(S.f1);//位域成员不能计算sizeof值。
4、sizeof("\0")=2.
*/
int main(){
    func1();
    return 0;
}
/*
含位域结构体的空间计算：
1、如果相邻位域字段的类型相同，且其位宽之和小于类型的sizeof大小，则后面的字段将紧接着前一个字段存储，直到不能容纳为止。
    1.1、在vs环境中，一个int a:4,如果后面不是位域，则占用4个字节；
    1.2、而在linux+gcc编译环境下，不论位域为何类型，所占字节数以其实际占用字节数为准，int a:4;仅占1个字节；
2、如果相邻位域字段的类型相同，但其位宽之和大于类型的sizeof大小，则后面的字段将从新的存储单元开始，其偏移量为其类型大小的整数倍；
3、若相邻的位域字段的类型不同，则各编译器的具体实现有差异，vc6采取不压缩方式，Dev-c++与gcc采取压缩方式；
4、如果位域字段之间穿插着非位域字段，则不进行压缩；
5、整个结构体的总大小为最宽基本类型成员大小的整数倍。
struct b{
    char f1:3;//1+1
    short f2:4;//2
    char f3:5;//1+1
};//在vc/vs中其sizeof为6，在Dev-C++/gcc中为2.
//short2;float4.使用伪指令#pragma pack(n),编译器将按照n个字节对齐；使用伪指令#pragma pack(),取消自定义字节对齐方式。
*/
