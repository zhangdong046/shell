//c++的struct具有很多class的功能，但也有一个不同点：
//class的成员访问权限默认为private,而struct成员的访问权限默认为public.
//struct可以有继承，可以有无参数构造函数，其成员变量可以不为public.
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
/*
1、结构体类型定义中不允许对结构体本身的递归定义。但可以使用指针指向本类型。
    1.1、struct person{
             类型名1 成员名1;
             类型名2 成员名2;
             struct person *per;
         };
2、结构体定义中可以包含另外的结构体，即结构体是可以嵌套的。
3、结构体变量可以在定义时进行初始化赋值。
    3.1、struct person{
             char name[20];
             char sex;
         }boy1={"zhangbing",'M'};
    3.2、在结构体变量初始化时，应将各成员所赋初值依照结构体类型说明中成员的顺序依次放在一对大括号中。
    3.3、不允许跳过前面的成员给后面的成员赋值，但可以只给前面若干成员赋初值，后面未赋值的成员中，数值型和字符型的数据，系统自动赋值0.
*/
typedef struct test
{
    int m;
    struct test* p;
}Tes;
struct st{
    int n;
    struct st *next;
};
//结构体中的位字段
struct bs{
    unsigned a:1;
    unsigned b:3;
    unsigned c:4;
}bit,*pbit;
/*
c和c++允许指定占用特定位数的结构成员，且可以使用没有名称的字段来提供间距，每个字段都被称为位字段（bit field）.
*/
int main(){
    Tes s={1,&s};
    printf("%d\n",s.m);
    static struct st a[3] = {1,&a[1],2,&a[2],3,&a[0]},*p;
    p = &a[2];
    printf("%d\n",++(p->next->n));
    bit.a = 1;
    bit.b = 7;
    bit.c = 15;//赋值不能超过该位域的允许范围，超过时，仅将等号右侧的低位赋值给位域。
    pbit = &bit;
    pbit->a = 0;
    pbit->b&=3;
    pbit->c|=1;
    printf("%d,%d,%d\n",pbit->a,bit.b,pbit->c);
    return 0;
}
/*
typedef在计算机编程中为复杂的声明定义简单的别名，与宏定义有些差异，它本身是一种存储类的关键字，
与auto\extern\mutable\static\register等关键字不能出现在同一个表达式中。
在编程中使用typedef目的一般只有两个，一个是给变量一个易记且意义明确的新名字，另一个是简化一些比较复杂的类型声明。
typedef struct tagMystruct
{
    int num;
    long length;
}MyStruct;
这个语句实际上完成两个操作：
    1、定义一个新的结构体类型
        struct tagMyStruct
        {
            int num;
            long length;
        };
        1.1、tagMyStruct实际上是一个临时名字，struct关键字和tagMyStruct一起，构成了这个结构类型，不论是否有typedef,这个结构都存在。
        1.2、我们可以用struct tagMyStruct varName来定义变量，但是要注意，使用tagMyStruct varName来定义变量是不对的，因为struct和tagMyStruct合在一起才能表示一个结构类型。
    2、typedef为这个新的结构起了一个名字，叫做MyStruct: typedef struct tagMyStruct MyStruct;
        2.2:因此，MyStruct实际上相当于struct tagMyStruct,我们可以用MyStruct varName来定义变量。
typedef struct tagNode
{
    char* pItem;
    struct tagNode* pNext;
}*pNode;
struct tagNode
{
    char* pItem;
    struct tagNode* pNext;
};
typedef struct tagNode* pNode;
*/
