/*如何实现位操作求两个数的平均值*/
/*
1、(x&y)+((x^y)>>1)
2、取x,y中对应位都为1的位，并将结果的对应位置1，相当于取得了都为1的位相加的一半。
3、x^y,即取x，y中对应位只有一个为1的位，并将结果对应位置1，由于最终结果是平均值，故除以2（用右移一位实现）。
4、以上两部分结果相加可得到两数的平均值。
*/
/*
一个整型数组里除了两个数字之外，其他的数字都出现了两次。请写程序找出这两个只出现一次的数字。要求时间复杂度O(n),空间复杂度O(1).
*/
/*
1、我们从头到尾一次异或数组中的每一个数字，那么最终得到的结果就是两个只出现一次数字的异或结果。由于这两个数字肯定不一样，那么这个异或结果肯定不为0，也就是说在这个结果数字的二进制表示中至少就有一位1.
2、我们在结果数字中找到第一个为1的位置，记为第N位，现在我们以第N位是不是1为标准把原数组中的数字分为两个子数组，第一个子数组中每个数字的第N位都为1，而第二个子数组的每个数字的第N位都为0.
*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;

//寻找num的二进制中第一位为1的序号
unsigned int FindFirstBitIs1(int num){
    int indexBit=0;
    while(((num&1)==0)&&(indexBit<32)){//这两个条件
        num=num>>1;
        ++indexBit;
    }
    return indexBit;
}
//判断num中第indexBit是否为1
bool IsBit1(int num,unsigned int indexBit){
    num=num>>indexBit;
    return (num&1);//bool    
}

void FindNumsAppearOnce(int data[],int length,int &num1,int &num2){
    if(length<2)
        return;
    int resultExclusiveOR = 0;
    for(int i=0;i<length;++i)
        resultExclusiveOR^=data[i];
    unsigned int indexof1=FindFirstBitIs1(resultExclusiveOR);//这里为什么使用unsigned int,是为了保证正数吗？
    num1=num2=0;
    for(int j=0;j<length;++j){
        if(IsBit1(data[j],indexof1))
            num1^=data[j];
        else
            num2^=data[j];
    }
}
int main(){
    int num1,num2;
    int *data = new int[10];//不能使用int data[] = new int[10];
    data[0]=4,data[1]=1,data[2]=2,data[3]=3,data[4]=4,data[5]=5,data[6]=6,data[7]=1,data[8]=2,data[9]=3;//data[10]={1,2,3,4,5,6,3,2,1,4};定义时候可以这样，定义后data[10]代表越界之外的一个元素
    int length =10;
    FindNumsAppearOnce(data,10,num1,num2);
    cout<<num1<<":"<<num2<<endl;
    delete []data;
    return 0;    
}
