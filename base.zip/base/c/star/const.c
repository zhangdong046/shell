#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//const 最有威力的用法是面对函数声明时的应用，在一个函数声明式内，const可以和函数返回值各参数，函数自身（如果是成员函数）产生关联。
/*
若返回值是值类型（非指针，引用类型），则对于内部数据类型来说，返回值是否是常量并没有关系。
const修饰返回值常用在处理用户定义的类型时，当处理用户定义的类型时，返回值不为常量有时会对用户造成困扰。
*/

/*
函数除了返回值类型外，还可以返回指针。函数不能返回指向局部变量的指针，这是因为在函数返回后，它们是无效的，而且栈也被清理了。
可返回的指针式指向堆中分配的存储空间的指针或指向静态存储区的指针，在函数返回后它仍然有效。
char* GetMemory(void){
    char p[] = "hello world";
    return p;    
}
void Test(void){
    char *str=NULL;
    str=GetMemory();
    printf(str);//结果可能是乱码，其内存分配在栈上，故GetMemory返回的是指向”栈内存“的指针，该指针的地址不是NULL，但其原来的内容已被清除，新内容不可知。
}
*/
char* GetMemory1(void){
    static char p[] = "hello world";
    return p;//数组位于静态存储区，可通过函数返回
}
const char* GetMemory2(void){//为防止程序对文字常量区的内容试图做修改，造成运行时崩溃。
    char* p="hello world";//g++中这里必须改成const指针
    return p;//p是指向全局（静态）存储区的指针，可通过函数返回
}
char* GetMemory(void){
    char* p=(char*)malloc(12);
    if(p == NULL)
        return NULL;
    else
        p="hello world";
    return p;//p是指向堆中分配存储空间的指针，可通过函数返回，但需要以后调用delete[]释放内存，否则易内存泄漏
}
/*
若是传地址，则无论任何时候传递一个地址给一个函数，我们都应该尽可能=用const修饰它（除非此参数确实需要在函数内修改），如果不这样做，就使得指向const的指针不能做实参。
int fun(int* i);
const int a =1;
fun(&a);//const int*类型的实参与int*类型的形参不兼容。
但若声明为int fun(const int*i);则int*类型与const int *类型的实参都可被接受。
在函数参数中使用常量引用特别重要。
void f(int &i){}
f(1);//编译错误，因为编译器必须首先建立一个引用。为一个int类型分派临时存储单元，同时将其初始化为1并为其产生一个地址和引用捆绑在一起，存储的内容是常量。
故实参是const int类型，而形参非const引用。
string f();
string g(string &str);
g(f());//在gcc下错误，在vs下正确，关键区别点在于gcc下临时变量都作为常量，常量不能传递给一个非常量引用，但在vs下做了优化。
*/
int main(){
    char* p1=GetMemory1();
    const char* p2=GetMemory2();
    char* p3=GetMemory();
    printf("%s\n%s\n%s\n",p1,p2,p3);
    //free(p3);//Segmentation fault,文字常量怎么可以free?
    return 0;
}
//void *realloc(void *ptr,size_t size);函数将ptr对象的储存空间改变为给定的大小size.参数size可以是任意大小，大于或小于原尺寸都可以。
//返回值是指向新空间的指针，如果发生错误返回NULL。
