/*
GCC/G++编译选项：
1、-c 只进行预处理、编译和汇编，生成.o文件；
2、-S 只进行预处理和编译，生成.s文件；
3、-E 只进行预处理，产生预处理的结果到标准输出；
4、-C 预处理时不删除注释信息，常与-E同时使用
5、-o 指定目标名称，常与-c,-S同时使用，默认为.out
6、-include file 插入一个文件，功能等同源代码中的#include
7、-Idir 优先在选项后目录中查找包含的头文件
8、-Ldir 指定编译搜索库的路径；
9、-g 编译器编译时加入debug信息。
10、-share/static 使用（禁止使用）动态库
*/
常用的GDB调试命令：
gcc -g -o helloword helloworld.c
gdb helloworld
break 5
run
print c
next
print c
continue
1、file<文件名> 在GDB中打开执行文件；
2、break 设置断点，支持的形式有break行号、break函数名称、break行号/函数名称 if 条件
3、info 查看和可执行程序相关的各种信息
4、kill 终止正在调试的程序
5、print 显示变量或表达式的值
6、set args 设置调试程序的运行参数
7、delete 删除设置的某个断点或观测点
8、clear 删除设置在指定行号或函数上的断点
9、continue 从断点处继续执行程序
10、list 列出GDB中打开的可执行文件代码
11、watch 在程序中设置观测点
12、run 运行打开的可执行文件
13、next 单步执行程序
14、step 进入所调用的函数内部，查看执行情况。
15、whatis 查看变量或函数类型，调用格式为“whatis 变量名/函数名”
16、ptype 显示数据结构定义成矿
17、make 编译程序
18、quit 推出GDB.
