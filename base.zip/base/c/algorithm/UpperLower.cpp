#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

bool isUpper(char a){
    if(a>='A'&&a<='Z')
        return true;
    return false;
}

bool isLower(char a){
    if(a>='a'&&a<='z')
        return true;
    return false;
}

void Partition(char A[],int low,int high){
    while(low<high){
        while(low<high&&isUpper(A[high])) --high;//A[low] = A[high]
        while(low<high&&isLower(A[low]))  ++low;//A[high] = A[low]
        char temp = A[high];
        A[high] = A[low];
        A[low] = temp;//A[low] = pivot; return low;
    }
}
//排序后所有0元素在前，非零元素在后，且非零元素排序前后相对位置不变，不能使用额外存储空间
void Partition2(int A[],int p,int r){
    int j,i=r+1;
    for(j=r;j>=p;--j){
        if(A[j]!=0){
            --i;//为什么我会想那么复杂。。。
            int temp = A[i];
            A[i] = A[j];
            A[j] = temp;//每一次，被换向前方的一定只会是0.
        }
    }
}
int main(){
    char a[8] = {'a','A','z','d','B','s','b','\0'};
    Partition(a,0,6);
    printf(a);
    cout<<endl;
    int b[7] = {0,3,0,2,1,0,0};
    Partition2(b,0,6);
    int i;
    for(i=0;i<7;i++) cout<<b[i];
    cout<<endl;
    return 0;
}
