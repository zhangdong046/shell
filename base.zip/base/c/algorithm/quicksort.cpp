/*求最小的k个数
1、这道题最简单的思路是把输入的n个整数排序，这样排在最前面的k个数就是最小的k个数，只是这种思路时间复杂度为O(nlogn).
2、使用块排的一次排序方法可以在O(n)时间内完成，不过这种递归的解法找到的k个数不一定是有序的。
*/
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;

int swap(int& a,int& b){
    int tmp =a;
    a=b;
    b=tmp;
}

int Partition1(int A[],int p,int r){
    int x = A[r];//以最后一个元素，A[r]为主元。
    int i = p-1;
    for(int j = p;j<=r-1;++j){
        if(A[j]<=x){
            ++i;
            swap(A[i],A[j]);
        }
    }
    swap(A[i+1],A[r]);
    return i+1;
    
}

int Partition(int A[],int low,int high){
    int pivot=A[low];
    while(low<high){
        while(low<high&&A[high]>=pivot) --high;
        A[low]=A[high];
        while(low<high&&A[low]<=pivot) ++low;
        A[high]=A[low];
    }
    A[low] = pivot;
    return low;
}

int getLeastNum(int* input,int n,int* output,int k){
    if(input == NULL||output == NULL ||k>n ||n<=0||k<=0)
        return 0;
    int start =0;
    int end = n-1;
    int index = Partition(input,start,end);//一次划分函数
    while(index!=k-1){
        if(index>k-1){
            end = index-1;
            index=Partition(input,start,end);
        }else{
            start = index+1;
            index=Partition(input,start,end);
        }
    }
    for(int i=0;i<k;++i){
        output[i] = input[i];
        cout<<output[i];
    }
    return 1;
}

int main(){
    int input[8]={5,3,8,1,9,4,7,2};
    int *output = new int[4];
    getLeastNum(input,8,output,4);
    delete []output;
    return 0;
}
