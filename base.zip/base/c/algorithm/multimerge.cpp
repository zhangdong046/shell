/*
1、外部排序常用的方法是多路归并排序，将原文件分解成多个能够一次性装入内存的部分，分别把每一部分调入内存完成排序。然后对已排序的子文件进行归并排序。
2、从二路到多路（k路），增大k可以减少外存信息读取时间，但是k个归并段中选取最小的记录需要比较k-1次，为了降低选出每个记录需要的比较次数k，引出了”败者树“的概念。
3、败者树是对树形选择排序的一种变形，可以视为一颗完全二叉树。，每个叶节点存放各归并段在归并过程中当前参加比较的记录，内部结点用来记忆左右子树中的“失败者”，而让胜利者往上继续进行比较，一直到根节点。如果比较两个数，大的为失败者，小的为胜利者，则根节点指向的数为最小数。
4、因为k路归并的败者树深度为【log2K】向上取整，因此k个记录中选择最小关键字，最多需要深度次比较，显然比依次比较k-1次小得多。
*/
//有20个有序数组，每个数组有500个unsigned int 元素，降序排序。要求从这10000个元素中选出最大的500个。
/*
1、显然，若以此从20个有序数组选择一个当前元素，两两比较，然后找出最大的数，循环500次即可选出500个最大的数。但是这里每选择一个最大元素，就需要比较19次，效率不高。
2、改进方法，利用堆，从20个数组中各取一个元素，并记录每个数的来源数组，建立一个含有20个元素的大根堆。此时堆顶就是最大的数，取出堆顶元素，并从堆顶元素的来源数组中取下一个数入堆，调整堆后再取最大值，一直这样进行500次，时间复杂度为O(n*log2K),其中n为要选出的元素个数，k为有序数组个数。
为了能标记元素的来源，需要将每个元素包装成以下这样子，其中source表示元素的来源：
struct ElemType{
    unsigned int value;
    int source;
}
*/
//3、利用败者树，从20个数组中各取一个数，并记录每个数的来源数组，建立一个20路归并的败者树。此时败者树输出的就是最大的数，然后从最大的数来源的数组中继续取下一个数加入败者树，继续比较，直至输出500个数为止。时间复杂度为O(nlog2k),n为要选出的元素个数，k为有序数组的个数。
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;

const int branchesLength = 20;//共有20路数组
/*20个一维数组，每个数组有500个元素，为叶子结点提供数据，本题中仅给出了测试用的40个元素，例程中输出了最大的前10个元素，结果正确*/
int branches[branchesLength][500]={{1000,900},{999,888},{1001,990},{887,877},{987,978},{1001,901},{992,883},{1005,992},{887,877},{987,978},{1002,902},{993,884},{1007,991},{887,877},{987,978},{1003,903},{994,882},{989,900},{887,877},{987,978}};
/*败者树的叶子结点，记录数据源的索引位置，根据结点的值可以定位到所指向的数据源*/
int tree[branchesLength];
/*败者树的叶子结点，叶子结点和数据源是一一对应的，即第一个叶子结点记录第一个数据源的当前数据*/
int nodes[branchesLength];
/*nodes_iterator[i]记录第i路数组当前已取到第几个元素*/
int nodes_iterator[branchesLength]={0};
/*设置第index个叶子结点的下一个数据*/
void put(int index){
    nodes[index] = branches[index][nodes_iterator[index]++];
}
/*获取第index个叶子结点当前数据*/
int get(int index){
    return nodes[index];
}
/*调整第index个叶子结点，具体调整过程为：叶子结点和父结点比较，败者留在父节点位置，胜者继续和父节点的父节点比较，直到整棵树的根节点*/
void adjust(int index){
    int size=branchesLength;
    int t=(size+index)/2;//计算父节点
    while(t>0){
        if(get(tree[t])>get(index)){//败者留在父节点位置？
            int temp = tree[t];
            tree[t] = index;//非叶子节点只负责存储叶子结点的序号！！
            index = temp;
         }//index负责存储最大元素，每次while循环更新一次
         t/=2;
    }
    tree[0]=index;
}
vector<int> merge(){//依次读取数据源的数据进行归并排序，返回排序后的数据列表
    vector<int> list1;//记录排好序的数据
    int top;
    int i=0;
    while(i<10){//仅输出10个供测试
        top = tree[0];
        list1.push_back(top);
        i++;
        put(tree[0]);//一旦输出了根节点元素，那么根节点中存储的序号信息指向也自动变成了该路的下一个元素
        adjust(tree[0]);
    }
    return list1;
}
void init(){//初始化构建败者树
    int size=branchesLength;
    for(int i=0;i<size;i++){
        put(i);
    }
    int winner = 0;
    for(int i=1;i<size;i++){
        if(get(i)>get(winner)){
            winner=i; 
        }
    }
    for(int i=0;i<branchesLength;i++)//非叶子结点初始化为冠军结点
        tree[i]=winner;
    for(int i=size-1;i>=0;i--)//从后往前依次调整非叶子节点
        adjust(i);
}
int main(){
    init();
    vector<int> tmp = merge();
    vector<int>::iterator iter;
    cout<<"分支取数顺序：";
    for(iter = tmp.begin();iter!=tmp.end();iter++)
        cout<<*iter<<":";
    return 0;
}
