#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
int CallScore(int N,double* Score,int* Judge_type)
{
    int ret =0,n = 0,m = 0;
    double sum1 =0,sum2 = 0;
    if(N&&Score&&Judge_type){
        int i;
        for(i = 0;i<N;++i)
            switch(Judge_type[i]){
                case 0:sum1+=Score[i];++n;break;
                case 1:sum2+=Score[i];++m;break;
                default:;//舍弃不符合要求的数据
            }
        if(n != 0) 
            sum1=(int)(sum1/n);//gcc中必须给强制类型转换，int加上括号。
        if(m != 0) 
            sum2=(int)(sum2/m);
        ret = m?(int)(sum1*0.6 + sum2*0.4):sum1;
    }
    return ret;
}
int main(){
    int* Judge_type =(int*)malloc(10*sizeof(int));
    double* Score = (double*)malloc(10*sizeof(double));
    srand((unsigned)time(NULL));
    int i;
    //for(i=0;i<4;++i) Judge_type[i] = rand()%1;当此处设定为1的时候，只会产生0一个数
//k=x+rand()%(y-x+1)/*k即为[x,y]范围内随机生成的数，rand()%a的结果最大为a-1*/
    for(i=0;i<4;++i) Judge_type[i] = rand()%2;
    printf("%d%d%d%d\n",Judge_type[0],Judge_type[1],Judge_type[2],Judge_type[3]);
    int N =4;
    Score[0] = 87.5;
    Score[1] = 60.1;
    Score[2] = 99;
    Score[3] = 77.8;
    int ret = CallScore(N,Score,Judge_type);
    printf("%d\n",ret);
    free(Judge_type);
    free(Score);
    return 0;
}
