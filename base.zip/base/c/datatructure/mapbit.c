#include<stdio.h>
#include<stdlib.h>
#define BITWORD 32
#define SHIFT 5
#define MASK 0x1F//0x11111
#define N 10000000
int a[1+N/BITWORD] = {0};//
void set(int i){//将第i位设置为1，i>=0
    a[i>>SHIFT]|=(1<<(i&MASK));
}
void clr(int i){//将第i位设置为0
    a[i>>SHIFT]&=~(1<<(i&MASK));
}
int test(int i){
    return a[i>>SHIFT]&(1<<(i&MASK));
}
//当海量数据比较大时，位图法比较合适。
int main(){
    set(890104);
    int i=test(890104);
    clr(890104);
    int j=test(890104);
    printf("%d:%d\n",i,j);
    return 0;
}


