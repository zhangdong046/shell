#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<assert.h>
using namespace std;

void FirstNotRepeatingChar(const char* pString){
    assert(pString!=NULL);
    const int tableSize = 256;
    unsigned int hashTable[tableSize];//这里还可以使用局部常量
    for(unsigned int i=0;i<tableSize;++i)
        hashTable[i]=0;
    const char* pHashKey=pString;
    while(*(pHashKey)!='\0')
        hashTable[*(pHashKey++)]++;//ASCII字符是一个长度为8的数据类型总共有256种可能，每个字母根据其ASCII码值作为数组下标对应数组的对应项。
    pHashKey=pString;
    while(*pHashKey!='\0'){
        if(hashTable[*pHashKey]==1){
            printf("%c\n",*pHashKey);
            return;
         }
         pHashKey++;//在一个字符串中找到第一个只出现一次的字符。
    }
}
//删除字符串开始及末尾的空白符，并且把数组中间的多个空格符转化为1个。
void fun(char* s){
    int i=0,j=0;
    while(s[j]==' ')
        j++;
    int len=strlen(s)-1;//start
    while(s[len]==' ')
        len--;
    s[len+1]='\0';//end
    while(s[j]!='\0'){
        while(s[j]==' ')
            j++;
        //将中间连续的空白符变为1个，判断i！=0是为了防止将头部的连续字符变为1个
        if(s[j-1]==' '&&s[j-2]==' '&&i!=0)
            s[i++]=' ';//此间代码写的很牛逼
        s[i++]=s[j++];
    }
    s[i]='\0';
}
int main(){
    const char*p="abaccdeff";
    FirstNotRepeatingChar(p);
    char q[]={' ',' ','a',' ',' ','b','c',' ','\0'};//c字符串你竟然忘了写结尾符。
    fun(q);
    printf(q);
    return 0;
}
