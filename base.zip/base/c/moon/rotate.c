#include<stdio.h>
#define N 4
void rotate(int matrix[][N]){
    int layer;
    for(layer=0;layer<N/2;++layer){
        int first = layer;//first,last
        int last = N - 1 -layer;
        int i;
        for (i=first;i<last;++i)//gcc编译器中不能定义增量int i；必须先定义。
            {
                int offset=i - first;//offset
                int top = matrix[first][i];
                matrix[first][i] = matrix[last-offset][first];
                matrix[last-offset][first] = matrix[last][last -offset];
                matrix[last][last-offset] = matrix[i][last];
                matrix[i][last] = top;
            }
    }
}
int main(){
    int a[][4] ={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    rotate(a);
    printf("%d,%d,%d,%d",a[0][0],a[0][1],a[0][2],a[0][3]);
    return 0;
}
