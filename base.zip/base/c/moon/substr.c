#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
using namespace std;

enum Status {kValid=0,kInvalid};
int g_nStatus = kValid;
int StrToInt(const char* str){
    g_nStatus = kInvalid;
    long long num = 0;
    if(str != NULL){
        const char* digit = str;
        bool minus = false;
        if(*digit == '+')
            digit++;
        else if(*digit == '-'){
            digit++;
            minus=true;
        }
       while(*digit != '\0'){
           if(*digit >='0'&&*digit<='9'){//
               num = num*10+(*digit - '0');
               if(num > 9999999){
                   num=0;
                   break;
               }
               digit++;
           }
           else{
               num = 0;
               break;
           }
       }
       if(*digit == '\0'){
           g_nStatus = kValid;//
           if(minus)
               num = 0 -num;
       }
    }
    return num;
}

bool find(const char* const src,const char* const des){
    assert(src != NULL&&des != NULL);
    int lensrc = strlen(src);
    int lendes = strlen(des);
    if(lensrc < lendes)
        return false;
    int k,i,j;
    for(i=0;i<lensrc;++i){
        k=i;//
        for(int j=0;j<lendes;j++){
            if(src[k++%lensrc] != des[j])//
                break;
        }
        if(k-i == lendes)
            return true;
    } 
    return false;
}
int main(){
    const char* p = "-123456789";
    const char* q= "789-123";
    if(find(p,q)){
        //char* s;
        char* s =new char[10];
        printf("请输入要转换的字符串:\n");
        scanf("%s",s);//不能在char* s后这么使用！会出现越界错误。
        int k = StrToInt(s);
        printf("%d\n",k);
        delete []s;
    }
    return 0;
}

