#include<stdio.h>
int function(int data[],int length){
    int currentAxis;
    int currentNum = 0;
    int i;
    for(i=0;i<length;i++){
        if(currentNum ==0){
            currentAxis=data[i];
            currentNum=1;
        }else{
            if(currentAxis == data[i]) currentNum++;
            else currentNum--;
        }
    }
    return currentAxis;
}
void main(){
    int data[]={0,1,2,1,1};
    int axis=function(data,5);
    printf("%d\n",axis);
}
