#include<stdio.h>
/*
具有线性复杂度，且不能使用除法运算符。
*/
int* cal(int* input, int n)
{
    int i;
    int* result=new int[n];
    result[0] = 1;
    for(i =1;i<n;++i)
    {
        result[i] = result[i-1]*input[i-1];
    } 
    result[0] = input[n-1];//result[0]的三处使用
    for(i=n-2;i>0;--i){
        result[i]*=result[0];//
        result[0]*=input[i];//
    }
    return result;
}
int main(){
    int input[4]={2,3,4,5};
    int* p=cal(input,4);
    printf("%d,%d,%d,%d",p[0],p[1],p[2],p[3]);
    return 0;
}
