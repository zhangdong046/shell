/*
如果f()从没有执行delete语句（因为过早的return或者在函数体内部抛出了异常），动态分配的对象将没有被delete，
一个典型的内存泄漏。
void f(){
    T* pt(new T);
    //more code
    delete pt;
}
使其安全的一个简单方法是用一个“灵巧”的类指针对象包容这个指针，在其析构时自动删除此指针。
void f(){
    auto ptr<T> pt(new T);
   //more code 因为pt的析构函数总是在退栈过程中被调用。
}
*/
/*
auto_ptr可以被用来安全地包容指针：
class C{
    public:
        C();
    private:
        auto_ptr<CImpl> pimpl;
};
C::C():pimpl(new CTmpl){}
析构函数不再需要删除pimpl指针，因为auto_ptr将自动处理它。
把auto_ptr放入container是不安全的，因为auto_ptr之间的拷贝是不等价的。当auto_ptr被拷贝时，原来的那一份会被删除。
class Object
{
public:
    virtual ~Object(){}
};
A\std::auto_ptr<Object> pObj(new Object);
E\std::auto_ptr<Object> source(){return new Object;}
*/

/*
1、this指针本质是一个函数参数，只是编译器隐藏起形式的，语法层面上的参数。
    1.1、this只能在成员函数中使用，全局函数、静态函数都不能使用this.
    1.2、成员函数默认第一个参数为T* const this.
2、this在成员函数的开始前构造，在成员的结束后清除。生命周期与普通函数参数一样。
    2.1、A a;a.func(10);//此处，编译器会编译成A::func(&a,10);
    2.2、看起来与静态函数没差别，但是编译器通常会对this指针做一些优化，因此，this指针的传递效率比较高，如vc通常是通过ecx寄存器传递this参数的。
3、this指针并不占用对向的空间。
    3.1、所有成员函数的参数，不管是不是隐含的，都不会占用对向的空间，只会占用参数传递时的栈空间，或者直接占用一个寄存器。
4、this指针可能存放在堆，栈，也可能存放在寄存器。
    4.1、this是个指向对象的“常指针”，所有对象共用的成员函数利用这个指针区别不同的变量，this是“不同对象共享相同成员函数”的保证。
    4.2、实际应用中，this应该是个寄存器参数。c风格约定，参数自右向左入栈，由调用方负责平衡堆栈。
    4.3、大多数编译器通过ecx寄存器传递this指针。
5、this指针只有在成员函数中才有定义，你不能直接通过对象使用this指针。
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<assert.h>
int main(){
    char* num1;
    char* num2;
    int* sum;
    int len_max,len_min;
    num1=(char*)malloc(100*sizeof(char));//size
    num2=(char*)malloc(100*sizeof(char));//
    printf("输入两个长长整型数据:");
    scanf("%s",num1);//size
    printf("%s\n",num1);
    printf("输入两个长长整型数据:");
    scanf("%s",num2);//scanf_s("%s",num2,100);vc中才有更安全的（防溢出）scanf_s函数
    printf("%s\n",num2);
    int len_num1=strlen(num1);
    printf("\n%d",len_num1);
    int len_num2=strlen(num2);
    printf("%d\n",len_num2);
    len_max=(len_num1>=len_num2)?len_num1:len_num2;
    len_min=(len_num1<=len_num2)?len_num1:len_num2;
    int len_max1=len_max;
    sum=(int*)malloc(sizeof(int)*(len_max+1));
    memset(sum,0,len_max+1);//size
    for(;len_num1>0&&len_num2>0;len_num1--,len_num2--){
        sum[len_max--]=((num1[len_num1-1]-'0')+(num2[len_num2-1]-'0'));
    }
    if(len_num1>0)
    {
        sum[len_max--]=num1[len_num1-1]-'0';
        len_num1--;
    }
    if(len_num2>0)
    {
        sum[len_max--]=num1[len_num2-1]-'0';
        len_num2--;
    }
    int j;
    for(j=len_max1;j>=0;j--){
        if(sum[j]>=10){
            sum[j-1]+=sum[j]/10;
            sum[j]%=10;
        }
    }
    char* outsum=(char*)malloc(sizeof(char)*(len_max1+1));
    j=0;
    while(sum[j]==0) j++;//这点小错误你都解决不了？
    int m;
    int j2 =j;
    for(m=0;m<=len_max1-j2/*j*/;++j,++m){//这里我犯了一个致命的错误，错把len_max1-j当做了常量使用！！
        outsum[m]=sum[j]+'0';
        }
    outsum[m]='\0';
    printf("输出两长长整型数据之和：%s\n",outsum);
    free(num1);
    free(num2);
    free(outsum);
    return 0;
}
