#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#define NUM 100
void fun(char* s){
    assert(s != NULL);
    int i=0,j=0;
    while(s[j] != '\0'){
        while(s[j] == 'a'||s[j] == 'e'|| s[j] =='i'|| s[j] == 'o'||s[j] == 'u'){
        //我想哪里去了，竟然想用字符数组的索引来判断
            j++;
        }
        s[i++] = s[j++];
    }
    s[i] ='\0';
}//也可以给每个字母分配一个素数，从2开始，依次类推，然后遍历字符串s,把每个字母代表的素数除乘积，若能整除，则将其删除。

void fun2(char* s){
    int i=0, j=0;
    while(s[j] == ' ')//
        j++;
    int len = strlen(s)-1;
    while(s[len] == ' ') len--;//
    s[len+1] = '\0';
    while(s[j] != '\0'){
        int k = 0;
        while(s[j] == ' '){//注意此处的逻辑。
           k++; 
           j++;
        }
        if(k == 1) s[i++]=s[j-1];
        if(s[j-1] == ' '&&s[j-2] == ' '&&i!=0)//判断i！=0是为了防止将头部的连续字符变为1个。注意此处的逻辑，逆向思维！
            s[i++]=' ';
        s[i++]=s[j++];
    } 
    s[i]='\0';
}

int main(){
    char* s=(char*)malloc(NUM);
    fgets(s,NUM,stdin);//gets(s);
    printf("%s\n",s);
    fun(s);
    printf("%s\n",s);
    fun2(s);
    printf("%s\n",s);
    return 0;
}
