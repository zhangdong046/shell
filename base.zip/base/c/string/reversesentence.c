#include<stdio.h>
#include<string.h>
#include<assert.h>
#include<stdlib.h>
void Reverse(char* pb,char* pe){
    if(pb == NULL||pe == NULL) return;
    while(pb<pe){
        char tmp = *pb;
        *pb = *pe;
        *pe = tmp;
        pb++,pe--;
    }//典型
}
char* ReverseSentence(char* pData){
    if(pData == NULL) return NULL;
    char* pBegin = pData;char* pEnd=pData;
    while(*pEnd != '\0')
        pEnd++;
    pEnd--;
    Reverse(pBegin,pEnd);
    pBegin=pEnd=pData;
    while(*pBegin != '\0'){
        if(*pBegin == ' '){
            pBegin++;
            pEnd++;
            continue;
        }
        else if(*pEnd==' '||*pEnd == '\0'){
            Reverse(pBegin,--pEnd);
            pBegin = ++pEnd;
        }
       else
           pEnd++;
    }
    return pData;
}
int main(){
    char* s=(char*)malloc(20);
    //scanf("%s",s);
/*
char* gets(char* buffer);
头文件：stdio.h(cstdio)
从stdin流中读取字符串，直到接受到换行符或EOF时停止，并将读取的结果存放在buffer指针所指向的字符数组中。
换行符不作为读取串的内容，读取的换行符被转换为‘\0’空字符，并由此来结束字符串。
本函数无限读取，不会判断上限，如果读取溢出，多出来的字符将被写入到堆栈中，这就覆盖了堆栈原先的内容，破坏了一个或多个不相关变量的值。
*/
    //gets(s);
/*
linux下gcc编译器不支持gets这个函数，解决办法是使用fgets(char* s,int size,FILE* stream)
fgets(p,20,stdin);//stdin意思为键盘输入
fputs(p,20,stdout);
*/
    fgets(s,20,stdin);
    printf("%s\n",s);
    s = ReverseSentence(s);
    printf("%s\n",s);
    free(s);
    return 0;
}
