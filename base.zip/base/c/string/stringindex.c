#include<iostream>//纯c语言想使用bool变量需要引入头文件stdbool.h
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
using namespace std;
const int tableSize=256;//尽量不要使用全局变量
bool char_set[256];//内置数据的全局数组，自动初始化为0
void FirstNotRepeatingChar(const char* pString){
    assert(pString != NULL);
/*
由于ASCII字符是一个长度为8的整数类型，总共有可能256种可能。
每个字母根据其ASCII码值作为数组的下标对应数组的对应项，而数组中存储的是每个字符对应的次数。
*/
    unsigned int hashTable[tableSize];//unsigned int
    for(unsigned int i=0; i < tableSize; ++i){
        hashTable[i] = 0;
    }
    const char* pHashKey=pString;
    while(*(pHashKey) != '\0')
        hashTable[*(pHashKey++)]++;//隐式类型转换
    pHashKey = pString;
    while(*pHashKey != '\0'){
        if(hashTable[*pHashKey] == 1){
            printf("%c",*pHashKey);
            return;
        }
        pHashKey++;
    }
}
int isUniqueCharString(const char* str){
    assert(str != NULL);
    int len=strlen(str);
    int i;
    for(i=0;i<len;++i){
        int val=str[i];
        if(char_set[val]) return 0;
        char_set[val] = true;
    }
    return 1;
}
int isUniqueChars(const char* str){
    assert(str != NULL);
    int checker=0;
    int len=strlen(str);
    int i;
    for(i=0;i<len;++i){
        int val = str[i] - 'a';
        if((checker&(1<<val))>0) return 0;
        checker |= (1<<val);
    }
    return 1;
}
int main(){
    char *p = (char*)malloc(20);
    char* q = (char*)malloc(20);
    scanf("%s",p);
    scanf("%s",q);
    if(1 == isUniqueChars(p))
        if(1 == isUniqueChars(p))
            printf("year!");
    FirstNotRepeatingChar(q);
    return 1;
}
