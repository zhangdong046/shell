#include<assert.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
void multiply(const char*a, const char* b)
{
    assert(a != NULL&&b != NULL);
    int i,j,ca,cb,*s;
    ca = strlen(a);
    cb = strlen(b);
    s = (int*)malloc(sizeof(int)*(ca+cb));
    for(i=0;i<ca+cb;i++){
        s[i] = 0;
    }
    for(i=0;i<ca;i++)
        for(j=0;j<cb;j++)
            s[i+j+1]+=(a[i]-'0')*(b[j]-'0');//i+j+1//0,1--1*1
    for (i=ca+cb-1;i>=0;i--)//ca+cb-1
        if(s[i]>=10){
            s[i-1]+=s[i]/10;
            s[i]%=10;
        }
    char* c=(char*)malloc((ca+cb)*sizeof(char));
    i=0;
    while(s[i]==0) i++;//i
    for(j=0;i<ca+cb;i++,j++) c[j]=s[i]+'0';//j--i
    c[j]='\0';//'\0'
    for(i=0;i<ca+cb;i++) printf("%c",c[i]);//第一次这里错写成了%d,1打成了48
    free(s);
    free(c);    
}
int main(){
    char* p=(char*)malloc(100);//一般情况下，以魔法数字为耻。
    char* q=(char*)malloc(100);
    scanf("%s",p);
    scanf("%s",q);
    multiply(p,q);
    return 0;
}
