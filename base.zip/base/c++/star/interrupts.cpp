/*
1、不可重入函数在实现的时候通常使用了全局的资源，在多线程的环境下，若没有很好地处理数据保护和互斥访问，就会出错。
    1.1、常见的不可重入函数：printf-->引用了全局变量stdout.malloc/free-->全局内存分配表.在unix里，通常都有加上_r后缀的同名可重入函数版本。
    1.2、若实在没有，不妨在可预见的发生错误地方尝试加上保护同步锁机制。
2、重入一般理解为一个函数在同时多次调用，例如操作系统或者单片机，处理器等中断时会发生重入现象。有时候会破坏前面调用的函数存储在寄存器中的结果。
1、中断服务子程序ISR.
    1.1、不能返回一个值。
    1.2、不能传递参数。
    1.3、在许多处理器/编译器中，浮点一般都是不可重入的；ISR应该是短而有效率的，在ISR中做浮点运算是不明智的。
    1.4、printf()经常有重入和性能上的问题，所以一般不使用printf().
*/
/*
volatile关键字：
当一个对象的值可能会在编译器的控制或监测之外被改变时，例如一个被系统时钟更新的变量，那么该对象应该声明为volatile.
因此编译器执行某些例行优化行为不能应用在已指定为votalite的对象上。
1、优化器在用到这个变量时必须每次都小心地重新读取这个变量的值，而不是使用保存在寄存器中的备份，下面是volatile变量的几个例子：
    1.1、并行设备的硬件寄存器（如状态寄存器）
    1.2、一个中断服务子程序中会访问到的非自动变量
    1.3、多线程中被几个任务共享的变量。
2、一个参数可以既是const又是volatile吗？
    2.1、可以，一个例子就是只读的状态寄存器。它是volatile,因为它可能被意想不到地改变。它又是const,因为程序不应该试图去修改它。
    2.2、一个指针可以是volatile的，一个例子是当一个中断服务子程序修改一个指向一个buffer的指针时。
*/
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
typedef struct student{
    int data;
    struct student* next;
}node;

typedef struct linkqueue{
    node*first,*rear;
}queue;

queue* insert(queue* HQ,int x){
    node *s;
    s=(node*)malloc(sizeof(node));
    s->data = x;
    s->next =  NULL;
    if(HQ->rear == NULL)
    {
        HQ->first = s;
        HQ->rear = s;
    }else{
        HQ->rear->next = s;
        HQ->rear = s;
    }
    return (HQ);
}

queue* del(queue *HQ){
    node* p;
    int x;
    if(HQ->first == NULL){
        printf("\n yichu");
    }else{
        x=HQ->first->data;
        cout<<x<<endl;
        p=HQ->first;
        if(HQ->first == HQ->rear){
            HQ->first = NULL;
            HQ->rear = NULL;
        }else{
            HQ->first = HQ->first->next;
            free(p);
        }
    return (HQ);
    }
}
typedef struct Student{
    int data;
    struct Student *next;
}Node;

typedef struct stackqueue{
    Node *zhandi = NULL;
    Node *top = NULL; 
}Queue;

Queue *push(Queue *H,int x){
    Node* m;
    m=(Node*)malloc(sizeof(Node));
    m->data =x;
    m->next = NULL;
    if(H->zhandi == NULL){
        printf("1,\n");
        H->zhandi = m;
        H->top = m;
    }else{
        printf("2,\n");
        H->top->next = m;//Segmentation fault
        H->top = m;
    }
    return (H);
}

Queue* pop(Queue* H){
    Node* n;
    int x;
    if(H->zhandi == NULL)
        printf("\n yichu");
    else{
        x = H->zhandi->data;
        cout<<x<<endl;
        n = H->zhandi;
        if(H->zhandi == H->top){
            H->zhandi = NULL;
            H->top = NULL;
        }else{
            while(n->next != H->top){
                n=n->next;
            }
            H->top = n;
            H->top->next = NULL;
        }
    return (H);
    }
}
int main(){
    queue *l;
    Queue *h;
    insert(l,1);
    del(l);
    push(h,2);
    pop(h);
    return 0;
}

