#include<iostream>
#include<string>
using namespace std;
/*
多态性可以简单地概括为”一个接口，多种方法“，在程序运行的过程中才决定调用的函数。多态性是面向对象编程领域的核心概念。
允许子类类型的指针赋值给父类类型的指针。
1、虚函数总是在派生类中被改写，这种改写为overwrite或override,它指派生类重写基类的虚函数，重写的函数必须有一致的参数表和返回值。
2、overload约定理解为重载，指编写与已存在函数同名但参数表不同的函数。
    2.1、重载，是指允许存在多个同名函数，而这些函数的参数表不同（或许参数个数不同，或许参数类型不同，或许两者都不同）。
    2.2、对int_func和str_int_func这两个函数的调用，在编译期间就确定了，是静态的。
    2.3、也就是说它们的地址在编译期间就绑定了。因此重载与多态无关。
虚函数重写与函数重载的区别。
3、真正与多态相关的是”覆盖“，当子类重新定义了父类的虚函数后，父类指针根据赋给它的不同的子类指针，动态地调用属于子类的虚函数，这样函数调用在编译期间是无法确定的。
    3.1、这样的函数地址是在运行期绑定的（晚绑定）。
重载只是一种语言特性，与多态无关，与面向对象也无关。
*/
/*
1、封装可以隐藏实现细节，使得代码模块化；继承可以扩展已存在的代码模块（类），它们的目的都是为了代码重用。
2、而多态确实为了实现另一个目的，接口重用。
3、继承为重用代码而存在的理由已经越来越薄弱，因为”组合“可以很好地取代继承扩展现有代码的功能，而且”组合“的表现更好（防止类爆炸）。
4、继承的存在很大程度上是作为”多态“的基础而非扩展现有代码的方式。
*/
class Eye{
public:
    void look(void){}
};
class Nose{
public:
    void smell(void){}
};
//若在逻辑上A是B的一部分，则不允许B从A派生，而是要用A和其他东西组合出B
class Mouth{
public:
    void eat(void){}
};
class Ear{
public:
    void listen(void){}
};
class Head{
public:
    void look(void){
        m_eye.look();
    }
    void smell(void){
        m_nose.smell();
    }
    void sat(void){
        m_mouth.eat();
    }
    void listen(void){
        m_ear.listen();
    }
private:
    Eye m_eye;
    Nose m_nose;
    Mouth m_mouth;
    Ear m_ear;
};
/*
1、使用抽象类，或者构造函数被声明为private：此时c++可以阻止一个类被实例化。
    1.1、当构造函数被声明为private的时候，可以阻止编译器生成默认的copy constructor。
2、什么时候编译器会生成默认的copy constructor：
    2.1、有4种情况，会导致”编译器必须为未声明constructor之class合成一个default constructor。
    2.2、该类继承自带有缺省构造函数的基类；
    2.3、带有一个virtual function的class.
    2.4、带有一个virtual base class的class.
    2.5、带有member object的类。
3、被合成出来的构造函数满足编译器而非程序需要，它之所以能够完成任务，是借着”调用member object或base class“的default constructor或是”为每一个object初始化其virtual function机制或者virtual base class机制“而完成。
4、并不是任何classm没有定义缺省构造函数，都会被合成出一个来。
5、编译器合成出来的缺省构造函数不一定会明确设定”class 内每一个data member的默认值“
*/
class bird{
public:
    void eat(void){}//ISO C++ forbids declaration of ‘eat’ with no type
    void sleep(void){}
    void fly(void){}
};

class ostrich{
public:
    void eat(void){
        cout<<"ostrich eat!\n";
        birds.eat();
    }
    void sleep(void){
        cout<<"ostrich sleep!\n";
        birds.sleep();
    }
protected:
    bird birds;
};
/*
如果一个类含有纯虚函数，则该类不能实例化。
带有虚函数的类中每一个对象都有一个虚指针指向该类的虚函数表。
每个虚函数都在vtable中占了一个表项，保存着一条跳转到它的入口地址的指令（实际上就是保存了它的入口地址）。
调用虚函数的时候，不管你是用什么指针调用的，它先根据vtable找到入口地址再执行，从而实现了动态联编，而不像普通函数那样简单地跳转到一个固定地址。
*/
int main(){
    Head *a = new Head;
    ostrich xiaoq;
    xiaoq.eat();
    xiaoq.sleep();
    return 0;
}
/*
不要把可替代性和子集混淆，即使鸵鸟集是鸟集的一个子集，但并不意味着鸵鸟的行为可以代替鸟的行为，
当评价一个潜在的关系时，重要的因素是可替代行为，而不是子集。
如果一定要让鸵鸟继承鸟类，可以采用组合的办法，把鸟类中可以被鸵鸟继承的函数挑选出来。
*/
