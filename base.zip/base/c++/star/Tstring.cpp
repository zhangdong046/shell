#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
class Tstring
{
public:
    Tstring(const char* str = NULL)
    {
        if(str==NULL)
        {
            atom = new char[1];//new 指针
            *atom = '\0';
        }else{
            int length = strlen(str);
            atom = new char[length+1];
            strcpy(atom,str);
        }
    }
    ~Tstring()
    {
        delete []atom;//delete 配套
    }
    Tstring(const Tstring&other)
    {
        int length = strlen(other.atom);
        atom = new char[length+1];
        strcpy(atom,other.atom);
    }
    Tstring& operator =(const Tstring&other)
    {
        if(this == &other)
            return *this;
        delete []atom;
        int length = strlen(other.atom);
        atom=new char[length+1];
        strcpy(atom,other.atom);
        return *this;
    }
private:
    char* atom;
};

class Integer
{
public:
    Integer(const char*str=NULL)
    {
        if(str==NULL)
            {
                sdata = new char[1];
                *sdata = '\0';
                data = new int[1];
                *data = 0;
                flag=0;
                length =0;//此处不赋值，length将成为不确定的值。//std::bad_alloc',内存分配错误。
            }else{
                length = strlen(str);//strlen为不计入'\0'的长度。但是strcpy带‘\0’拷贝。
                data = new int[length];
                sdata = new char[length+1];
                //memset(data,0,length*sizeof(int));//sizeof(int)使用错误。而且即将被覆盖的内存没有清零必要。
                strcpy(sdata,str);
                int num = 0;
                for(int i = length-1;i>=0;i--)//Segmentation fault,越界错误。(i--错误写成了i++).
                {
                    data[num++] = str[i]-'0';
                }
                flag=0;
           }
    }
    ~Integer()
    {
        delete []data;
        delete []sdata;
    }
    Integer& operator=(const Integer& other)
    {
        if(this==&other)
        {
            return* this;
        }
        delete []data;//必须
        delete []sdata;
        if(other.length == 0){//不能new int[0]；
            sdata = new char[1];
            *sdata = '\0';
            data = new int[1];
            *data = 0;
            flag=other.flag;
            length =0;
        }else{
            data = new int[other.length];
            sdata = new char[other.length+1];
            memset(data,0,length*sizeof(int));
            strcpy(sdata,other.sdata);
            for(int i=0;i<other.length;i++)//other.length此时length尚为未知值
            {
                data[i] = other.data[i];
            }
            flag = other.flag;
            length = other.length;
        }
        return *this;
    }
    bool operator!=(const Integer& other)
    {
        return !(*this==other);
    }
    bool operator==(const Integer&other)
    {
        if(this==&other)//
            return true;
        bool ret = true;
        if((length != other.length)||(flag != other.flag))//效率
            return false;
        for(int i=0;i<length;i++)
        {
            if(data[i] != other.data[i])
                {
                    cout<<data[i]<<endl<<i<<endl<<other.data[i]<<endl;
                    ret = false;
                }
        }
        return ret;
    }
    friend ostream& operator<<(ostream& out,const Integer& other)
    {
        if(other.flag)
            out<<"-";
        for(int k = other.length-1;k>=0;k--)
            {
                out<<other.data[k];
            }
        return out;
    }

    int* data; 
private:
    int flag;
    int length;
    char* sdata;
};
int main(int argc,char**argv)//char* argv[]
{
    for(int i=0;i<argc;i++)
        {
            char* tmp = argv[i];
            Tstring a(tmp);
            Tstring b;
            b=a;
            Integer c;
            Integer d;
            d=c;
            cout<<d;
            if(d!=c) cout<<"赋值出错！"<<endl;
            else cout<<"赋值成功！"<<endl;
            Integer e("abc");
            Integer f;
            f=e;
            printf("%d\n",f.data);//需要添加stdio.h且sdata为public段的。
            if(f==e) printf("%d\n",e.data);//指针地址
        }
    return 0;
}
