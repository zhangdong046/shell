#include<iostream>
#include<typeinfo>
using namespace std;
template <class type>
//为模板形参显式指定实参：Point<float> obj;(栈对象)；Point<float>* obj = new Point;(堆对象，delete obj;)
class Point{
public:
    Point(type x = 0.0):_x(x){}
//虚析构函数解决问题：基类的指针指向派生类对象，并且基类的指针删除派生类对象
//如果不声明为虚析构函数，delete 基类指针的时候，不会调用继承类的析构函数。(vptr是在对象中的，基类指针指向的继承类对象的vptr指针)。
//若某个类不包含虚函数，即其将不作为一个基类使用，使用虚析构函数不仅会使对象体积翻倍，还会降低其可移植性。
//当且仅当类里包含至少一个虚函数的时候才去声明虚析构函数。
//抽象类必须要有虚析构函数，纯虚函数会产生抽象类。
//在想要成为抽象类的类里声明一个纯虚析构函数，必须提供纯需析构函数的定义。
    virtual ~Point(){}
    type x(){return _x;}
    virtual void set(float xval)
        {
            _x = xval;
        }
//静态成员函数和普通成员函数的声明和实现没区别，但是静态函数是没有this指针的，因此不能访问
//任何非静态的其他成员函数及成员变量，如果要访问需要传递this指针进去。
    static int PointCount()
        {
            cout<<point_count<<endl;
        }    
//const实施于成员函数的目的，确保该成员函数可作用于const对象身上
//const对象，指向const对象的指针或引用只能调用其const成员函数，而非const对象可调用非const成员函数与const成员函数
//普通的成员函数总是具体的属于某个类的具体对象，一般都隐含了一个this指针，指向类的对象本身。
    virtual Point<type>& Pointback( Point<type>& pt) const;//改变了隐含的this形参的类型，const成员函数不能修改调用该函数的对象（mutable成员除外）
protected:
    type _x;
//static作用，非类函数：1、隐藏（封装，对其他源文件隐藏，防止命名冲突）;非类变量：1、默认初始化为0；2、保持局部变量内容的持久。
//类中static:表示属于一个类而不是属于此类的任何特定对象的变量或函数。
    static int point_count;//static 数据成员必须在类定义体外定义,正好一次，独立于该类的任意对象而存在。
//规则例外：基本整型const static 数据成员可以在类的定义体中进行初始化，但该数据成员仍必须在类的定义体外进行定义，只不过定义时，不再需要初始化。
};

template<class type>
int Point<type>::point_count = 1;
//static静态成员变量不能在类的内部初始化，在类的内部只是声明，定义必须在类定义体的外部，通常在类的实现文件中初始化。
//给const static成员变量赋值时，不需要加static修饰符，但要加const.
//const成员变量也不能在类定义处初始化，只能通过构造函数初始化列表进行，并且必须有构造函数。其只在某个对象生存期内是常量，对整个类而言是可变的。
template<class type>
inline Point<type>& Point<type>::Pointback( Point<type>& pt) const{
    return pt;//如果参数写为const Point<type>& pt则会报错：invalid initialization of reference of type。错把const对象赋值给非const对象。       
}

int main(){
    Point<float> obj(1.5);
    obj.x();
    obj.set(2.5);
    Point<float>* obj1 = new Point<float>;
    *obj1 = obj.Pointback(obj);
    delete obj1;
    //cout<<typeid(&Point<float>::point_count).name()<<endl;//protected:变量只能通过成员函数访问。
    //cout<<typeid(&Point<float>::_x).name()<<endl;
//成员函数指针：int (base::*p)()=&base::func;
//普通函数指针(包含静态成员函数):int (*p)()=&base::func;
    int (*pf)() = &Point<float>::PointCount;
//静态成员函数的地址可以用普通函数指针储存，而普通成员函数的地址需要用类成员函数指针来储存。
//静态成员函数不能同时声明为virtual，const,volatile函数。
    return 0;
}
//常量数据成员（成员变量）必须在构造函数的成员初始化列表中进行初始化。
