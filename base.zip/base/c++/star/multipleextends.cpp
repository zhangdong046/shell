/*
                                               继承方式
                              类（成员函数）                类对象
                     私有继承  保护继承  公有继承  私有继承  保护继承  公有继承
              私有       0        0         0         0         0         0
父类成员类型  保护       1        1         1         0         0         0
              公有       1        1         1         0         0         1
1、私有继承方式
    1.1、基类成员【对其对象的可见性】与一般类及其对象的可见性相同，公有成员可见，其他成员不可见；
    1.2、基类成员【对派生类的可见性】对派生类来说，基类的公有成员和保护成员是可见的，（基类的公有成员和保护成员都作为派生类的私有成员，并且不能被这个派生类的子类访问）    1.3、基类成员对【派生类对象的可见性】对派生类对象来说，基类的所有成员都是不可见的。
//私有/保护继承的类对象，不能使用基类的成员，但它们的类可以使用基类的公有和保护成员。*/
//基类的private对所有的外界都是屏蔽的（包括自己的继承类）
//基类的protected控制符对应用程序时屏蔽的，但对其派生类是可访问的。
#include<iostream>
#include<memory.h>
#include<assert.h>
using namespace std;
class A{
    char k[3];
public:
    virtual void aa(){}
};//3+1+4
class B:public virtual A{
    char j[3];
public:
    virtual void bb(){}
};//3+1+4+4+3+1：继承类的vptrz指针（记录基类对象地址位移）和基类vptr指针。
class C:public virtual B{
    char i[3];
public:
    virtual void cc(){}
};//3+1+4+3+1+4+3+1+4//每一层都有自己的vptr指针,专指虚继承，而不是虚函数继承。
/*
class Base1{
public:
    Base1();
    virtual ~Base1();
    virtual void speakClearly();
    virtual Base1 *clone() const;
protected:
    float data_Base1;
};
class Base2{
public:
    Base2();
    virtual ~Base2();
    virtual void mumble();
    virtual Base2 *clone() const;
protected:
    float data_Base2;
};
class Derived:public Base1,public Base2{
public:
    Derived();
    virtual ~Derived();
    virtual Derived *clone() const;
protected:
    float data_Derived;
};
多重继承情况记录内容如下：*/
/*
Derived's vptr(shared with Base1):
#1、type_info for Derived
#2、Derived::~Derived()
#3、Base1::SpeakClealy()
#4、Derived::clone()
#5、Base2::mumble() //需要执行期调整this指针

Base2 subobject's vptr:
#1、type_info for Derived
#2、Derived::~Derived()
#3、Base2::mumble()
#4、Derived::clone() //需要执行期调整this指针

Derived object:
此处无__vptr__指针和vtbl表
在多重继承下，一个derived class 内含n-1个额外的virtual tables,n表示其上一层base classes的数目（单一继承将不会有额外的virtual tables）
对于本例之Derived而言，会有两个virtual tables被编译器产生出来：
1、当你将一个Derived对象地址指定给一个Base1指针或Derived指针时，被处理的virtual table是主要表格vtbl_Derived；
2、当你将一个Derived对象地址指定给一个Base2指针时，被处理的virtual table是次要表哥vtbl_Base2_Derived.
3、指向主要表格的指针，可有主要表格名称加一个offset求得。
*/
int main(int argc,char *argv[]){
    cout<<"sizeof(A):"<<sizeof(A)<<endl;
    cout<<"sizeof(B):"<<sizeof(B)<<endl;
    cout<<"sizeof(C):"<<sizeof(C)<<endl;
    return 0;
}
