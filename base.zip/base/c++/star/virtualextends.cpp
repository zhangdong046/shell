#include<iostream>
using namespace std;
class Point2d{
public:
    Point2d(float x= 0.0,float y= 0.0):_x(x),_y(y){}
    virtual ~Point2d(){}
    virtual void mumble(){}
    virtual float z(){}
protected:
    float _x,_y;
};
class Point3d:public virtual Point2d{
public:
    Point3d(float x = 0.0,float y = 0.0,float z = 0.0):_z(z),Point2d(x,y){}
    ~Point3d(){}
    float z(){}
protected:
    float _z;
};
/*
#0   _z
#4   _vptr_Point3d-------->1.1、offset to virtual base
#8   _x                    1.2、type_info for Point3d
     _y                    1.3、Point3d::~Point3d()
     _vptr_Point2d-------------------------------------------->2.1、type_info for Point3d         
                           1.4、Point3d::mumble()              2.2、Point3d::~Point3d()
                           1.5、Point3d::z()                   2.3、Point3d::mumble()
                                                               2.4、Point3d::z()
*/
int main(){
    cout<<sizeof(Point3d);
    return 0;
}  
