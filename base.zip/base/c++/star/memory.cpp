#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
//栈区、堆区、全局（静态）存储区、文字常量区、代码区（段）。
int a = 0;//全局初始化区
char* p0;//全局未初始化区
void GetMemory(const char* p){
    p = (char*)malloc(11);
}
int main(){
    char* p1 = (char*)malloc(10);
    free(p1);
    char* p2 = new char[10];
    delete []p2;
    int b;//存放在栈上
    char s[] = "abc";//s为一个大小为4的数组，存放在栈上
    char* p3;//栈
//注意：p4中存放指向文字常量区的地址：const char* p4; p4 = "123456";
    const char* p4="123456";//123456\0在文字常量区，p4在栈上，p4中存放指向文字常量区的地址
    static int c = 0;//全局(静态)初始化区
    p3 =(char*)malloc(10);//分配的10字节的区域在堆区，变量p3位于栈上，p3指向堆区分配的内存
    strcpy(p3,"123456");//123456\0放在常量区，编译器可能会将它与p3所指向的”123456“优化成一个地方。
    const char* str = "Hello";
    GetMemory(str);
    //strcpy(str,"Hello World");
    printf("%s",str);
    return 0;
/*
开始时，str指向文字常量区的指针，GetMemory(str)并不会为str新分配空间：
    str---> Hello\0 <---p
如上图，函数调用传参时，str和形参的p虽然指向相同，但他们自身的地址是不同的，是两个不同的变量。
    str-->Hello\0
    p--->11个字节的堆区
如上图，p在执行malloc之后就指向不同的位置了，随后因为p是局部变量而被释放，malloc的空间没有被free，成为无法被引用的空间了。
    可见str一直都是指向"Hello"的，即str指向文字常量区，而文字常量区是不允许修改的，使用strcpy就会出错。
*/
}
