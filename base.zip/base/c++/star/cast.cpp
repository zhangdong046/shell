#include<iostream>
using namespace std;
/*
c++中，有4个类型转换操作符：static_cast,const_cast,dynamic_cast,reinterpret_cast
1、假设你想把一个int转换为double，以便让int类型变量的表达式产生出浮点数据的结果
    int f1,s2;
    double result = static_cast<double>(f1)/s2;
    1.1、在c++中，static_cast在功能上相对c语言来说有所限制。
    1.2、不能像c风格那样把struct转换成int类型；
    1.3、不能把double类型转换为指针类型。
    1.4、不能从表达式中去除const属性。
2、const_cast最普通的用途就是转换掉对象的const属性。
    const B b1 = b0;
    const_cast<B&>(b1).mdata = 200;
    2.1、使用const_cast,编译器知道通过类型转换想做的只是改变一些东西的constness或者volatileness属性。
    2.2、如果试图用其来完成这两个之外的事情，会被拒绝。
3、static_cast和reinterpret_cast操作符修改了操作数类型。
    3.1、static_cast在编译时使用类型信息执行转换，在转换时执行必要的检测（诸如指针越界检查，类型检查），其操作数相对是安全的。
    3.2、reinterpret_cast仅仅是重新解释了给出的对象的比特模型，而没有进行二进制转换。
    3.3、编译器隐式执行任何类型转换都可由static_cast显式完成。
    3.4、reinterpret_cast通常为操作数的位模式提供较底层的重新解释。
4、 4.1、dynamic_cast是在运行时检查的，dynamic_cast用于在继承体系中进行安全的向下转换downcast(当然也可以执行向上转换，但是没必要，因为完全可以用虚函数实现)，即基类指针/引用到派生类指针/引用的转换。如果源和目标没有继承/被继承关系，编译器会报错，否则必须在代码里判断返回值是否为NULL来确认转换是否成功。
    4.2、dynamic_cast不是扩展c++中style转换的功能，而是提供了类型安全性。你无法使用dynamic_cast进行一些“无理”的转换。
    4.3、dtnamic_cast是4个转换中唯一的RTTI操作符，提供运行时类型检查。
    4.4、dynamic_cast不是强制转换，而是带有某种“咨询”性质的。如果不能转换，返回NULL,表示不成功，这是强制转换做不到的。
*/
class A{
    int m_nA;
};
class B{
    int m_nB;
};
class C:public A,public B{
    int m_nC;
};
int main(){
    C* pc = new C;
    B* pb = dynamic_cast<B*>(pc);
    A* pa = dynamic_cast<A*>(pc);
//当pc==pb比较时，实际上是比较pc指向的对象和C*隐式转换pb后pb指向的对象（pc指向的对象）的部分，这个是同一部份。
//pb实际上指向的地址是对象C中的子类B部分，在地址上跟pc不一样，直接比较地址数值不相等。
    if(pc == pb) cout<<"pc == pb"<<endl;//这里两端的数据类型不同，比较时需要进行隐式的类型转换，相当于pc == (C*)pb.
    if(int(pc) == int(pb)) cout<<"int(pb) == int(pc)" <<endl;
    return 0;
}
/*
0x3d3dd8<---------pc
0x3d2ddc<---------pb
*/
/*
0x3d3dd8<---------pc<--(【(C*)pb后】)--pb
0x3d2ddc
*/
