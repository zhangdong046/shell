/*c++的额外开销体现在以下方面
1、编译时开销：模板、类层次结构、强制类型检查等新特性。
2、运行时开销
    2.1、虚基类
        2.1.1、从直接虚继承的子类中访问虚基类的数据成员或其虚函数时，将增加两次指针引用（大部分情况下可以优化成一次）和一次整型加法的时间开销
        2.1.2、定义一个虚基类表，定义若干虚基类表指针的空间开销
    2.2、虚函数
        2.2.1、虚函数运行开销有进行整型加法和指针引用的时间开销。
        2.2.2、定义一个虚表，定义若干个虚表指针的空间开销。
    2.3、RTTI(dynamic_cast和typeid)
        2.3.1、RTTI的运行开销主要在整型比较和取址操作所增加的时间开销。
        2.3.2、定义一个type_info对象的空间开销。
        2.3.3、dynamic_cast用于在类层次结构中漫游，对指针或者引用进行自由的向上，向下或者交叉转化。
        2.3.4、typeid则用于获取一个对象或引用的确切类型。
        2.3.5、一般来说，能用虚函数解决的问题就不要用dynamic_cast,能用dynamic_cast解决的就不要用typeid.
    2.4、异常
        抛出和捕捉异常的开销也只是在某些情况下会高于函数返回和函数调用的开销
    2.5、对象的构造和析构
*/
/*
RTTI破坏了面向对象的纯洁性：
    1、它破坏了抽象，使一些本来不应该被使用的方法和属性被不正确地使用。
    2、因为运行时类型的不确定性，它把程序变得更脆弱。
    3、它使程序缺乏扩展性。
其重要作用是动态判别执行时期的类型，由于虚函数本身的局限性，是的使用typeid运算符能使程序员确定对象的动态类型。
1、用typeid()返回一个typeinfo对象，也可以用于内部类型，当用于非多态类型时，没有虚函数，用typeid返回的将是基类地址。
2、动态映射dynamic_cast<类型>（变量）可以映射到中间级，将派生类映射到任何一个基类，然后在基类间相互映射。
3、不能对void指针进行映射。
4、如果p是指针，typeid(*p)返回p所指向的派生类类型，typeid(p)返回基类类型，如果r是引用，typeid(r)返回派生类类型，typeid(&r)返回基类类型。
5、典型的RTTI是通过在vtable中放一个额外的指针实现的。每个新类只产生一个typeinfo实例，额外指针指向typeinfo,typeid返回对它的一个引用。
*/
#include<iostream>
#include<typeinfo>
using namespace std;
class base{
public:
    virtual void funcA(){cout<<"base"<<endl;}
};
class derived:public base{
public:
    virtual void funcB(){cout<<"derived"<<endl;}
};

void funcC(base* p){
    derived* dp=dynamic_cast<derived*>(p);
    if(dp!=NULL)
        dp->funcB();
    else
        dp->funcA();
}

void funcD(base* p){
    derived *dp = NULL;
    if(typeid(*p) == typeid(derived)){
        dp = static_cast<derived*>(p);
        dp->funcB();
    }
    else{
        p->funcA();
    }
}

int main(){
    base*cp = new derived;
    cout<<typeid(cp).name()<<endl;//P4base
    cout<<typeid(*cp).name()<<endl;//7derived
    funcD(cp);//derived
    funcC(cp);//derived
    base *dp = new base;
    funcC(dp);//Segmentation fault
egmentation fault
    return 0;
}

