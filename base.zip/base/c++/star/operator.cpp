#include<iostream>
#include<string>
#include<math.h>
using namespace std;
/*
定义一个重载运算符就像定义一个函数，只是该函数名字是operator@,这里的@代表运算符。
1、运算符被定义为全局函数（对于一元运算符是一个参数，对于二元运算符是两个参数）；
2、如果运算符被定义为全局函数，（对于一元运算符没有参数，对于二元运算符没有参数）。
对于二元运算符，单个参数是出现在运算符右侧的那个，当一元运算符被定义为成员函数时，没有参数，成员函数被运算符左侧的对象调用。
非静态成员函数操作符（带一个参数）是二元运算符，非成员函数操作符（带两个参数）是二元运算符。
*/
/*
友元是一种定义在类体外部的普通函数，但它需要在类体内进行说明。
友元不是成员函数，但是它可以访问类中的私有成员。友元的作用在于提高程序的运行效率，但是，它破坏了类的封装性和隐藏性，使得非成员函数也可以访问类的私有成员。
*/
class Point{
private:
    float x;
    float y;
public:
    Point(float a = 0.0f,float b = 0.0f):x(a),y(b){}
    friend float distance(Point& left,Point& right);
};

float distance(Point& left,Point& right){
//math.h pow() sqrt()
    return sqrt((left.x-right.x)*(left.x-right.x)+(left.y-right.y)*(left.y-right.y));//^是按位异或运算，不是幂运算，还有就是一般不要乱用运算符重载
}
template<class T>
class Test;
template<class T>
ostream& operator<<(ostream& out,const Test<T> &bbj);
template<class T>
class Test{
private:
    int num;
public:
    Test(int n=0){num=n;}
    Test(const Test<T>&copy){num = copy.num;}
    friend ostream& operator<<<>(ostream& out,const Test<T> &obj);//注意在<<后面加上<>表明这是个函数模板
};
template<class T>
ostream& operator<<(ostream& out,const Test<T> &obj){
    out<<obj.num;
    return out;
}
class Base{
public:
    void fun(){throw 1;}
    ~Base(){
        try{
            throw 2;
        }catch(int e)
        {cout<<"异常发生"<<endl;}
    }
};
/*
1、c++中通知对象构造失败的唯一办法，就是在构造函数中抛出异常；
2、对象的部分构造是很常见的，异常的发生点也是完全随机的，程序员要谨慎处理。
3、当对象发生部分构造时，已经够早完毕的子对象将不会被构造了，当然它也没有了析构过程，还有正在构建的子对象和对象自己本身将停止继续构建，并且它的析构是不会被执行的。
4、析构函数尽量不要抛出异常。
    4.1、出现异常的时候，异常处理模块为了维护系统对象数据的一致性，避免资源泄露，有责任释放这个对象的资源，调用对象的析构函数，有可能会陷入无限的递归嵌套当中。
*/
int main(){
    Test<int> t(2);
    cout<<t;
    try{
        Base base;
        base.fun();
    }catch(int e)
    {
/*
此时可以运行是因为析构抛出来的异常，在到达上一层析构节点之前已经被别的catch给处理掉了。
如果当回到上一层异常函数时，其SEH没有变。。。析构函数尽量不要抛出异常。
*/
        cout<<"get the catch"<<endl;
    } 
    return 0;
}
