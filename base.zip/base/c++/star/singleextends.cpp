#include<iostream>
using namespace std;
//关键字virtual告诉编译器它不应当及早完成绑定，它应当自动安装实现晚绑定所必需的所有机制。
/*虚（拟）继承是多重继承中特有的概念
class A;
class B:public virtual A;
class C:public virtual A;
class D:public B,public C;
使用其他类的对象作为这个类的数据成员 ： 复合。
D继承了B和C,如果出现了相同的函数foo(),那么D.B::foo(),D.C::foo()就分别代表从B类中继承的foo函数和从B类中继承的foo函数。
*/
class Point{
public:
    virtual ~Point(){}
    virtual Point& mult(float) = 0;
    float x() const {return _x;}
    virtual float y() const {return 0;}
    virtual float z() const {return 0;}
protected:
    Point(float x = 0.0):_x(x){}
    float _x;    
};

class Point2d:public Point{
public:
    Point2d(float x = 0.0,float y = 0.0):Point(x),_y(y){}
    ~Point2d();
    //改写base class virtual functions
    Point2d& mult(Point2d& s){}
    float y() const{return _y;}
protected:
    float _y;
};

class Point3d:public Point2d{
public:
    Point3d(float x = 0.0,float y = 0.0,float z = 0.0):Point2d(x,y),_z(z){}
    ~Point3d(){}
    //改写base class virtual functions
    Point3d& mult(Point3d& s){return s;}
    float z() const {return _z;}
protected:
    float _z;
};
/*
Point pt;
      _x
     __vptr__Point------------->#0 type_info for Point
                                #1 Point::~Point()
                                #2 pure_virtual_called()
                                #3 Point::y()
                                #4 Point::z() 
*/
/*
Point2d:Point pt2d;
     _x
     __vptr__Point------------>#0 type_info for Point2d
     _y                        #1 Point2d::~Point2d()
                               #2 Point2d::mult()
                               #3 Point2d::y()
                               #4 Point::z()
*/
/*
Point3d:Point2d pt3d;
     _x
     __vptr__Point------------>#0 type_info for Point3d
     _y                        #1 Point3d::~Point3d()
     _z                        #2 Point3d::mult()
                               #3 Point2d::y()
                               #4 Point3d::z()
Point *pp;
pp->mult(pp);----> (*pp)->__vptr__Point[2])(pp);
*/      
int main(){
    cout<<sizeof(Point)<<sizeof(Point2d)<<sizeof(Point3d)<<endl;
    return 0;
}
