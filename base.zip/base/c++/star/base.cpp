#include<iostream>
using namespace std;
const int M =10;//不可以省去int。
int main(){
    int **a = new int* [M];//二维数组的动态声明。此时，只能用a[i][j]或者*(*(a+i)+j)来访问数组的元素，而不能a[i*n+j]这样使用。（非一片连续内存，任意的a[k]都是一个int*类型）。
    for(int i=0;i<M;i++){
        a[i]=new int [M];
    }
    for(int i=0;i<M;++i)
        delete []a[i];
    delete []a;
    return 0;
}
