#include<iostream>
#include<iomanip>
using namespace std;

class C
{
public:
    C(int i):m_Count(i){}
    int incr() const
    {
        return ++m_Count;
    }
    int decr() const
    {
        return --m_Count;
    }
private:
    mutable int m_Count;//类里面的数据成员加上mutable后，修饰为const的成员函数，就可以修改它了。
};
int main(){
    C c1(0),c2(10);
    int tmp,i;
    for(i=0;i<10;++i)
    {
        tmp = c1.incr();
        cout<<setw(tmp)<<setfill(' ')<<tmp<<endl;
        tmp = c2.decr();
        cout<<setw(tmp)<<setfill(' ')<<tmp<<endl;
    }
    return 0;
}
/*
1、unsigned影响的只是最高位bit的意义，数据长度是不会改变的。
    1.1、sizeof(unsigned int) == sizeof(int)
2、自定义类型的sizeof取值等同于它的类型原型。
    2.1、typedef short WORD;sizeof(short) == sizeof(WORD);
3、对函数使用sizeof,在编译阶段会被函数返回值的类型取代；
4、只要是指针，大小就是4
5、数组的大小是各维数的乘积*数组元素的大小。
6、空类占空间为1，多重继承的空类空间还是1，但是虚继承涉及虚表（虚指针），sizeof为4.
*/

