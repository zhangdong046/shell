//class 如果内含一个或多个virtual base class subjects,将会被分割为两部分：一个不变局部和一个共享局部。
/*
1、不变局部中的数据，不管后续如何衍化，总是拥有固定的offset(从object的开头算起)，所以这一部分数据可以被直接读取。
2、共享局部，其位置会因为每次的派生操作而有变化，只能间接存取。
class Point2d{
public:
    ...
protected:
    float _x,_y;
};
class Vertex:public virtual Point2d{
public:
    ...
protected:
    Vertex *next;
};
class Point3d:public virtual Point2d{
public:
    ...
protected:
    float _z;
};
class Vertex3d:public Vertex,public Point3d{
public:
    ...
protected:
    float mumble;
};

1、Point2d pt2d;
    1.1、 float _x
    1.2、 float _y
    1.3、 __vptr__Point2d

2、class Point3d:virtual Point2d{...}pt3d;
    2.1、float _z
    2.2、Point2d* pPoint2d ---->指向subobject开始地址
    2.3、__vptr__Point3d
    1.1、float _x           --|
    1.2、float _y           --|-->Point2d subobject
    1.3、__vptr__Point2d    --|
3、class Vertex:virtual Point2d{...}v;
    3.1、Vertex* next
    3.2、Point2d* pPoint2d ---->指向subobject开始地址
    3.3、__vptr__Vertex
    1.1、float _x           --|
    1.2、float _y           --|-->Point2d subobject
    1.3、__vptr__Point2d    --|
4、class Vertex3d:public Vertex,public Point3d{...}v3d;
    3.1、Vertex* next            ---|
    3.2、Point2d* pPoint2d -->   ---|-->Vertex sub
    3.3、__vptr__Vertex          ---|
    2.1、float _z              ---|
    2.2、Point2d* pPoint2d ->  ---|-->Point3d sub
    2.3、__vptr__Point3d       ---| 
    4.1、float mumble 
    1.1、float _x           --|
    1.2、float _y           --|-->Point2d subobject
    1.3、__vptr__Point2d    --|
虚拟继承，使用virtual table offset strategy所产生的数据布局如下：
    3.1、Vertex* next            
    3.2、__vptr__Vertex  ---->20/./..         
    2.1、float _z              
    2.2、__vptr__Point3d ---->12/./..      
    4.1、float mumble 
    1.1、float _x           
    1.2、float _y           
    1.3、__vptr__Point2d    
虚拟继承：1、消除多重继承的二义性；2、节省空间。
区分虚拟继承和虚函数继承。
*/
#include<iostream>
using namespace std;

class A
{
protected:
    int m_data;

public:
    A(int data = 0)
        {
            m_data = data;
        }
    int GetData(){
        return doGetData();
    }
    virtual int doGetData(){
        return m_data;
    }
};
/*
各个类的同名变量没有形成覆盖，都是单独的变量
*/
class B:public A
{
protected:
   int m_data;
public:
    B(int data =1){
        m_data = data;
    }
    int doGetData(){
        return m_data;
    }
};

class C:public B{
protected:
    int m_data;
public:
    C(int data=2){
        m_data = data;
    }
};
int main(){
    C c(10);
    cout<<c.GetData()<<endl;//调用A的GetData(),因为A中doGetData()是虚函数，故调用B的doGetData()
    cout<<c.A::GetData()<<endl;//A中的doGetData()是虚函数。。。
    cout<<c.B::GetData()<<endl;//1
    cout<<c.C::GetData()<<endl;//1
    cout<<c.doGetData()<<endl;//1
    cout<<c.A::doGetData()<<endl;//因为直接调用了A的doGetData(),故输出0.
    cout<<c.B::doGetData()<<endl;//1
    cout<<c.C::doGetData()<<endl;//1
    return 0;
}
//一个私有的或保护的派生类不是子类，因为非公共的派生类不能做基类能做的所有的事。
//私有派生类对象空间中，包含了父类的对象，只是无法让其公开访问，只能通过其他函数间接访问。
/*
class Animal{
public:
    Animal(){}
    void eat();
};
class Giraffe:private Animal{
public:
    Giraffe(){}
    void StrchNeck(double);    <---->    void take(){eat();}//注意！！为什么此处可以。
};
void Func(Animal&an){
    an.eat();                  <---->    an.take();
}
void main(){
    Giraffe gir;
    Func(gir);//error                     //ok
}
*/
