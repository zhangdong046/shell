/*
int b = 500;
const int* a = &b;
*a = 600;//错误
但是有以下两种方法来改变*a的值
1、通过改变b的值：b = 600;
2、a指向别处：a=&c;
int* const a;//错误，此时定义指针时候必须初始化。
*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;

template<typename t>
struct tcontainer{
    virtual void push(const t&) = 0;
    virtual void pop() = 0;
    virtual const t& begin() = 0;
    virtual const t& end() = 0;
    virtual size_t size() = 0;
};
template<typename t>
struct tvector:public tcontainer<t>{
    static const size_t _step = 100;
    tvector(){
        _size = 0;//初始化向量实际大小
        _cap = _step;//向量容量
        buf = 0;//首地址，需要动态分配内存
        re_capacity(_cap);//此时buf为空，即要设置buf初始值，配了100个元素的空间
    }
    ~tvector(){
        free(buf);
    }
    void re_capacity(size_t s){
        if(!buf)
            buf = (t*)malloc(sizeof(t)*s);
        else
            buf = (t*)realloc(buf,sizeof(t)*s);
    }
    virtual void push(const t& v){
        if(_size >= _cap)
            re_capacity(_cap+=_step);
        buf[_size++]=v;
    }
    virtual void pop(){
        if(_size)
            _size--;
    }
    virtual const t& begin(){
        return buf[0];
    }
    virtual const t& end(){
        if(_size)
            return buf[_size-1];
    }
    virtual size_t size(){
        return _size;
    }
    const t& operator[](size_t i){
        if(i>=0&&i<_size)
            return buf[i];
    }
private:
    size_t _size;//实际元素个数
    size_t _cap;//已分配容量
    t* buf;//首地址
};
int main(){
    tvector<int> v;
    int i;
    for(i=0;i<10;++i)
        v.push(i);
    for(i=0;i<10;++i)
        cout<<v[i]<<endl;
    return 0;
}

