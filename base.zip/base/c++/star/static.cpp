#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
/*
在c++中，static静态成员变量不能在类的内部初始化。在类的内部只是声明，定义必须在类定义体的外部，通常在类的实现文件中初始化。
static关键字只能用于类定义体内部的声明中，定义时不能标示为static.
在c++中，const成员变量也不能在类定义处初始化，只能通过构造函数初始化列表进行，并且必须有构造函数。
const数据成员只在某个对象生存期内是常量，而对整个类而言是可变的。
因为类可以创建多个对象，不同的对象其const数据成员的值是不同的。所以不能在类的声明中初始化const数据成员，
因为类的对象没有创建时，编译器不知道const数据成员的值是什么。
*/
//const数据成员的初始化只能在类的构造函数的初始化列表中进行，要想建立整个类中都恒定的常量，应该用类中的枚举常量来实现，或者用static const.
class Test{
public:
    Test():a(0){}
    ~Test(){}
    enum {size1 = 100,size2 = 200};
private:
    const int a;//只能在构造函数初始化列表中初始化
    static int b;//在类的实现文件中定义并初始化
    const static int c;/*与static const int c;相同，c为整型，故也可以在此处初始化，但仍需在类定义体外定义
注意c为非整型时，不能在此处初始化，整型包括char,short,int,long*/
};
int Test::b=0;//static 成员变量不能在构造函数初始化列表中初始化
const int Test::c=0;//注意，给const static成员变量赋值时，不需要加static修饰符，但要加const。
class Test1{
public:
    const int a;
    static int b;
public:
    Test1(int _a,int _b):a(_a){ b=_b;}//
};
int Test1::b;//这样也算类体外定义了，因为是全局，会自动赋值0.
int main(){
    Test1 t1(0,0),t2(1,1);
    t1.b = 10;
    t2.b = 20;
    printf("%u %u %u %u",t1.a,t1.b,t2.a,t2.b);
    return 0;
}
/*
1、如果两个文件中都定义了相同名字的全局变量，则连接出错，变量重定义。
2、只要文件不互相包含，在两个不同的文件中可以定义完全相同的两个全局静态变量，它们是两个完全不同的变量。
*/

