#include<iostream>
#include<string>
#include<vector>
/*
什么时候一个class不展现出"bitwise copy semantics"?共有4种情况。//位逐次拷贝
    1、当class内含一个member object而后者class声明有一个copy constructor时。
    2、当class继承自一个base class而后者存在有一个copy constructor时（不论是被明确声明还是被合成而得）。
    3、当class声明一个或多个virtual functions时。
    4、当class 派生自一个继承串链，其中有一个或多个virtual base classes时。
前两种情况，编译器必须将member或base class的”copy constructor“调用操作安插到被合成的copy constructor中。
*/
/*
重新设定virtual table指针：
当一个base class object以其derived class的object内容作初始化操作时，其vptr复制操作也必须保证安全。
derived d;
base b = d;
//b的vptr不可以被设定为指向derived class的virtual table(如果b的vptr被直接”bitwise copy“的话，就会导致此结果)
否则，当用b调用derived的函数传入对象的时候，但是b中的derived部分已经被切割掉了，会导致炸毁（blow up）.
此处存在所谓的仲裁或决议！！！！！！！
*/
using namespace std;
class B{
private:
    int data;
public:
    B(){cout<<"default constructor"<<endl;}
    ~B(){cout<<"destructed"<<endl;}
//带参数的构造函数，冒号后边是成员变量初始化列表
    B(int i):data(i){cout<<"constructed by parameter"<<data<<endl;}
};
B play(B b){
    return b;
}
int main(int argc,char* argv[]){
    B temp = play(5);//5通过隐含的类型转换，调用了B::B(int i)
//单个参数的构造函数如果不添加explicit关键字，会定义一个隐含的类型转环（从参数的类型转换到自己），添加explicit关键字会消除这种隐含转换。
    return 0;
//该函数有一个constucted被打出，两个destructed被调用
//play(5)返回时，参数的析构函数被调用
//temp的析构函数被调用，temp的构造函数调用的是编译器生成的拷贝构造函数
}
/*
constructed by parameter5//注意，构造函数，只有这一个被打出，并无default constructor!!!!
destructed
destructed
*/

/*
string& sting::operator=(const string&other){
    if(this == &other)
        return *this;
    delete [] m_data;
    int length = strlen(other.m_data);
    m_data = new char[length+1];
    strcpy(m_data,other.m_data);
    return *this;
}
两个引用，一个const.
const有两个作用：
1、一个const变量是不能随意转换成非const变量的。
    MyString s3(pello);
    const MyString s4(qello);
    s3=s4;
    如果不加入const的话，这里就会出现问题。
2、s1=s2+s3;不用const也会出错，
    因为”+“赋值必须返回一个操作值已知的MyString对象，除非它是一个const对象。
第一个引起作为是为了连续赋值需要，
*/
