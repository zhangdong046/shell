#include<iostream>
using namespace std;
template<class type>
class Point{
public:
    Point(type x = 0.0):_x(x){}
    virtual ~Point(){}
    type x(){return _x;}
    virtual void set(type xval,type yval,type zval)
        {
            _x = xval;
        }
    static int PointCount()
        {
            cout<<point_count<<endl;
        }    
    virtual Point<type>& Pointback( Point<type>& pt) const;
protected:
    type _x;
    static int point_count;
};

template<class type>
class Point2d:public Point<type>{
public:
//这里需要使用Point<type>
    Point2d( type x =0.0,type y =0.0):Point<type>(x),_y(y){}
    virtual ~Point2d(){}
    type y(){return _y;}
//局部变量和参数存在于函数栈中，局部变量的作用范围以此方式与函数对应。栈空间有限，故需要大量的堆对象。
//类对象模型。
/*
    1、数据成员
//执行期绑定的类成员
    2、__vptr__Class-->virtual table for class==> 2.1、 type_info for class
                                                  2.2、 class::~class()
                                                  2.3、 (virtual) class::print(ostream&)
*/
//静态绑定的类成员
//3、静态数据成员；4、静态成员函数；5、构造函数；6、普通成员函数
    virtual void set(type xval,type yval,type zval)
        {
           this->_x = xval;
            _y = yval;
        }
protected:
    type _y;
};
/*
1、非静态成员在类对象中的排列顺序和声明顺序一致，任何在其中声明的静态成员都不会被放进对象布局中。
2、静态数据成员存放在程序的data segment中，和个别类对象无关。
   data segment是程序的虚地址空间的一部分，包含全局变量和静态变量，其大小由程序在运行之前程序员所放置的变量决定。
3、Program memory包括3部分：
    3.1、Data Segment(Data+BSS+Head)
    3.2、Stack
    3.3、Code Segment
在同一个访问快private,public,protected等区段中，成员的排列只需符合较晚出现的成员在类对象中具较高的地址即可，并不一定连续。    
*/

//静态数据成员并不在类对象中，存取静态成员不需要通过类对象，通过操作符.进行存取只是语法上的便宜行事。
//非静态数据成员存放在每一个类对象中，只有经由显示（explicit）或者隐式的（implicit）类对象才能存取。

/*
void Point::translate(const Point &pt){
    x+ = pt.x;
}
事实上x的存取是经由this指针完成的
void Point::translate(Point* this,const Point &pt){
    this->x+ = pt.x;
}
每一个非静态数据成员的偏移量在编译时期即可获得，即便这个成员属于一个基类（派生自单一或者多重继承串链）子对象也是一样的。
但是当使用基类指针且继承链中含有虚函数的时候，我们不知道这个指针到底指向那种类类型，也不知道这个成员的真正偏移量，此时存取操作会延迟汁执行期解决。
derived指针涵盖地址包含整个derived类，而base指针涵盖地址只包含derived类中的base subobject.一般情况下，你不能用base指针来直接处理derived的任何members,唯一例外是通过virtual 机制。
对象声明后是确定的，但是指针却可以对它有不同的解析。
derived->drivedfunc ERROR:base->drivedfunc; RIGHT:((derived*)base)->drivedfunc;
或者if(derived*p=dynamic_cast<base*>pz) p->drivedfunc;（run-time operation）
*/

/*
derived b;
base a=b;引起切割
a.func();调用base::func()
一个pointer或一个reference之所以支持多态，是因为它们并不引发内存中任何“与类型有关的内存委托操作”，会受到改变的只是它们所指向的内存的“大小和内容解释方式”而已。
当一个base class object被直接初始化为（或指定为）一个derived class object时，derived object就会被切割，以塞入较小的base tyoe内存中。derived type没有留下任何蛛丝马迹。
vptr会在初始化中发生vtbl的重新设定（所谓的仲裁），vptr由指向derived类的vtbl变成指向base类的vtbl，多态于是不再呈现。
*/
template<class type>
class Point3d:public Point2d<type>{
public:
    Point3d(type x =0.0,type y=0.0,type z=0.0):Point2d<type>(x,y),_z(z){}
    virtual ~Point3d(){}
    type z(){return _z;}
    virtual void set(type xval,type yval,type zval)
        {
            this->_x= xval;
            this->_y= yval;
            _z = zval;
        }
protected:
    type _z;
};
/*
c++以下列方法支持多态：
1、经由一组隐含的转化操作。例如把一个derived class指针转化为一个指向其public base type的指针： shape *base = new circle();
2、经由virtual function机制。ps->rotate();
3、经由dynamic cast和typeid运算符： if(circle *pc = dynamic_cast<circle*>(ps)).
类对象=其nonstatic data members+由于alignment的需求而填补上的空间+为了支持virtual而由内部产生的任何额外负担。
alignment就是将数据调整到某数的倍数，在32位机器上，通常alignment为4bytes,以使bus的运输量达到最高效率。
*/

//一个指针，不管它指向哪一种数据类型，指针本身所需的内存大小是固定的。指向不同类型之各指针间的差异，既不在其指针表示法不同，也不在其内容上，而在
//其所寻址出来的object类型不同，也就是说，指针类型会教导编译器如何解释某个特定地址中内存内容及其大小。

/*
struct空间计算原则：
1、整体空间是占用空间最大的成员（的类型）所占字节数的整倍数。但在32位的linux+gcc环境下，若最大成员类型所占字节数超过4，则整体空间是4的倍数即可。
2、内存结构按结构体成员的先后顺序排列，当排列到该成员变量时，其前面已摆放的空间大小必须是该成员类型大小的整倍数，不够补齐，依次类推。linux+gcc下前面是4的正被属于即可。
*/
template<class type>
int Point<type>::point_count = 1;
template<class type>
inline Point<type>& Point<type>::Pointback( Point<type>& pt) const{
    return pt;       
}

int main(){
    Point<int>* p=new Point3d<int>(1,2,3);
    p->set(3,2,1);//同名虚函数在基类和继承类的接口必须一致，即参数类型和参数个数必须一致。
    cout<<p->x()<<endl;
    return 0; 
}
/*
函数重载是用来描述同名函数具有相同或者相似功能,但数据类型或者是参数不同的函数管理操作的称呼。
所谓函数重载是指同一个函数名可以对应着多个函数的实现。每种实现对应着一个函数体，这些函数的名字相同，但是函数的参数的类型或返回值不同。
重载函数虽然可以让我们有同名的函数，但这些函数的参数列表应该不一样。所以，为了让重载函数正确工作，编译器要用函数名来区分参数类型名。
重载的函数与具有多态性的函数（即虚函数）不同处在于：调用正确的被重载函数实体是在编译期间就被决定了的；
而对于具有多态性的函数来说，是通过运行期间的动态绑定来调用我们想调用的那个函数实体。
请不要被重载(overloading)和重写(overriding)所迷惑。
重载是发生在两个或者是更多的函数具有相同的名字的情况下。区分它们的办法是通过检测它们的参数个数或者类型来实现的。
*/

/*
如果某类中的一个成员函数被说明为虚函数，这就意味着该成员函数在派生类中可能有不同的实现。
(1) 与基类的虚函数有相同的参数个数； 
(2) 其参数的类型与基类的虚函数的对应参数类型相同； 
(3) 其返回值或者与基类虚函数的相同，或者都返回指针或引用，并且派生类虚函数所返回的指针或引用的基类型是基类中被替换的虚函数所返回的指针或引用的基类型的子类型。
 一般要求基类中说明了虚函数后，派生类说明的虚函数应该与基类中虚函数的参数个数相等，对应参数的类型相同，如果不相同，则将派生类虚函数的参数的类型强制转换为基类中虚函数的参数类型。

*/
//带有纯虚函数的类称为抽象类。
// 抽象类只能作为基类来使用，其纯虚函数的实现由派生类给出。如果派生类没有重新定义纯虚函数，而派生类只是继承基类的纯虚函数，则这个派生类仍然还是一个抽象类。
//隐式类型转换导致重载函数产生二义性.
//函数重载，是静态的多态（静态联编），（不同数量，不同类型的参数）.overload
//虚函数，是动态的多态（动态联编），重写。overwrite
