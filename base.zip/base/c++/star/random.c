#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<assert.h>
void swap(int *a,int *b){//c语言没有引用传参数这种语法
    /*assert(*a != *b);//Assertion `*a != *b' failed.//Aborted
    *a^=*b;
    *b^=*a;
    *a^=*b;不知道为什么，这种方式会出现多于1个的莫名其妙的0元素!!!!*/
    int tmp = *a;
    *a = *b;
    *b = tmp;
}
void display(int card[],int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d,",card[i]);
    printf("\n");
}
void shuffle(int card[],int n)
{
    int i;
    int index = 0;
    for(i=0;i<n;i++){
        index = rand()%(n-i)+i;//全排列的放入方式？(0~n-i-1)+i
        swap(&card[i],&card[index]);
    }
}
/*
算法的本质是“随机确定a[1]的值，然后递归地对后n-1位进行操作”，数学归纳即可证明。这段程序会产生n!中可能情况，正好与全排列对应
如果交换i与rand()%n的话会导致一些重复的数列，公有n^n中情况，且不能被n！整除。
*/
int main(){
    int card[54];
    int i;
    for(i=0;i<54;i++)
        card[i] = i;
    srand((unsigned)time(NULL));//随机种子
    shuffle(card,54);
    printf("Wash ok!\n");
    display(card,54);
    return 0;
}
