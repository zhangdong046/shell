/*原地归并排序*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
void swap(int& x,int& y){
    int tmp=x;
    x=y;
    y=tmp;
    }

void reverse(int*arr,int n){
    int i=0,j=n-1;
    while(i<j){
    swap(arr[i],arr[j]);
    i++;
    j--;
    }
}

void exchange(int *arr,int n,int i)//将含有n个元素的数组向左循环移位i个位置
{
    reverse(arr,i);
    reverse(arr+i,n-i);
    reverse(arr,n);
}
//数组两个有序部分的归并，本节图解的实现
void Merge(int *arr,int begin,int mid,int end){
    int i=begin,j=mid,k=end;
    while(i<j&&j<=k){
        int step=0;
        while(i<j&&arr[i]<=arr[j]) ++i;
        while(j<=k&&arr[j]<=arr[i]){
            ++j;
            ++step;
        }
//arr+i为子数组的首地址，j-i为子数组元素个数，j-i-step为左循环移位的个数
    exchange(arr+i,j-i,j-i-step);
    i=i+step;
    }
}
void MergeSort(int *arr,int l,int r){
    if(l<r){
        int mid=(l+r)/2;
        MergeSort(arr,1,mid);
        MergeSort(arr,mid+1,r);
        Merge(arr,1,mid+1,r);
    }
}
int main(){
    int arr[]={6,4,3,1,7,8,2,9,5,0};
    int len=sizeof(arr)/sizeof(arr[0]);//
    MergeSort(arr,0,len-1);
    int i;
    for()cout<<
    return 0;
}
