#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

void swap(int& x,int& y){
    int tmp = x;
    x = y;
    y = tmp;
}
void BubbleSort(int A[],int n){
    int i,j,flag;
    for(i=0;i<n-1;i++){
        flag=false;//表示本趟冒泡是否发生交换的标志
        for(j=n-1;j>i;j--)
            if(A[j-1]>A[j]){
                swap(A[j-1],A[j]);
                flag=true;
             }
            if(flag==false)
                return ;//当返回为void可以这样使用
    }
}
void SelectSort(int A[],int n){
    int i,min,j;
    for(i=0;i<n-1;i++){//n-1)
        min = i;
        for(j=i+1;j<n;j++)//[i+1,n)
            if(A[j]<A[min]) min=j;
        if(min!=i) swap(A[i],A[min]);   
    }
}

void InsertSort(int A[],int n){
    int i,j;
    for(i=2;i<=n;i++)//2
        if(A[i]<A[i-1]){
            A[0] = A[i];
            for(j=i-1;A[0]<A[j];--j)//j=i-1
                A[j+1]=A[j];//j+1
            A[j+1] = A[0];//--j;j+1
        }
}

void ShellSort(int A[],int n,int len){
    int i,dk,j;
    for(dk=len/2;dk>=1;dk=dk/2)
        for(i=dk+1;i<=n;++i)//i=dk+1
            if(A[i]<A[i-dk]){
                A[0]=A[i];
                for(j=i-dk;j>0&&A[0]<A[j];j-=dk)//j=i-dk
                    A[j+dk]=A[j];//j+dk
                A[j+dk]=A[0];//j+dk
            }
}
int main(){
    int a[10]={0,6,5,2,4,9,7,8,3,1};
    int b[10]={0,6,5,2,4,9,7,8,3,1};
    SelectSort(a,10);
    InsertSort(b,9);
    ShellSort(b,9,9);
    int i;
    for (i=0;i<10;i++) cout<<a[i]<<":"<<b[i]<<endl;
    return 0;
}
