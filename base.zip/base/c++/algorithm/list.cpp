#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

typedef struct Item{
    char data;
    Item *next;
}Node;

Node* reverse_1(Node* head){
    Node* prev = NULL,*cur = head;
    while(cur){//头插法逆序链表,3个指针，prev\cur\next
        Node* next = cur->next;
        cur->next = prev;
        prev = cur;
        cur = next;
    }
    return prev;
}

Node* reverse_2(Node* head){
    if(head == NULL)
        return NULL;
    Node *cur,*reverse_head,*temp;
    if(head->next == NULL)
        return head;
    else{
        cur = head;
        temp = head->next;//递归步
        reverse_head = reverse_2(temp);//递归形式反转单链表
        temp->next = cur;//改写置为NULL的next。你不能相信这里表面上的顺序
        cur->next = NULL;//递归。
    }
    return reverse_head;
}

bool isloop(Node* head){
    Node* n1 = head;
    Node* n2 = head;
    while(n2->next != NULL){
        n1 = n1->next;
        n2 = n2->next->next;//NULL->next = NULL;
        if(n1 == n2) return true;
    }
    if(n2->next == NULL)//考虑链表可能很长，故不能直接用判断指针是否最后到NULL来判断是否有环。
        return false;
}

Node* Findbegining(Node* head){
    Node* n1 = head;
    Node* n2 = head;
    while(n2->next != NULL){
        n1 = n1->next;
        n2 = n2->next->next;
        if(n1 == n2) break;
    }
    if(n2->next == NULL)
        return NULL;
    n1 = head;
    while(n1 != n2){
        n1 = n1->next;
        n2 = n2->next;
    }
    return n2;
}

typedef struct ComplexNode{
    int m_nValue; //数据字段
    struct ComplexNode* m_pNext;//指向链表下一元素
    struct ComplexNode* m_pSibling;//指向链表中某任意位置的元素（可以是自己）的指针
}CNode;

void Clonenodes(CNode* pHead){
    CNode* pNode = pHead;
    while(pNode != NULL){
        CNode * pCloned = new CNode();//注意！
        pCloned->m_nValue = pNode->m_nValue;
        pCloned->m_pNext = pNode->m_pNext;
        pCloned->m_pSibling = NULL;
        pNode->m_pNext = pCloned;//1
        pNode = pCloned->m_pNext;//2
    }
}

void ConnectSiblingNodes(CNode* pHead){
    CNode* pNode = pHead;
    while(pNode != NULL){
        CNode* pCloned = pNode->m_pNext;
        if(pNode->m_pSibling != NULL)
            pCloned->m_pSibling = pNode->m_pSibling->m_pNext;
        pNode = pCloned->m_pNext;
    }
}

int main(){
    Node* x,
    d = {'d',NULL},
    c = {'c',&d},
    b = {'b',&c},
    a = {'a',&b};
    x=reverse_1(&a);
    x=reverse_2(x);
    Node* y,
    D = {'d',NULL},//此处D的类型并非指针
    C = {'c',&D},
    B = {'b',&C},
    A = {'a',&B};
    //&D->next = &B;
    //D = {'d',&B};//编译器告诉你延迟初始化话仅仅在C++0x标准或gnu++ox标准中使用
    D.next = &B;//我去指针还可以这么用。。。
    y = &A;
    if(isloop(y))
        y = Findbegining(y);
    return 0;
}
