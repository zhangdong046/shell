#include<iostream>
#include<vector>
using namespace std;

static int count;
static int target;
const int coin[4] = {1,2,5,10};
static int total;
vector<int> solution;

void dfs(int index){
    if(total == target){
        count++;
        cout<<count<<":";
        int i;
        for(i=0;i<(int)solution.size();i++){
            cout<<solution[i]<<" ";
        }
        cout<<endl;
        return;
    }
    if(total > target)
        return;
    int i;//上一个i只存在于那个if循环中，如果此处不再次定义一个i，后续的i是not declared的。
    for(i=index;i<4;i++){
        total+=coin[i];//1
        solution.push_back(coin[i]);//2
        dfs(i);//dfs[i];如此低级的错误//warning: pointer to a function used in arithmetic
        solution.pop_back();//2
        total-= coin[i];//1//-=必须紧密相连
    }
}
int main(){
    count = 0;
    cout<<"请输入一个大于0的整数："<<endl;
    cin>>target;
    dfs(0);
    cout<<"共有"<<count<<"种组合！"<<endl;
    return 0;
}


