#include<iostream>
using namespace std;

static int MAXS = 0xf66666;//6位16进制，32位4byte

void reverse(int* left,int len){
    int* right =left + len -1;
    if((left == NULL)&&(right == NULL)) return;
    int tmp;
    while(left<right){
        tmp = *left;
        *left = *right;
        *right = tmp;
        left++;
        right--;
    } 
}
int uppermax(int* array,int len){
    return 2*len;
}
int lowermin(int* array,int len){
    int i,ret = 0;
    for(i=0;i<len-1;i++){
        int flag = array[i] - array[i+1];
        if(flag == 1||flag == -1){
        }else{
            ret++;
        }
    }
    return ret;
}
int judge(int* array,int len){
    int i,ret=0;
    for(i=0;i<len-1;i++){
        if((array[i]-array[i+1]) != -1)
            ret = 1;
    }
    return ret;
}

void sortcount(int* array,int T,int n){
    int len = T+lowermin(array,n);
    if(len>MAXS) return;
    int ret = judge(array,n);
    if(ret == 0){
        if(T<MAXS)
            MAXS = T;
            return;
    }else{
        int i;
        for(i=2;i<=n;i++){
            reverse(array,i);
            sortcount(array,T+1,n);
            reverse(array,i);
        }
    }
}
int main(){
    int n=0;
    cout<<"请输入数组长度"<<endl;
    while((cin>>n)&&n!=0){
        int array[100]={0};
        int i;
        for(i=0;i<n;i++){
            cout<<"请输入第"<<i+1<<"个元素:";
            cin>>array[i];
        }
        MAXS = uppermax(array,n);
        sortcount(array,0,n);
        cout<<MAXS;
    }
    return 0;
}
