#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;

typedef int ElemType;

int Partition(ElemType A[],int low,int high){
    ElemType pivot = A[low];
    while(low<high){
        while(low<high&&A[high]>=pivot) --high;
        A[low] = A[high];//1//3..
        while(low<high&&A[low]<= pivot) ++low;
        A[high] = A[low];//2//4...
    }
    A[low] = pivot;
    return low;
}//堆排序优于快排的原因：常考

void QuickSort(ElemType A[],int low,int high){
    if(low<high){
        int pivotpos = Partition(A,low,high);
        QuickSort(A,low,pivotpos-1);
        QuickSort(A,pivotpos+1,high);
    }   
}
//建立最大堆的时候注意A[0]中不存储元素，实际储存从A[1]开始。
void AdjustDown(ElemType A[],int k,int len){
    A[0] = A[k];
    int i;
    for(i=2*k;i<=len;i*=2){//！！！！！！！！腾讯二面后端研发时候你写的i=k开头。。。根本没按照原理，而是照着回忆来的！！！！！！！！！
        if(i<len&&A[i]<A[i+1])//！！！！！！！！！！！！腾讯后端研发二面你漏写了i<len！！！！！！！！！！！！！！
            i++;
        if(A[0]>=A[i]) break;
        else{
            A[k] = A[i];//注意for循环中的i=2*k，注意下一步中的k=i。此步的作用是把子结点的值赋值给父节点。
            k=i;//！！！！！！！！！腾讯后端研发二面你这里写错了！！！！！！！！！！！！！！学那么多东西，现在让你写个插入排序你都不一定能写对，要你何用！！
        }
    }
    A[k] = A[0];
}//堆顶元素的删除操作需要向下调整

void BuildMaxHeap(ElemType A[],int len){
    for(int i=len/2;i>0;i--)//！！！！！！！！！！！！腾讯研发面试你竟然写反了i的递变顺序，mbd.！！！！！！！！！！！！！！！！
        AdjustDown(A,i,len);
}//O(n）

void HeapSort(ElemType A[],int len){
    BuildMaxHeap(A,len);//初始建堆//!!!!!!!!!!!!!!!!!!腾讯研发面试你竟然漏写了堆的创建!!!!!!!!!!!!!!!!!!!!!!!!!所谓的眼高手低就是说我的，不把基础努力学好，一知半解，整天净想着搞高大上的难题，终于，自吞苦果。
    int i;
    for(i=len;i>1;i--){//!!!!!!!!!!!这里不是len到0!!!!!!!!!!!!!!!!!麻痹，一个笔试题你做成啥样子了!!!!!!!!!!!!!!!!!!!!!!!!
        swap(A[i],A[1]);//输出堆顶元素（和堆底元素交换）
        AdjustDown(A,1,i-1);//整理，把剩余的i-1个元素整理成堆
    }
}//O(nlog2n)

void swap(ElemType& x,ElemType& y){
    ElemType tmp;
    tmp = x;
    x = y;
    y = tmp;
}

void AdjustUp(ElemType A[],int k){
    A[0] = A[k];
    int i = k/2;//若结点值大于双亲结点，则将双亲结点向下调，并继续向上比较
    while(i>0&&A[i]<A[0]){
        A[k]=A[i];//把父结点的值赋给子结点。
        k=i;//这一步相当传神
        i=k/2;//还有这一步，在向下调整的时候是在for循环中的。
    }
    A[k] = A[0];
}//堆元素的插入操作需要向上调整

ElemType *B =(ElemType*)malloc((101)*sizeof(ElemType));

void Merge(ElemType A[],int low,int mid,int high){
    int k;
    for(k=low;k<=high;k++)
        B[k] = A[k];
    int i,j;
    for(i=low,j=mid+1,k=i;i<=mid&&j<=high;k++){
        if(B[i]<B[j])
            A[k]=B[i++];
        else
            A[k]=B[j++];
    }
    while(i<=mid) A[k++] = B[i++];
    while(j<=mid) A[k++] = B[j++];
}

void MergeSort(ElemType A[],int low,int high){
    if(low<high){
        int mid=(low+high)/2;
        MergeSort(A,low,mid);
        MergeSort(A,mid+1,high);
        Merge(A,low,mid,high);
    }
}//每一趟归并排序的时间复杂度是O（n）,共需进行log2n向上取整次归并。稳定的排序算法。

typedef struct linklist{
    ElemType data;
    struct linklist *next;
    linklist(int x = 0,struct linklist*y = NULL):data(x),next(y){} 
}Node;

Node* mergeList(Node* list1,Node* list2)
{
    if(list1 == NULL)
        return list2;
    else if(list2 == NULL)
        return list1;
    Node* pHead=NULL;
    if(list1->data<list2->data){
        pHead = list1;
        pHead->next = mergeList(list1->next,list2);
    }else{
        pHead = list2;
        pHead->next = mergeList(list1,list2->next);
    }
    return pHead;
}

int main(){
    ElemType a[10]={4,6,2,7,12,6,8,9,1};
    QuickSort(a,0,9);
    int i;
    for(i=0;i<10;i++) cout<<a[i]<<":";
    ElemType b[10]={0,6,2,7,12,6,8,9,1,3};
    HeapSort(b,9);
    for(i=1;i<10;i++) cout<<b[i]<<"|";
    ElemType c[10]={0,6,2,7,12,6,8,9,1,3};
    MergeSort(c,0,9);
    for(i=0;i<10;i++) cout<<c[i]<<";";
    int arr[10] ={1,6,2,7,8,9,3,4,5,10};
    int brr[4] = {0,1,6,2};//从arr中依次读入3个数，第一个数存放在brr[1]中
    BuildMaxHeap(brr,3);
    for(i=3;i<10;i++){
        if(arr[i]>brr[1]) continue;
        else{
            brr[1]=arr[i];
            AdjustDown(brr,1,3);
        }
    }//利用大顶堆可以输出n个数中最小的m个。
//当需要求最大的k个数时，只需将大根堆改为小根堆即可，原理一样。
    cout<<brr[1]<<brr[2]<<brr[3]<<endl;
    return 0;
}
