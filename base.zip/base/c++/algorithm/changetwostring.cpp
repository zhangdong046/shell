/*唯品会笔试的这道算法题：我不该犯那么低级的错误，唉！
  下面状态转移方程第一个不是min(f[i+1,j],f[i,j+1]);第二个你漏掉了f[i+1,j+1]+1;怎么可以犯这么低级的错误。
   

1、一步操作后，再将A[2,...,lenA]和B[1,...,lenB]变成相等字符串。
2、一步操作后，再将A[2,...,lenA]和B[2,...,lenB]变成相等字符串。
3、一步操作后，再将A[1,...,lenA]和B[2,...,lenB]变成相等字符串。
设f[i][j]表示strA[i,lenA]与strB[j,lenB]的最小距离，则问题的描述为：、
           |f[i+1,j+1]        strA[i] == strB[j]
    f[i,j]=|
           |min{ f[i+1,j]+1, f[i,j+1]+1, f[i+1,j+1]+1}     其他
*/
#include<iostream>
#include<cstdio>
#include<string>
#include<cstdlib>
using namespace std;

int minValue(const int x,const int y,const int z){
    return (x<y)?((x<z)?x:z):((y<z)?y:z);
}

int calculateStringDistance(string strA,string strB){
    int lenA = strA.length();
    int lenB = strB.length();
    int** c = new int*[lenA+1];
    int i;
    for(i=0;i<lenA+1;i++)
        c[i]=new int[lenB+1];
    for(i=0;i<lenA;i++)
        c[i][lenB] = lenA - i;
    for(i=0;i<lenB;i++)
        c[lenA][i] = lenB - i;
    c[lenA][lenB] = 0;
    int j;
    for(i=lenA-1;i>=0;i--)
        for(j=lenB-1;j>=0;j--){
            if(strB[j] == strA[i])
                c[i][j] = c[i+1][j+1];
            else
                c[i][j] = minValue(c[i][j+1],c[i+1][j],c[i+1][j+1])+1;
        }
    int dis = c[0][0];
    for(int i=0;i<lenA+1;++i)
        delete []c[i];
    delete []c;
    return dis;//局部变量可以返回，又不是返回局部指针。。。
}

int main(){
    string A("asdfgs");
    string B("ddfgaa");
    int ret=calculateStringDistance(A,B);
    cout<<ret<<endl;
    return 0;
}

