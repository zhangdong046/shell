#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<math.h>
using namespace std;
static int c[100][100];

int max(const int& x,const int& y){
    return (x>=y)?x:y;
}

int LCS_LENGTH(const char* X,const char* Y/*,int* c*/){
    if(X == NULL|| Y == NULL)
         return 0;
    int m = strlen(X);
    int n = strlen(Y);
    int i,j;
    for(i=1;i<m;++i)
        c[i][0] = 0;
    for(i=1;i<n;++i)
        c[0][i] = 0;
    c[0][0] = 0;
    for(i=1;i<=m;++i)//=知道c[m][n]数组元素代表的意义，i或者j为0是无意义的。
        for(j=1;j<=n;++j){//=
            if(X[i] == Y[j])
                c[i][j] = c[i-1][j-1] + 1;
            else
                c[i][j] = max(c[i][j-1],c[i-1][j]);
        }
    return c[m][n];
}
int main(){
    /*int** c =new int* [100];
    int i;
    for(i=0;i<100;i++)
        c[i] = new int [100];*/
    const char* X = "abcdefgh";
    const char* Y = "cdacgkl";
    int length = LCS_LENGTH(X,Y/*,&c[0][0]*/);
    printf("最长公共子字符串长度是：%d\n",length);//注意此处不要写成/n.
   /* for(i=0;i<100;++i)
        delete []c[i];
    delete []c;*/
    return 0;     
}
