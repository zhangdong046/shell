#include<iostream>
using namespace std;
void swap(int& x,int& y){
    int tmp;
    tmp = x;
    x = y;
    y = tmp;
}

bool judge(const int* a,int num)
{
    int s =0;
    int i;
    for(i = 0;i <= num;i++)
        s = a[i] +s*10;
    if(s%num == 0)
        return true;
    else
        return false;
}

void trace(int *a,int T){
    if(T == 9)
        cout<<a[1]<<a[2]<<a[3]<<a[4]<<a[5]<<a[6]<<a[7]<<a[8]<<a[9]<<endl;
    int i;
    for(i = T;i<=9;i++){
        swap(a[T],a[i]);
        if((T<9)&&judge(a,T))//此处，外层括号必须加上
            trace(a,T+1);
        swap(a[T],a[i]);
    }
}
int main(){
    int* a = new int[10];
    int i;
    for(i=1;i<=9;i++)
        a[i] = i;
    trace(a,1);
    delete []a;
    return 0;
}
/*
封装：
1、使用类；
2、通过文件：比如c和c++支持对头文件的包含（#include）.因此，可以把一些相关的常量定义，类型定义，函数声明，统统封装到某个头文件中。
3、通过namespace/package/module：c++的namespace,java的package,python的module.
*/
/*
c++中的struct其实和class意义一样，唯一的不同是struct里面默认的访问控制是public,class中默认的访问控制是private.
c++中存在struct关键字的唯一意义是为了让c程序员有个归属感，是为了让c++编译器兼容以前用c开发的项目。
*/
/*
虚函数采用一种虚调用的方法。虚调用是一种可以在只有部分信息的情况下工作的机制，特别允许我们调用一个只知道接口，而不知道其准确类型的函数。
但是如果创建一个对象，你势必要知道对象的准确类型，因此构造函数不能为虚。
*/
//析构函数可以是内联函数。
