#include<iostream>
#include<vector>
using namespace std;
const int N = 4;
int point[N] = {0};
int visited[N] = {0};
int edge[][N]={{0,1,1,1},{1,0,1,1},{1,1,0,1},{1,1,1,0}};
typedef struct circles{
    int len;
    int flag;
    int arr[10];
}circle;
void dfs(int depth,int vetex,vector<circle>& array){
    int i;
    for(i = 0;i<4;i++){
        if(edge[vetex][i] == 1){
            if(visited[i] == 0){
                visited[i] = 1;
                point[depth] = i;
                dfs(depth+1,i,array);
                visited[i] = 0;
            }else{
                int j = 0;
                for(j=0;i<depth;j++)
                    if(point[j] == i) break;
                int tmp = 0;
                circle temp;
                int k;
                for(k=0;k<10;k++)
                    temp.arr[k] = 0;
                if(depth-j>2){
                    for(;j<depth;j++){
                        temp.arr[point[j]] = 1;
                        tmp = tmp*10+point[j];
                    }
                    temp.arr[i] = 1;
                    tmp = tmp*10 + i;
                    temp.len = tmp;
                    temp.flag = 0;
                    array.push_back(temp);
                }
             }
        }
    }
}
void distinct(vector<circle>&array){
    int length = array.size();
    int i;
    for(i=0;i<length-1;i++){
        if(array[i].flag == 0){
            int j;
            for(j=i+1;j<length;j++){
                int k,index = 0;
                for(k = 0;k<=9;k++)
                    if(array[i].arr[k] != array[j].arr[k]) index = 1;
                if(index == 0)
                    array[j].flag = 1;
            }
        }
    }
}
void printout(vector<circle>&array){
    int length = array.size();
    int i;
    for(i=0;i<length;i++){
        if(array[i].flag == 0)
        {
            int tmp = array[i].len%10;
            if(tmp == 0)
                cout<<tmp<<array[i].len<<endl;
            else
                cout<<array[i].len<<endl;
        }
    }
}
int main(){
    vector<circle> array;
    visited[0] = 1;
    point[0] = 0;
    dfs(1,0,array);
    distinct(array);
    printout(array);
    return 0;
}
