#include<iostream>
#include<string>//
#include<vector>
using namespace std;

pair<int,string> fun(const string& str){
    vector<string> substrs;
    int maxcount = 0,count = 1;
    string substr;
    int i,len = str.length();
    for(i=0;i<len;++i)
        substrs.push_back(str.substr(i,len-i));//向量的使用
    for(i=0;i<len;++i){
        for(int j=i+1;j<len;++j){
            count = 1;
            if(substrs[i].substr(0,j-i) == substrs[j].substr(0,j-i)){
                ++count;
                for(int k = j+(j-i);k<len;k+=j-i){
                    if(substrs[i].substr(0,j-i) == substrs[k].substr(0,j-i)) ++count;
                    else break;
                }
                if(count > maxcount){
                    maxcount = count;
                    substr =substrs[i].substr(0,j-i);
                }
            }
        }
    }
    return make_pair(maxcount,substr);//make_pair的使用
}
int main(){
    string str;//string类的使用
    pair<int,string> rs;
    while(cin>>str){
        if(str.length() == 1) break;
        rs = fun(str);
        cout<<rs.second<<':'<<rs.first<<'\n';
    }
    return 0;
}
