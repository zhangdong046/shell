#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

typedef struct student{
    int data;
    struct student *next;
    struct student *pre;
}dnode;

dnode* creat(){
    dnode *head,*p,*s;
    int x,cycle = 1;
    head = (dnode*)malloc(sizeof(dnode));//首先申请一个空结点，以便处理边界问题。
    p = head;
    while(cycle){
        printf("\nplease input the data:");
        scanf("%d",&x);
        if(x!=0){
            s = (dnode*)malloc(sizeof(dnode));
            s->data = x;
            printf("\n %d",s->data);
            p->next = s;
            s->pre = p;
            p = s;
        }
        else cycle = 0;
    }
    s = head;
    head = head->next;
    free(s);
    head->pre = NULL;//
    p->next = NULL;
    printf("yyy %d\n",head->data);
    return head;
}


dnode* del(dnode* head,int num){
    dnode *p1,*p2;
    p1 = head;
    while(num!=p1->data&&p1->next!=NULL)//双层4分支
        p1 =p1->next;
    if(num == p1->data){
        if(p1 == head){
            head = head->next;
            head->pre = NULL;
            free(p1);
        }
        else if(p1->next == NULL){
            p1->pre->next = NULL;
            free(p1);//多出的分支
        }else{
            p1->next->pre = p1->pre;
            p1->pre->next = p1->next;
        }
    }else{
        printf("\n%d could not been found",num);
    }
    return head;
}

dnode* insert(dnode *head,int num){
    dnode *p0,*p1;
    p1 = head;
    p0 = (dnode*)malloc(sizeof(dnode));
    p0->data = num;
    while(p0->data>p1->data&&p1->next!=NULL)
        p1 = p1->next;
    if(p0->data<=p1->data){
        if(head == p1){
            p0->next = p1;
            p1->pre = p0;
            head = p0;
        }else{
            p1->pre->next = p0;//后前
            p0->next = p1;
            p0->pre = p1->pre;
            p1->pre = p0;
        }
    }else{
        p1->next = p0;
        p0->pre = p1;
        p0->next = NULL;//后面没有对应head的tail指针
    }
    return head;
}
int main(){
    dnode *head,*p;
    int n,del_num,insert_num;
    cout<<"del_num:";
    insert_num=del_num = 0;
    cin>>del_num;
    cout<<"insert_num:";
    cin>>insert_num;
    head = creat();
    head = del(head,del_num);
    head = insert(head,insert_num);
    p = head;
    while(p!=NULL){
        cout<<p->data;
        p = p->next;
    }
    return 0;
}
