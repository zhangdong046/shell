#include<iostream>
using namespace std;

const char* _strstr(const char* string,const char* strCharSet){
    for(int i=0;string[i]!='\0';i++){
        int j = 0;
        int temp = i;
        if(string[i] == strCharSet[j]){
            while(string[i++] == strCharSet[j++]){//
                if(strCharSet[j] == '\0')
                    return &string[i-j];
            }
            i = temp;
        }
    }
    return NULL;//
}
int main(){
    const char* string = "1432354345345";
    cout<<string<<endl;
    char strCharSet[10] = {};//!
    cin>>strCharSet;//还可以这样使用？
    cout<<_strstr(string,strCharSet)<<endl;//普通函数指针可以传参给常指针参数类型
    return 0;
}
