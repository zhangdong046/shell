#include<iostream>
#include<cstdlib>
#include<cstdio>
using namespace std;

#define ERROR 0

typedef struct LNode{
    int data;
    struct LNode *link;
}LNode,*LinkList;//!

void JOSEPHUS(int n,int k,int m){
//n为总人数，k为第一个开始报数的人，m为出列者喊到的数。
    /*p为当前节点，r为辅助结点，指向p的前驱节点，list为头节点*/
    LinkList p,r,list,curr;
    /*建立循环链表*/
    p = (LinkList)malloc(sizeof(LNode));//
    p->data = 0;
    p->link = p;//初始化
    curr = p;
    for(int i=1;i<n;i++){
        LinkList t = (LinkList)malloc(sizeof(LNode));
        t->data = i;
        t->link = curr->link;
        curr->link = t;
        curr = t;
    }
    r = curr;
    while(k--) r=p,p=p->link;//把当前指针移动到第一个报数的人，r为p的前驱。
    while(n--){
        for(int s =m-1;s--;r=p,p=p->link);//s--条件处的使用
        r->link = p->link;
        printf("%d->",p->data);
        free(p);
        p=r->link;
    }
}
int main(){
    JOSEPHUS(13,4,1);
    cout<<endl;
    JOSEPHUS(100,3,8);
    return 0;
}
