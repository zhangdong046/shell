#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
typedef struct student{
    int data;
    struct student *next;
}node;

typedef struct linkqueue{
    node *first,*rear;
}queue;

queue* insert(queue *HQ,int x){
    node* s;
    s = (node*)malloc(sizeof(node));
    s->data = x;
    s->next = NULL;
    if(HQ->rear == NULL){
        HQ->first = s;
        HQ->rear = s;
    }else{
        HQ->rear->next = s;
        HQ->rear = s;
    }
    return HQ;
}

queue* del(queue* HQ){
    node *p;
    int x;
    if(HQ->first == NULL){
        printf("\n null&&empty");
    }else{
        x=HQ->first->data;
        p = HQ->first;
        if(HQ->first == HQ->rear){
            HQ->first = NULL;
            HQ->rear = NULL;
        }else{
            HQ->first = HQ->first->next;
            free(p);
        }
    return HQ;
    }
}

typedef struct stackqueue{
    node* top;
    node* head;//必须的标记链表的头节点
}stack;

stack *push(stack *HQ,int x){
    node *s,*p;
    s= (node*)malloc(sizeof(node));
    s->data = x;
    s->next = NULL;
    if(HQ->head == NULL){
        HQ->top = s;
        HQ->head = s;
    }else{
        HQ->top->next = s;
        HQ->top = s; 
    }
    return HQ;
}

int pop(stack *HQ){
    node* p;
    int x;
    if(HQ->head == NULL){
        printf("\nnull&&empty");
    }else{
        x= HQ->top->data;
        p = HQ->head;
        if(HQ->top==HQ->head){
            HQ->head = NULL;
            HQ->top = NULL;
        }else{
            while(p->next!=HQ->top){
                p = p->next;
            }
            HQ->top = p;
            HQ->top->next = NULL;
        }
    return x;
    }
}
int main(){
    queue *s;
    s->first =s->rear=NULL;
    s = insert(s,5);
    s = del(s);
    //stack *t;如果是栈上分配内存，未名原因错误：Segmentation fault.
    stack *t =(stack*)malloc(sizeof(stack));
    t->head = NULL;
    t->top = NULL;
    t = push(t,5);
    t = push(t,6);
    pop(t);
    printf("%d",t->top->data);
    free(t);
    return 0;
}
