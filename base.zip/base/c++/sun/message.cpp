#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

typedef struct TNode{
    char* pText;//直接指向文件映射的内存地址
    int dwCount;//计算器，记录此节点的相同短信数
    TNode* ChildNodes[256];//子节点数据，由于一个字母的ASCII值不可能超过256，所以子节点也不可能超过256.
    TNode(){}
    ~TNode(){}
}Node;

void CreateNode(Node *pNode,char* pText,int nIndex){
    if(pNode->ChildNodes[pText[nIndex]] == NULL){//如果是栈上分配的节点，这里读取子节点时候会失败？
        pNode->ChildNodes[pText[nIndex]] = new Node;
    }
    if(pText[nIndex+1] == '\0'){
        pNode->ChildNodes[pText[nIndex]]->dwCount++;
        pNode->ChildNodes[pText[nIndex]]->pText = pText;
    }else{
        CreateNode(pNode->ChildNodes[pText[nIndex]],pText,nIndex+1);
    }
}//这个函数的逻辑相当清晰简练。

Node* CreateRootNode(char** pTexts,int dwCount){
    Node* RootNode = new Node;//如果此处使用栈，则后续会出现Segmentation fault错误！！！一直没弄清楚原因。
    for(int dwIndex = 0;dwIndex<dwCount;dwIndex++){
        CreateNode(RootNode,pTexts[dwIndex],0);
    }
    cout<<RootNode->ChildNodes['a']->ChildNodes['b']->dwCount<<endl;
    return RootNode;
}

void del(Node *pNode){
    for(int i =0;i<256;++i){
        if(pNode->ChildNodes[i]!=NULL)
            del(pNode->ChildNodes[i]);
    }
    delete pNode;
}

int main(){
    char** message=new char*[2];//特别注意，指向指针的指针作为参数传递方法。
    int i,j;
    for(i =0;i<2;i++){
        message[i] = new char[3];
    }
    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            message[i][j] = '\0';
        }
    }
    message[0][0] = 'a';
    message[0][1] = 'b';
    message[1][0] = 'a';
    message[1][1] = 'b';
    Node* tmp = CreateRootNode(message,2);
    del(tmp);
    for(i=0;i<2;++i) delete []message[i];//!指向指针的指针的使用
    delete []message;//!!
    return 0;
}
