#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

class base{
private:
    int m_i;
    int m_j;
    //const int Size = 0;常量必须在构造函数的初始化列表里面初始化或者将其设置为static。
/*
正确使用如下：
1、class A{
    A(){
        const int Size = 0;
    }
};
2、class A{
    static const int Size = 9;//注意这个特例，其赋值规则不同于const与static.
}
*/
public:
    base(int i):m_j(i),m_i(m_j){}//初始化列表的初始化变量顺序是根据成员变量的声明顺序执行的，因此m_i会被赋予一个随机值。
    base():m_j(0),m_i(m_j){}
    int get_i(){return m_i;}
    int get_j(){return m_j;}
};

int main(int argc,char* argv[]){
    base obj(98);
    cout<<obj.get_i()<<endl<<obj.get_j()<<endl;
    return 0;
}
