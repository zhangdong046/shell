/*
1、如果Child类的构造函数在堆中分配了内存，而其析构函数又不是virtual类型的，那么撤销pBase时，将不会调用Child::~Child(),从而不会释放Child::Child()占据的内存，造成内存泄漏。
2、将Object的析构函数设为virtual型，则所有Object类的派生类的析构函数都将自动变为virtual型，这保证了任何情况下，不会出现析构函数未被调用而导致内存泄漏。
3、虚函数采用一种虚调用的方法，虚调用是一种可以在只有部分信息的情况下工作的机制，特别允许我们调用一个只知道接口而不知道其准确对象类型的函数。
4、但是如果要创建一个对象，你势必要知道对象的准确类型，因此构造函数不能为虚。
5、如果仅是一个很小的类，且不想派生其他类，那么根本没必要使用虚函数。
6、析构函数可以是内联函数：inline A::~A(){}.
7、B temp = class(5);形参类型是个类，而5是个常量，这样合法。
    7.1、单个参数的构造函数如果不添加explicit关键字，会定义一个隐含的类型转换（从参数类型转换到自己）;添加explicit关键字会消除这种隐含转换。
*/
//如果类中已经包含了需要深拷贝的字符指针，则应编写拷贝构造函数和赋值函数。
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
class NamedStr{
    public:
    NamedStr(){
        static const char s_szDefaultName[] = "Default name";//
        static const char s_szDefaultStr[] = "Default string";
        m_pName = new char[strlen(s_szDefaultName)+1];
        m_pData = new char[strlen(s_szDefaultStr)+1];
        strcpy(m_pName,s_szDefaultName);
        strcpy(m_pData,s_szDefaultStr);
    }
    NamedStr(const char *pName,const char *pData){
        m_pName = new char[strlen(pName)+1];
        m_pData = new char[strlen(pData)+1];
        strcpy(m_pName,pName);
        strcpy(m_pData,pData);
    }
    ~NamedStr(){
        delete[] m_pName;
        delete[] m_pData;
    }
    void print(){
        cout<<"Name:"<<m_pName<<endl;
        cout<<"String:"<<m_pData<<endl;
    }
    private:
    char* m_pName;
    char *m_pData;
};

int main(int argc,char* argv[]){
    NamedStr *pDefNss = NULL;
    try{
        pDefNss = new NamedStr[10];
        NamedStr ns("Kingsoft string","This is for test.");
        ns.print();
    }catch(...){//
        cout<<"Exception!"<<endl;
    }
    delete []pDefNss;
    return 0;
}
/*
虚函数重写与函数重载的区别：
1、虚函数总是在派生类中被改写，这种改写为override,它指派生类重写基类的虚函数，重写的函数必须有一致的参数表和返回值。
2、overload约定理解为重载，指编写一个与已有函数同名但参数表不同的函数。
*/
