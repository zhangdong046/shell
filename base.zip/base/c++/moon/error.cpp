#include<iostream>
#include<cstdio>
using namespace std;

struct Test{
    Test(int){}
    Test(){}
    void fun(){}
};
class Cat
{
public:
    Cat(int age):itsAge(age){
        HowManyCats++;
    }
    virtual ~Cat(){HowManyCats--;}
    virtual int GetAge(){
        return itsAge;
    }
    virtual void SetAge(int age){
        itsAge = age;
    }
    static int GetHowMany(){
        return HowManyCats;
    }//静态成员变量私有时候，可以通过公有静态成员函数访问
private:
    int itsAge;
    static int HowManyCats;
};

int Cat::HowManyCats = 0;//静态成员变量赋初值
void tele();

int main(){
    Test a(1);
    a.fun();
    Test b();//不要与Test b = new Test();弄混淆了。
   // b.fun(); 上一句Test b();这个语法等同于声明了一个函数，函数名为b，返回值为Test,传入参数为空，但是这个错误编译时候检查不出，但是本句是无法编译通过的。
    Cat c(1);
    Cat d(2);
    d.SetAge(3);
    Cat* e = new Cat(4);//Cat e = new Cat(4);使用new运算符得到的是一个指针地址，而不是该类型的一个变量，这么基础的地方，不要再错了好不？
    int i = d.GetAge();
    int j = d.GetHowMany();
    printf("%d,%d",i,j);
    const int MaxCats = 5;
    Cat* CatHouse[MaxCats];//
    for(i=0;i<MaxCats;i++){
        CatHouse[i] = new Cat(i);
        tele();
    }
    for(i=0;i<MaxCats;i++){
        delete CatHouse[i];
        tele();
    }
    delete e;
    return 0;
}
void tele(){
    cout<<"There are "<<Cat::GetHowMany()<<" Cats alive!\n";
}
