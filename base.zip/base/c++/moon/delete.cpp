#include<iostream>
#include<cstdlib>
#include<vector>
#include<cstring>
using namespace std;
class CDemo{
public:
    CDemo():str(NULL){}
    ~CDemo(){
        if(str){
            static int i = 0;
            cout<<"&CDemo"<<i++<<"="<<(int*)this<<",str="<<(int*)str<<endl;
            delete []str;
        }
    }
    char* str;
};
int main(int argc,char** argv){
    CDemo d1;
    d1.str = new char[32];
    strcpy(d1.str,"trend micro");
    vector<CDemo>*a1 = new vector<CDemo>();
    a1->push_back(d1);//默认拷贝构造函数
    delete a1;//发生了CDemo类的两次析构，两次析构str所指向的同一内存地址空间。
/*
1、有人认为，vector对象指针能够自动析构，所以不需要调用delete a1,这样理解不准确。
    1.1、任何对象如果通过new操作符申请了空间，必须显式的调用delete来销毁这个对象，所以delete a1；这条语句是没有错误的。
    1.2、但必须明白一点，释放vector对象，vector所包含的元素也同时被释放。
2、vector<CDemo>* a1 = new vector<CDemo>(); 说明a1所含元素是CDemo类型的。
    2.1、在执行a1->push_back(d1);这条语句时，会调用CDemo的拷贝构造函数（虽然CDemo类中没有定义拷贝构造函数，但是编译器会为CDemo类构造一个默认的拷贝构造函数，浅拷贝）
    2.2、正是这里出了问题，a1中所有CDemo元素的str成员变量没有初始化，只有一个四字节（32位机）指针空间。
    2.3、a1->pushback(d1);这句话执行完后，a1里的CDemo元素与d1是不同的对象，但是a1里CDemo元素的str与d1.str指向的是同一块内存。
3、我们知道，局部变量，如CDemo d1；在main函数退出时，自动释放所占用的空间，那么会调用CDemo的析构函数~CDemo，问题就出在这里。
    3.1、前面的delete a1；已经把d1.str释放掉了（因为a1里面的CDemo元素的str与d1.str指向的是同一块内存），main函数退出时，又要释放已经释放的d1.str的内存空间，所以程序最后崩溃
    3.2、因为没有显式的delete d1.str,故程序结束时会自动析构。
*/
    return 0;
}
/*
在CDemo类中添加拷贝构造函数就可以解决深拷贝和浅拷贝的问题。
CDemo(const CDemo &cd){
    this->str = new char[strlen(cd.str)+1];
    strcpy(str,cd.str);
}
*/

