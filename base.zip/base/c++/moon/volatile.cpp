/*
1、volatile修饰符的主要目的是提示编译器该对象的值可能在编译器未检测到的情况下被改变，因此编译器不能武断地对引用这些对象的代码做优化。
    1.1、优化器在用到这个变量时必须每次都很小心地重新读取这个变量的值，而不是使用保存在寄存器中的备份。
    1.2、并行设备的硬件寄存器（如状态寄存器）
    1.3、一个中断子程序中会访问到的非自动变量（Non-automatic variables）
    1.4、多线程应用中被几个任务共享的变量。
2、合理地使用关键字const可以使编译器很自然地保护那些不希望被改变的参数，防止其被无意的代码修改，这样可以减少bug的出现。
3、一个参数可以既是const又是volatile，一个例子就是只读的状态寄存器。它是volatile,因为它可能被意想不到地改变，它又是const,因为程序不应该试图去修改它。
4、一个指针可以是volatile，一个例子是当一个中断服务子程序修改了一个指向一个buffer的指针时。
错误示例：
int square(volatile int *ptr){
    return *ptr**ptr;
}
编译器将产生类似下面的代码：
int square(volatile int *ptr){
    int a,b;
    a=*ptr;
    b=*ptr;
    return *ptr**ptr;
}
由于*ptr的值可能被意想不到地改变，因此a和b可能是不同的，结果这段代码可能无法返回你所期望的平方值。
正确示例：
long square(volatile int *ptr){
    int a;
    a = *ptr;
    return a*a;
}
*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

int main(){
    int *ptr;
    ptr = (int*)0x67a9;
    //*ptr = 0xaa55;//要求设置一绝对地址为0x67a9的整型变量的值为0xaa66.
//虽然为了访问一个绝对地址把一个整型数强制转换为一个指针是合法的，但在g++编译器中，此处访问越界。
    unsigned int zero = 0;
    //unsigned int compzero = 0xFFFF;对于一个int型且不失16位的处理器来说，这样写是错误的。
    unsigned int compzero = ~0;
    char* ptr1;
    if((ptr1 = (char*)malloc(0)) == NULL)
        puts("Got a null pointer");
    else
        puts("Got a valid pointer");
    char* ptr2;
    if(int pp = (strlen(ptr2 = (char*)malloc(0))) == 0)
        puts("Got a null pointer");
    else
        puts("Got a valid pointer");
    return 0;
}
