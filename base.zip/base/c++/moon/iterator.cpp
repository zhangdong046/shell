#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
using namespace std;

void print(vector<int>);

int main(){
    vector<int> array;
    array.push_back(1);
    array.push_back(6);
    array.push_back(6);
    array.push_back(3);
//删除array数组中所有的6.
    vector<int>::iterator itor;
    vector<int>::iterator itor2;
    itor = array.begin();

    for(itor=array.begin();itor!=array.end();){
        if(6 == *itor){
            itor2 = itor;//itor2 = itor;这句说明两个迭代器是一样的，array.erase(itor2);等于array.erase(itor);
            array.erase(itor2);//这时指针已经指向下一个元素6了，itor++;又自增了，指向了下一个元素3,略过了第二个6.
        }
        itor++;
    }
    print(array);
    return 0;
}

void print(vector<int> v){
    cout<<"\nvector size is:"<<v.size()<<endl;
    vector<int>::iterator p = v.begin();
}
/*
1、可以使用itor--,再回到原来的位置上。
    for(itor=array.begin();itor!=array.end();itor++){
        if(6 == *itor){
            itor2=itor;
            array.erase(itor2);
            itor--;
        }
    }
2、使用vector模板里面的remove函数进行修改：
    array.erase(remove(array.begin(),array.end(),6),array.end());
    2.1、s.erase(p1,p2);删除s容器中[p1,p2)区间内的元素，返回最后一个被删除元素的下一个元素的迭代器。
    2.2、remove(array.begin(),array.end(),6);把符合条件的元素移到容器尾部，返回其第一个。
*/
