#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;

class ExceptionClass{
public:
    ExceptionClass(const char* name = "Exception Default Class"){
        cout<<"Exception Class Construct String"<<endl;
    }
    ~ExceptionClass(){
        cout<<"Exception Class Destruct String"<<endl;
    }
    void ReportError(){
        cout<<"Exception Class::this is report message"<<endl;
    }
};
class ArguClass{
    const char* name;
public:
    ArguClass(const char* name = "default name"){
        cout<<"Construct string::"<<name<<endl;
        this->name = name;//
    } 
    ~ArguClass(){
        cout<<"Destruct String::"<<name<<endl;
    }
    void mythrow(){
        throw ExceptionClass("my throw");//抛出自定义异常对象
    }
};
int main(){
    ArguClass e("haha");
    try{
         e.mythrow();
    }
    catch(int){
         cout<<"unknowen error!"<<endl;
    }
    catch(ExceptionClass pTest)//捕获异常对象
    {
        pTest.ReportError();
    }
    catch(...){
        cout<<"**********"<<endl;
    }
}//Exception 对象 一次构造，一次浅拷贝，两次析构。
/*
1、构造函数中抛出异常是有一定必要的。
    1.1、构造函数中有两次new操作，第一次成功了，返回了有效的内存，而第二次失败了，此时因为对象构造尚未完成，析构函数是不会调用的，异常程序可以将这样的内存泄漏暴露出来。
    1.2、Base(){
             int* p = new int();
             try{
                 int* q = new int();
             }catch(...){
                 delete p;
                 throw;
             }
         }
2、构造函数中遇到异常时不会调用析构函数的，一个对象的父对象的构造函数执行完毕，不能称之为构造完成，对象的构造是不能分割的，要么完全成功，要么完全失败。
    2.1、对于成员变量，c++遵循这样的规则，即从异常的发生点按照成员变量的初始化逆序释放成员。
    2.2、处理这样的问题，使用智能指针是最好的，这是因为auto_ptr成员是一个对象而不是指针：所以在c++中，资源泄漏的问题一般使用RAII（资源获取就是初始化）的办法，把需要打开/关闭的资源用简单的对象封装起来。
3、c++中通知对象构造失败的唯一方法，就是在构造函数中抛出异常。
4、对象的部分构造是很常见的，异常的发生点也是完全随机的，程序员要谨慎处理这种情况。
5、析构函数尽可能地不要抛出异常，有可能会处于无限的递归嵌套中。
6、构造函数从最初的基类开始构造，各个类的同名变量没有形成覆盖，都是单独的变量。
*/
