#include<iostream>
using namespace std;

class A{
public:
    void virtual f(){
        cout<<"A"<<endl;
    }
};

class B:public A{
public:
    void virtual f(){
        cout<<"B"<<endl;
    }
};

int main(){
    A* pa = new A();
    pa->f();
    B* pb = (B*)pa;
    pb->f();//A
//转化pa为B类型并新建一个指针pb，将pa复制到pb。pa的指针没有发生变化，所以pb也指向pa的f函数。这里不存在覆盖的问题。
    delete pa,pb;
    pa = new B();
    pa->f();
    pb = (B*)pa;
    pb->f();
    return 0;
}
//一个私有的或保护的派生类不是子类，因为非公共的派生类不能做基类能做的所有的事。
//含纯虚函数的抽象类不能实例化。
//如果p是指针，typeid(*p)返回p所指向的派生类类型，typeid(p)返回基类类型；如果r是引用，typeid(r)返回派生类类型，typeid(&r)返回基类类型。
//动态映射dynamic_cast<类型>(变量) 可以映射到中间级，将派生类映射到任何一个基类，然后在基类之间可以相互映射。
