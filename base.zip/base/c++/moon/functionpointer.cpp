#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
//一个函数在编译时被分配给一个入口地址，这个入口地址就成为函数的指针，正如指针是一个变量的地址一样。
//函数指针用途很广，最常用的用途之一是把指针作为参数传递到其他函数。
using namespace std;

template<class T>
class Operate{
public:
    static T Add(T a, T b){
        return a+b;
    }
    static T Mul(T a, T b){
        return a*b;
    }
    static T Judge(T a, T b=1){
        if(a>=0){
            return a;
        }else{
            return a/b;
        }
    }
};//静态类模板实现方法
//有些地方必须使用函数指针才能完成给定的任务，特别是异步操作的回调和其他需要匿名回调的结构。另外，像线程的执行和事件的处理，如果缺少了函数指针的支持也是很难完成的。
int jug(int x,int y){
    if(x>=0){
        return x;
    }else if(y == 0){
        return x;
    }else
        return x/y;
}

int sub(int x, int y){
    return (x+y);
}
int minus2(int x,int y){
    return (x-y);
}
void test(int (*p)(int,int),int a,int b){//函数指针
    int Int1;
    Int1 =(*p)(a,b);
    printf("a=%d,b=%d,%d\n",a,b,Int1);
}
int main(){
    int A,B,C,D,E,x,y,z;
    A=1,B=2,C=3,D=4,E=5;
    x=Operate<int>::Add(A,B);//这个类直接调用这个函数而不用实例化一个对象
    y=Operate<int>::Mul(C,D);
    z=Operate<int>::Judge(E,B);
    cout<<x<<'\n'<<y<<'\n'<<z<<endl;

    int a=1,b=2,c=3,d=4,e=-5;
    test(sub,a,b);
    test(minus2,c,d);
    test(jug,e,b);
    return 0;
}
