//键树又称为数字查找树（Digital Search Trees）。
/*
键的存储通常有两种方式：
1、用树的孩子-兄弟链来表示键树（成为双链树）：
    1.1、每个Node有三个域：symbol域，存储关键字的一个字符；son域：存储指向第一棵子树的根的指针；brother域：存储指向右兄弟的指针。
    1.2、在双链树种插入或删除一个关键字，相当于在树种某个结点上插入或删除一棵子树。
2、用多重链表表示（又称Trie树，字典树）
    2.1、如果以树的多重链表表示键树，则树的每个结点中应包含d个（d为关键字符的基，如：字符集由英文大写字母构成时，则d=26）指针域，此时的键树又称为Trie树。
    2.2、Trie树的思想是利用字符串的公共前缀来降低时空开销；
    2.3、Trie树的典型应用是用于统计和排序大量的字符串（但不仅限于字符串），所以经常被搜索引擎系统用于文本词频的统计；
    2.4、Trie树的优点是最大限度地减少无谓的字符串比较。
    2.5、Trie树的缺点是如果存在大量字符串且这些字符串基本没有公共前缀，则相应的Trie树将非常消耗内存。
*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
const int branchNum = 26;
typedef struct Trie_node{
    bool isStr;
    struct Trie_node *next[branchNum];
    Trie_node():isStr(false){
        int i;
        for(i=0;i<branchNum;i++)
            next[i]=NULL;
    }//memset(next,NULL,sizeof(next));}//warning: passing NULL to non-pointer argument 2 of ‘void* memset(void*, int, size_t)’ 
}Node;

class Trie{
public:
    Trie(){root = new Node();}//类中类的构造函数可以这样使用。
    ~Trie(){}
    void insert(const char* word);
    bool search(const char* word);
    void deleteTrie(Node* root);
    Node* getTrie(){return root;}
public:
    Node* root;
};

void Trie::insert(const char* word){
    Node* location=root;
    while(*word){
        if(location->next[*word-'a']==NULL){//不存在则建立一个新的结点
            Node* tmp = new Node();
            location->next[*word-'a'] = tmp;
        }
        location = location->next[*word-'a'];
        word++;
    }
    location->isStr = true;//到达尾部，标记一个串
}

bool Trie::search(const char* word){
    Node* location =root;
    while(*word&&location){
        location=location->next[*word-'a'];
        word++;
    }
    return (location != NULL&&location->isStr);
}

void Trie::deleteTrie(Node* root){
    int i;
    for(i=0;i<branchNum;i++)
        if(root->next[i]!=NULL)
            deleteTrie(root->next[i]);
        delete root;
}
int main(){
    Trie* A = new Trie();
    const char* str = "abcde";
    A->insert(str);
    if(A->search(str)) cout<<"find!"<<endl;
    const char*str1 = "abcd";
    const char*str2 = "abcdef";
    if(A->search(str1)||A->search(str2)) cout<<"find too!"<<endl;
    A->deleteTrie(A->root);
    return 0;
}
