#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<stack>
using namespace std;

template<class T>
class MyQueue{
    stack<T> s1,s2;
public:
    int size(){
        return s1.size()+s2.size();
    }
    bool empty(){
        if(size() == 0)
            return true;
        else
            return false;
    }
    void push(T value){
        s1.push(value);
    }
    T front(){//
        if(!s2.empty())
            return s2.top();
        while(!s1.empty()){
            s2.push(s1.top());
            s1.pop();
        }
        return s2.top();
    }
    void pop(){
        if(s2.empty()){
            while(!s1.empty()){
                s2.push(s1.top());
                s1.pop();
            }
        }
       s2.pop();
    }
};
int main(){
    MyQueue<int>* p =new MyQueue<int>();//易丢失的<int>
    return 0;
}
