/*
有一数组乱序存放数1到N,N最大为32000.数组中可能会有重复元素，如果只有4kB内存可用，如何发现并输出所有重复元素。
4KB意味着共有8*4*2^10bit,32*2^10>32000,故可使用bit-map来解决本问题。
*/
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>//memset
using namespace std;
#define BITWORD 32
#define SHIFT 5
#define MASK 0x1F

class BitSet{
    int* bitset;
public:
    BitSet(int size){
        bitset = new int[size/32+1];//数据成员。
        memset(bitset,0,sizeof(int)*(size/32+1));//我知道你很容易眼高手低。
    }
    void set(int i){
        bitset[i>>SHIFT]|=(1<<(i&MASK));
    }
    void clr(int i){
        bitset[i>>SHIFT]&=~(1<<(i&MASK));
    }
    int get(int i){
        return bitset[i>>SHIFT]&(1<<(i&MASK));
    }
    ~BitSet(){
        delete []bitset;
    }
};

void checkDuplicates(int* array,int length){
    BitSet bs(length);
    for(int i = 0;i<length;i++){
        int num = array[i];
        int num0 = num - 1;
        if(bs.get(num0)){
            cout<<num<<" ";
        }else{
            bs.set(num0);
        }
    }    
}

int main(void){
    int a[33]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,1};
    checkDuplicates(a,33);
    return 0;
}
