#include<iostream>
#include<vector>
/*
迭代器是用来遍历容器内所有元素的数据类型。一般提供两种类型：iterator和const_iterator。
每种容器都定义了一对命名为begin()和end()的函数，用来返回容器的迭代序列。其中begin()返回的迭代器指向第一个元素，end返回的迭代器指向最后一个元素的下一个位置(实际上是一个不存在的元素)，所以迭代序列为【begin(),end()）,那么begin()返回与end()一样的迭代器。
1、假如迭代器it指向容器的一个元素，那么解引用*it就是钙元素的值（注意： 不能对end()解引用）。
2、所有迭代器都支持前缀自增运算符，++it，表示把迭代器移到容器中的下一个元素的位（同样不能对end()运算）。
3、所有迭代器都支持前缀自增运算符，如++it,表示把迭代器移动到容器中的下一个元素的位。
*/
using namespace std;
/*
向量vector是一种对象实体，能够容纳许多其他类型相同的元素，因此又被称为容器。与string相同，vector同属于STL(Standard Template Library,标准模板库)中的一种自定义数据类型，是广义上数组的增强版。
vector容器与数组相比，其优点在于它能够根据需要随时自动调整自身的大小以便容下所要存放的元素。
*/
int main(){
    vector<int> a;
    vector<int> b(10);//声明一个初始大小为10的向量
    vector<int> c(10,1);//声明一个初始大小为10且初始值为1的向量
    vector<int> d(c);//声明并用向量c初始化向量d
//表示向量起始元素位置到起始元素+3之间的元素位置
    vector<int> e(c.begin(),c.begin()+3);//将c向量中从第0个到第2个（共3个）作为向量e的初始值。
    cout<<e.size()<<endl;
    int n[] = {1,2,3,4,5};
    vector<int> a1(n,n+5);//将数组n的前5个元素作为向量a1的初值
    vector<int> b1(&n[1],&n[4]);//将n[1]-n[4]范围内的元素作为向量a的初值。
//元素的输入和访问可以像操作数组那样，用cin>>进行输入，cout<<a[n]这样进行输出：
    cout<<"输入一个int数字";
    cin>>c[2];
    int i;
    for(i=0;i<c.size();i++)
        cout<<c[i]<<" ";
    vector<int>::iterator t;//迭代器,针对向量内存不连续，不能使用指针迭代。
    for(t=e.begin();t!=e.end();t++)
        cout<<*t<<"|";//类似指针，为指针的间接访问形式，意思是访问t所指向的元素值。
    if(b.empty()) cout<<b.size();//获取元素个数，判断空
    b.clear();//清空向量元素
    b=c;//复制。保持== != > <=的惯有意义，如a == b;向量a,b比较，相等则返回1。
    a.insert(a.begin(),1000);//将1000插入到向量a的起始位置前
    a.insert(a.begin()+1,3,2000);//将2000分别插入到向量元素位置的1~3处
    a.insert(a.begin(),b.begin(),b.end());//将b.begin().b.end()之间的全部元素插入到b.begin()前。
    cout<<"a的大小："<<a.size()<<endl;
    vector<int>::iterator s;
    for(s=a.begin();s!=a.end();s++)
        cout<<*s<<",";
    a.erase(a.begin());//将起始位置的元素删除
    a.erase(a.begin(),a.begin()+3);//将（a.begin(),a.begin()+3）之间的元素删除
    b.swap(a);//a向量与b向量进行交换
    cout<<"b的大小："<<b.size()<<endl;
//与数组相同，向量也可以增加维数
    vector< vector<int> > B(10,vector<int>(5,0));//创建一个10*5的int型二维向量
    cin>>B[1][1];
    cin>>B[2][2];
    cin>>B[3][3];
    int m,N;
    for(m=0;m<b.size();m++){
        for(N=0;N<B[m].size();N++)
            cout<<B[m][N]<<" ";
        cout<<"\n";
    }
    return 0;
}
/*
vecList.push_back(elem);      //将elem的一个拷贝插入至list的末尾
vec.pop_back();               //删除最后元素
vec.resize(num);              //将元素个数改为num,若size（）增加，默认的构造函数负责创建这些新元素。
vec.resize(num,elem);         //若size()增加，默认的构造函数将这些新元素初始化为elem.
vec.at(index);                //返回由index指定的位置上的元素
vec[index];                   //返回由index指定的位置上的元素
vec.front();                  //返回第一个元素（不检查容器是否为空）
vec.back();                   //返回最后一个元素（不检查容器是否为空）
vec.capacity();               //返回不重新分配空间可以插入到容器vec中的元素的最大个数
vec.size();                   //返回容器vec中当前的个数
vec.max_size();               //返回可以插入到容器vec中的元素的最大个数。
*/
/*
函数原型：
template<typename T>
    explicit vector();   //默认构造函数，vector对象为空//拒绝隐式类型转换
    explicit vector(size_type n,const T& v = T()); //创建有n个元素的vector对象
    vector(const vector& x);
    vector(const_iterator first,const_iterator last);
*/
//注意：vector容器内存放的所有对象都是经过初始化的。如果没有指定存储对象的初始值，那么对于内置类型将用0初始化。对于类类型将调用默认构造函数
//进行初始化（如果有其他构造函数而没有默认构造函数，那么此时必须提供元素初始值才能放入容器中）。
/*
bool empty() const;
size_type max_size() const;  //返回容器能容纳的最大元素格式
size_type size() const;      //返回容器中元素的个数
size_type capacity() const;  //容器能够存储的元素个数，有：capacity()>=size()
void reserve(size_type n);   //确保capacity()>=n
void resize(size_type n,T x=T()); //确保返回后，有：size() == n;如果之前size()<n,那么用元素x值补全。
reference front()            //返回容器中第一个元素的引用（容器必须非空）
const_reference front() const;
reference back();
const_reference back() const;
reference operator[](size_type pos);//返回下标为pos的元素的引用（下标从0开始，如果下标不正确，则属于未定义行为）
const_reference operator[](size_type pos) const;
reference at(size_type pos);  //返回下标为pos的元素的引用，如果下标不正确，则抛出异常out_of_range
const_reference at(size_type pos) const;
void push_back(const T& x);
void pop_back();
*/
//下面的插入和删除操作将发生元素的移动（为了保持连续存储的性质），所以之前的迭代器可能失效。
/*
iterator insert(iterator it,const T& x =T());
void insert(iterator it,size_type n,const T&x);
void insert(iterator it,const_iterator first,const_iterator last);
iterator erase(iterator it);  //删除指定元素，并返回删除元素后一个元素的位置（如果无元素，返回end）
iterator erase(iterator first,iterator last);
void clear() const;
void assign(size_type n,const T& x = T()); //赋值，用指定元素序列替换容器内所有元素
void assign(const_iterator first,const_iterator last);
const_iterator begin() const;
iterator begin();
const_iterator end() const;
iterator end();
*/
