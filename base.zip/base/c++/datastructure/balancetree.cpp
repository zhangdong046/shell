#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
static int MINX = -99999;
typedef struct node{
    int data;
    struct node *left,*right;
    node(int x,struct node* p=NULL,struct node* q=NULL):data(x),left(p),right(q){}//c++中结构体的构造函数
}Node;

int JudgeBST(Node* bt){
    int b1,b2;
    //int MINX = -99999;该程序不能正确执行的原因出在这里，MINX的值不会带入到递归函数中，此处应该把MINX声明为全局变量。
    if(bt == NULL)
        return 1;
    else{
        b1 = JudgeBST(bt->left);//left
        if(b1 == 0||MINX >= bt->data)//data>left
            return 0;
        MINX = bt->data;
        b2 = JudgeBST(bt->right);//right
        cout<<b2<<endl;
        return b2;//b1,b2为0或为1.b2传给了上面的b1，该程序这么做纯粹为了性能考虑。
    }//三个return语句//中序遍历的变形。
}

bool isEqual(Node* node1,Node* node2){
    if(node1 == NULL&&node2 == NULL)
        return 1;
    if(!node1||!node2){//此处重点在||上,它是在第一句话不成立的基础上作的后续判断。
        return 0;
    }
    if(node1->data == node2->data)
        return (isEqual(node1->left,node2->left)&&isEqual(node1->right,node2->right))||(isEqual(node1->left,node2->right)&&isEqual(node1->right,node2->left));
    else
        return 0;
}

int main(){
    Node c(1,NULL,NULL);
    Node b(2,NULL,NULL);
    Node a(3,&b,&c);
    if(JudgeBST(&a) == 0){
        cout<<b.data<<a.data<<c.data<<":"<<&a<<endl;
        c.data = 4;
        cout<<b.data<<a.data<<c.data<<":"<<&a<<endl;
        MINX = -99999;//变量的作用域，最后用传参数的方法传递MINX，而不是这样子！！！
        if(JudgeBST(&a) == 1)//上次循环后的MINX是3，此时被直接带过来了，不经过b直接return 0了。。。
            if(!isEqual(&b,&c))
                cout<<"hello world!"<<endl;
    }
   return 0;
}
