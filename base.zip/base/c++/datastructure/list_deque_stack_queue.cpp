#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<stack>
using namespace std;

stack<int> sort(stack<int> s){
    stack<int> r;
    while(!s.empty()){//1
        int tmp = s.top();
        s.pop();
        while(!r.empty()&&r.top()>tmp){//2
            s.push(r.top());
            r.pop();
        }
        r.push(tmp);
    }
    return r;//栈对象是可以在此返回的，又不是指向栈对象的指针。
}

template <class T> class MyQueue{
    stack<T> s1,s2;
public:
    MyQueue(){}
    int size(){
        return s1.size()+s2.size();
    }
    bool empty(){
        if(size() == 0)
            return true;
        else
            return false;
    }
    void push(T value){
        s1.push(value);
    }
    T front(){
        if(!s2.empty())
            return s2.top();
        while(!s1.empty()){
            s2.push(s1.top());//在s2为空时，将s1掏空
            s1.pop();
        }
        return s2.top();
    }
    void pop(){
        if(s2.empty()){
            while(!s1.empty()){
                s2.push(s1.top());//这一步，仅仅当s2为空，s1非空时才会执行
                s1.pop();
            }
        }
        s2.pop();
    }
};
int main(){
    
    return 0;
}
