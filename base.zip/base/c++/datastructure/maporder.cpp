#include<map>
#include<string>
#include<iostream>
using namespace std;
/*
STL是默认采用小于号来排序的，如果关键字是int型，它本身支持小于号运算，在一些情况下，比如关键字是一个结构体，涉及到排序就会出现问题，因为它没有
小于号操作，insert等函数在编译的时候过不去
*/
typedef struct tagStudentInfo
{
    int nID;
    string strName;
//第一种方法：
    bool operator<(tagStudentInfo const& _A) const
    {
        if(nID<_A.nID) return true;
        if(nID == _A.nID) return strName.compare(_A.strName)<0;
        return false;
    }
}StudentInfo,*PStudentInfo;
//第二种方法
/*
仿函数的应用，这个时候结构体没有直接的小于号重载，程序说明。
class sort
{
public:
    bool operator()(StudentInfo const& _A,StudentInfo const &_B) const
    {
        if(_A.nID<_B.nID) return true;
        if(_A.nID == _B.nID) return _A.strNAME.compare(_B.strNAME)<0;
        return false;
    }
};
map<StudentInfo,int,sort> mapStudent;
map中由于它的内部排序，由红黑树保证。
*/
int main(){
    map<StudentInfo,int> mapStudent;
    StudentInfo studentInfo;
    studentInfo.nID = 1;
    studentInfo.strName = "student_one";
    mapStudent.insert(pair<StudentInfo,int>(studentInfo,90));
    studentInfo.nID = 2;
    studentInfo.strName = "student_two";
    mapStudent.insert(pair<StudentInfo,int>(studentInfo,80));
    return 0;
}
/*
map和set的插入删除效率比用其他序列容器高，因为对于关联容器来说，不需要做内存拷贝和内存移动。所有元素都是以节点的方式来存储。
1、插入和删除，只是把节点的指针指向新的节点，一切的操作都是指针换来换去，和内存移动没有关系。
2、每次insert之后，以前保存的iterator不会失效，因为iterator是指向节点的指针，内存没有变，指向内存的指针当然不会失效。
    1.1、get_allocator() 返回map的配置器
    1.2、key_comp() 返回比较元素key的函数
    1.3、explicit map(const Pred& comp = Pred(), const A& al = A());
         map(const map& x);  
         map(const value_type *first, const value_type *last, 
         const Pred& comp = Pred(), const A& al = A());
*/
