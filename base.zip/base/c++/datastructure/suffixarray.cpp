/*
有串abcdabcda，此时最长重复字串是abcda.
*/
//直观的解法是，首先检测长度为n-1的字符串情况，如果不存在重复则检测n-2，一直递减下去直到1.时间复杂度为o(n^3)
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

int comlen(const char* p,const char *q){
    int i = 0;
    while(*p&&(*p++==*q++)) ++i;//*p++ == *q++
    return i;
}

void fun1(const char*str,int n){
    int i,j;
    int maxi,maxj,maxlen = 0;
    int thislen = 0;
    maxi=maxj=0;
    for(i=0;i<n;++i){
        for(j=i+1;j<n;++j){
            if((thislen = comlen(&str[i],&str[j]))>maxlen){//&str[j]
                maxlen = thislen;
                maxi = i;
                maxj = j; 
            }
        }
    }
    for(i=maxi;i<maxi+maxlen;++i) cout<<str[i];
    cout<<endl;
}
const int MAXCHAR = 5000;//最长处理5000个字符
int pstrcmp(const void *p1,const void *p2){
    return strcmp(*(char**)p1,*(char**)p2);//应用于库函数块排qsort的比较函数
}
/*
extern int strcmp(const char*s1,const char* s2);
比较字符串s1和s2,当s1<s2时，返回为负数，当s1 = s2时，返回值为0，当s1>s2时，返回正数。
两个字符串自左向右逐个字符比较，直到出现不同的字符或者遇到‘\0’为止。
*/
int main(){
    char str[10] ={'a','b','c','d','a','b','c','d','a','\0'};
    int len = strlen(str);
    fun1(str,len);//数组名做指针时候可以放心地传递给常量指针参数
    char *c=new char[MAXCHAR];
    char **a=new char*[MAXCHAR];//指向指针的指针
    char ch;
    int n=0,i,temp,maxlen=0,maxi=0;
    printf("please input your string:\n");
    n=0;
    while((ch=getchar())!='\n'){//输入标准,此时结束符为换行符。
        a[n]=&c[n];
        c[n++]=ch;
    }
    c[n] = '\0';
    qsort(a,n,sizeof(char*),pstrcmp);//库函数排序的使用！！！！！！！！
    for(int i=0;i<n-1;++i){
        temp = comlen(a[i],a[i+1]);
        if(temp>maxlen){
            maxlen = temp;
            maxi = i;
        }
    }
    printf("%.*s\n",maxlen,a[maxi]);
    delete []c;
    delete []a;//delete []*a;//不要画蛇添足
    return 0;
}
/*
1、处理过程为先对一个字符串生成相应的后缀数组，然后再排序，拍完序依次检查相邻的两个字符的开头公共部分，其中生成后缀数组的时间复杂度为O(n),拍序时间复杂度为O（nlogn*n）,最后面的n是因为字符串比较也是O(n),依次监测相邻两个字符串的时间复杂度为O(n^2),故总的时间复杂度为O（n^2*logn）,优于第一种方法的O(n^3).
*/
