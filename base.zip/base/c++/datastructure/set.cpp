/*
set/multiset会根据待定的排序准则，自动将元素排序。两者不同在于前者不允许元素重复，而后者允许。
1、不能直接改变元素值，因为那样会打乱原本正确的顺序，要改变元素值必须先删除旧元素，再插入新元素。
2、不提供直接存取元素的任何操作函数，只能通过迭代器进行间接存取，而且从迭代器角度来看，元素值是常数。
3、元素比较动作只能用于型别相同的容器（即元素和排序准则必须相同）
set模板原型：//key为元素(键值)类型
template<class key,class Compare=less<key>,class Alloc=STL_DEFAULT_ALLOCATOR(Key)>
从原型可以看出，比较函数对象及内存分配器采用的是默认参数，因此如果未指定，它们将采用系统默认方式。
利用原型，可以有效地辅助分析创建对象的几种方式。
*/
#include<iostream>
#include<cstring>
#include<string>
#include<set>
#include<iterator>
using namespace std;

struct strLess
{
    bool operator()(const char* s1,const char* s2) const
    {
        return strcmp(s1,s2)<0;
    }
};
/*
红黑树是一种自平衡二叉查找树，典型的用途是实现关联数组。它的统计性能要好于平衡二叉树（AVL树）。
1、节点是红色或黑色。
2、根节点是黑色。
3、每个叶子节点（NIL节点，空节点）是黑色的。
4、每个红色节点的两个子节点是黑色的。
5、从任一节点到其每个叶子的所有路径都包含相同数目的黑色节点。
*/
/*
红黑树从根到叶子的最长的可能路径不多于最短的可能路径的两倍长。这个树大致是平衡的。
*/
void printSet(set<int> s)
{
    copy(s.begin(),s.end(),ostream_iterator<int>(cout,","));
    /*上面一行等同于：
    set<int>::iterator iter;
    for(iter = s.begin();iter != s.end();iter++)
    cout<<*iter<<",";*/
    cout<<endl;
}
int main(){
//创建set对象，共5种方式，提示如果比较函数对象及内存分配器未出现，即表示采用的是系统默认方式。
//创建空的set对象，元素类型为int
    set<int> s1;
//创建空的set对象，元素类型为char*,比较函数对象（排序准则）为自定义strLess
    set<const char*,strLess> s2(strLess);
//利用set对象s1，拷贝生成set对象s2
    set<int> s3(s1);
//用迭代区间【&first,&last】所指的元素，创建一个set对象
    int iArray[] = {13,32,19};
    set<int> s4(iArray,iArray+3);
//用迭代区间[&first,&last]所指的元素，及比较函数对象strLess，创建一个set对象
    const char* szArray[] = {"hello","dog","bird"};
    set<const char* ,strLess> s5(szArray,szArray+3,strLess());
/*
元素插入：
1、插入value，返回pair配对对象，可以根据.second判断是否插入成功（提示：value不能与set容器内元素重复）
   pair<iterator,bool> insert(value)
2、在pos位置之前插入value，返回新元素位置，但不一定能插入成功
    iterator insert(&pos,value)
3、将迭代区间[&first,&last]内的所有元素，插入到set容器
    void insert(&first,&last)
*/
    cout<<"s1.insert(...):"<<endl;
    for(int i = 0;i<5;i++)
        s1.insert(i*10);
    printSet(s1);
    cout<<"s1.insert(20).second ="<<endl;
    if(s1.insert(20).second)
        cout<<"Insert ok!"<<endl;
    else
        cout<<"Insert Failed!"<<endl;
    cout<<"s1.insert(25).second="<<endl;
    if(s1.insert(25).second)
    {
        cout<<"Insert ok!"<<endl;
        printSet(s1);
    }else
        cout<<"Insert Failed!"<<endl;
/*
元素删除
1、size_type erase(value) 移除set容器内元素值为value的元素，返回移除的元素个数。
2、void erase(&pos) 移除pos位置上的元素，无返回值。
3、void erase(&first,&last) 移除迭代区间[&first,&last)内的元素，无返回值
4、void clear() 移除set容器内的所有元素。
*/
    cout<<"\ns1.erase(70)="<<endl;
    s1.erase(70);
    printSet(s1);
    cout<<"s1.erase(60)="<<endl;
    s1.erase(60);
    printSet(s1);
    cout<<"set<int>::iterator iter = s1.begin();\ns1.erase(iter)="<<endl;
    set<int>::iterator iter = s1.begin();
    s1.erase(iter);
    printSet(s1);
/*
元素查找
1、count(value)返回set对象内元素值为value的元素个数
2、iterator find(value) 返回value所在位置，找不到value将返回end()
3、lower_bound(value),upper_bound(value),equal_range(value) 略
*/
    cout<<"\ns1.count(10) = "<<s1.count(10)<<", s1.count(80) = "<<s1.count(80)<<endl;
    cout<<"s1.find(10) : ";
    if (s1.find(10) != s1.end()) 
        cout<<"OK!"<<endl;
    else
        cout<<"not found!"<<endl;

    cout<<"s1.find(80) : ";
    if (s1.find(80) != s1.end()) 
        cout<<"OK!"<<endl;
    else
        cout<<"not found!"<<endl;

//其它常用函数
    cout<<"\ns1.empty()="<<s1.empty()<<", s1.size()="<<s1.size()<<endl;
    set<int> s9;
    s9.insert(100);
    cout<<"s1.swap(s9) :"<<endl;
    s1.swap(s9);
    cout<<"s1: "<<endl;
    printSet(s1);
    cout<<"s9: "<<endl;
    printSet(s9);
    return 0;
}
/*
一个集合（set）是一个容器，它其中所包含的元素的值是唯一的，集合中的元素按一定顺序排列，并作为集合中的实例。
一个集合通过一个链表来组织，在插入和删除操作上比向量快，但查找或者添加末尾的元素时会有些慢。
具体实现采用了红黑树的平衡二叉树的数据结构。
*/
//set支持唯一键值，set中的值是特定的，而且只出现一次，而multiset中可以出现副本值，同一值可以出现多次。
/*
set<int,less<imt>> set1;//less<int>是一个标准类，用于形成升序排列函数对象。降序排列是用greater<int>。
1、begin()  //返回指向第一个元素的迭代器
2、clear()  
3、count()  //返回某个值元素的个数。
4、empty()  //如果集合为空，返回true
5、end()    //返回指向最后一个元素之后的迭代器，不是最后一个元素
6、equal_range()  //返回集合中与给定值相等的上下限的两个迭代器
7、erase()  //删除集合中的元素
8、find()   //返回一个指向被查找元素的迭代器
9、get_allocator()  //返回集合的分配器
10、 insert()
11、lower_bound() //返回指向大于（等于）某值得第一个元素的迭代器。
12、key_comp()  //返回一个用于元素间值比较的函数
13、max_size()  //返回集合能容纳的元素的最大限值
14、rbegin()  //返回指向集合中最后一个元素的反向迭代器
15、rend()  //返回指向集合中第一个元素的反向迭代器
16、size()
17、swap()
18、upper_bound()  //返回大于某个值元素的迭代器
19、value_comp()  //返回一个用于比较元素间的值的函数。
1、std::set_intersection():这个函数求两个集合的交集。
2、std::set_union():求两个集合的并集。
3、std::set_difference():差集。
4、std::set_symmetric_difference():得到的结果是第一个迭代器相对于第二个的差集并上第二个相当于第一个的差集。
struct compare{
    bool operator()(string s1,string s2){
        return s1>s2;
    }//自定义一个仿函数
}；
std::set<string,compare> s;
*/
