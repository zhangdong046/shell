#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<assert.h>
using namespace std;
typedef struct Node{
    int data;
    struct Node *next;
}node;

bool deleteNode(node *pCur){
    if(pCur == NULL||pCur->next ==NULL)
        return false;
    node* pNext = pCur->next;
    pCur->next = pNext->next;
    pCur->data = pNext->data;
    free(pNext);
    return true;
}//狸猫换太子，删除指针指向的单链表中间的一个结点（此结点不是第一个，也不是最后一个）

node* deleteNodes(node* head,int value){
    assert(head != NULL);
    node* p = head,*q = NULL;
    while(p != NULL&&p->data != value){
        q=p;
        p=p->next;
    }
    if(p == NULL)
        return head;
    if(q == NULL){//头指针指向的结点的值等于value
        q=p;
        p=p->next;
        free(q);
        return p;
    }
    q->next = p->next;
    free(p);
    return head;
}
node* create(){
    node* head = (node*)malloc(sizeof(node));
    node* p = head;
    int i;
    for(i=0;i<10;i++){
        node* tmp =(node*)malloc(sizeof(node));
        p->data = i;
        p->next = tmp;
        p=p->next;
    }
    p->data = 10;
    p->next = NULL;
    return head;
}
bool isloop(node* head){
    node* n1=head;
    node* n2=head;
    while(n2->next != NULL){//
        n1=n1->next;
        n2=n2->next->next;
        if(n1 == n2)  return true;
    }
    if(n2->next == NULL)
        return false;
}

node* findkthtotail(node* p,unsigned int k){
    assert(p != NULL&&k>=1);//k>=1
    node* pa = p,*pb = p;
    int i;
    for(i=0;i<k-1;++i){//i<k-1
        pa = pa->next;
        if(pa == NULL)//len<=k
            return NULL;
    }
    while(pa->next != NULL){//
        pa = pa->next;
        pb = pb->next;
    }
    return pb;
}
//首先两个链表各遍历一次，求出两个链表的长度l1,l2,然后可得出两个链表的长度差L.然后在长的链表上遍历L个结点，之后再同步遍历，第一个相同的结点就是第一个公共的结点。
//编程实现环状单向链表，去除连续重复元素的操作。
node* unique(node* head){
    if(head == NULL||head->next == head)
        return head;
    node *p,*q;
    p = head;
    q = head->next;
    while(q != head){//1.1
        while(p->data == q->data&&q != head){
            p->next=q->next;
            free(q);
            q=p->next;//1
        }
        if(q == head) break;
        p = q;//2
        q = q->next;
    }
    if(p->data == q->data){//2.2
        p->next = q->next;
        free(q);
        return p;
    }else
        return q;
}

int main(){
    node* p = create();
    deleteNodes(p,10);
    node* q = findkthtotail(p,4);
    cout<<"倒数第4个结点值为："<<q->data<<endl;
    return 0;
}
