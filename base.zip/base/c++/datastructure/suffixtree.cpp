/*
键树只适合前缀匹配和全字匹配，并不适合后缀和子串匹配。而后缀树在这方面非常合适。它与键树最大的区别是，后缀树的单词集合是由指定字符串的后缀子串构成的，然后对这些子串的集合建立一颗键树。
后缀树常用来在串s中查询子串p是否存在。
*/
//给你一个长字符串s与很多短字符串集合{T1，T2，……}，设计一个方法在s中查询T1,T2……要求找出Ti在s中的位置。
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<vector>
#include<map>
using namespace std;

class SuffixTreeNode{//后缀树结点类
    map<char,SuffixTreeNode*> children;
    char value;//结点的字符值
    vector<int> indexs;//存储子字符串在s中开始的位置
public:
    SuffixTreeNode(){}
    //递归地插入一个后缀子串，s为要插入的字符串，index为s在主串中的起始位置
    void insertString(string s,int index){
        indexs.push_back(index);//如果已经是某字串的末尾字符，为已创建，此时为该子串的起始位置。否则为新串起始位置。读取时候是走到头，然后读取末尾叶子节点的vector信息。
        if(s.length()>0){
            value = s[0];
            SuffixTreeNode* child = NULL;
            if(children.find(value)!=children.end()){//如果首字符结点已存在
                child=children[value];//映射的数组使用方式
            }else{
                child = new SuffixTreeNode();
                children[value]=child;//类似于python中词典的使用方法
            }
            string remainder = s.substr(1);//第二个参数空缺，保存除首元素之外的子串
            child->insertString(remainder,index);//递归插入
        }
    }
    /*用递归法查询子串p，原理同Trie树*/
    vector<int> getIndexs(string s){
        if(s.length()==0){
            return indexs;
        }else{
            char first = s[0];
            if(children.find(first)!=children.end()){
                string remainder = s.substr(1);
                return children[first]->getIndexs(remainder);
            }else{
                vector<int> empty;
                return empty;
            }
        }
    }
    ~SuffixTreeNode(){
        map<char,SuffixTreeNode*>::iterator ite;
        for(ite = children.begin();ite!=children.end();ite++)
            delete (ite->second);//map
    }
};

class SuffixTree{
    SuffixTreeNode* root;
public:
    SuffixTree(string s){
        root = new SuffixTreeNode();
        for(int i=0;i<s.length();i++){
            string suffix = s.substr(i);
            root->insertString(suffix,i);
        }
    }
    vector<int> getIndexs(string s){return root->getIndexs(s);}//？重点在root->上面
    ~SuffixTree(){
        if(root!=NULL) delete root;
    }
};
int main(){
    string testString = "mississippi";
    string stringList[] = {"is","sip","hi","sis"};
    SuffixTree tree(testString);
    for(int i = 0;i<4;i++){
        vector<int> li = tree.getIndexs(stringList[i]);
        if(li.size()!=0){
            cout<<stringList[i].c_str()<<"   ";//c_str();
            for(int j=0;j<li.size();j++){
                cout<<li[j]<<" ";
            }
            cout<<endl; 
        }
    }
    return 0;  
}//匹配成功正好比较了len次字符，则查找效率为O(len)。
/*
1、已知n个由小写字母构成的平均长度为10的单词，判断其中是否存在某个串为另一个串的前缀子串。
2、给定一个单词，如果通过交换单词中字母的顺序可以得到另外的单词b,那么定义b是a的兄弟单词，例如army和mary是兄弟单词，现在给一个字典，用户输入一单词，如何根据字典找出这个单词有哪些兄弟单词，要求时间和空间效率尽可能高。
    2.1、使用hash_map和链表。
         首先定义一个id,使得兄弟单词有相同的id,不是兄弟的单词有不同的id,例如将单词按字母从小到大重新排序后作为其id.
         创建一个hash_map,它的key为单词的id,value为一个链表的起始地址，链表中存放所有id等于key的单词。
         当需要找兄弟单词时，只需计算这个单词的id,然后到hash_map中找到对应的链表即可，这样创建hash_map的时间复杂度为O（n),查找兄弟单词的时间复杂度为O（1).
    2.2、同样适用hash_map和链表。
         将每一个字母对应一个质数，a对应2，b对应3.。。然后将单词各个字母对应的质数相乘，将得到的值进行hash,这样兄弟单词的乘积就是一样的了。
         使用链表将所有兄弟单词串在一起，hash_map的key为单词的乘积，value为链表的起始地址。
         对用户输入的单词计算乘积，然后查找hash_map，将value中对应的链表遍历输出就得到它的所有兄弟的单词。
         这样创建hash_map的时间复杂度为O(n),查找兄弟单词的时间复杂度为O(1).
         此方法相比解法1不需要对单词按字母排序。
    2.3、利用trie树，单词插入tire树之前，先按字母排序。在tire树的结点中增加一个vector,记录所有兄弟单词。
         这样当查询的时候，只需先将关键词排序，然后将排序后的单词拿去查询，当所有字母都遍历后，读出对应结点的vector,里面存储的就是此单词的所有兄弟单词。
3、双链树和trie树是键树的两种不同表示方法，它们有各自的特点。若键树中结点的度较大，则采用trie树结构较双链树更为合适。
   综上，键树的查找过程都是从根结点出发，走了一条从根到叶子（或非终端结点）的路径，其查找时间依赖于单词的长度。
*/
