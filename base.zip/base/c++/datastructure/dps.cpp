#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;

const int N=10;//n的最大值
int d[N];//记录解
int v[N];//记录某个值是否被遍历过，没遍历过为0，遍历过为1.
int n;
void dfs(int depth){
    if(depth>=n){
        int i;
        for(i=0;i != n;++i)
            cout<<d[i];
        cout<<endl;
        return;//不是递归，而是通过调用自身分出很多分支
    }
    int i;
    for(i=1;i<=n;++i){//注意此处的n个分支
        if(v[i] == 0){//区别于回溯法的swap式的全排列,虽然原理一样。
            v[i]=1;
            d[depth]=i;
            dfs(depth+1);
            v[i]=0;
        }
    }
}
int ans=0;//保存解
int item_number=10;//物品件数
int knap_size=30; //背包载重量或者体积容量
int weight[N]={10,20,3,4,5,6,7,8,9,11}; //物品的重量或者体积
int value[N]={8,12,3,6,2,6,5,7,8,10}; //物品的价值
int x[N]; //解向量
void dfss(int cur_depth,int cur_size,int cur_value){
    if(cur_depth>item_number){//超过解答树深度，该路径不是问题的解
        if(cur_value>ans)
            ans = cur_value;
        return;
    }
    if(cur_size>knap_size)//超过背包容量，该路径不是问题的解
        return;
    if(cur_value>ans)//保存当前路径的解
        ans=cur_value;
    dfss(cur_depth+1,cur_size,cur_value);//注意这里的参数传递
    dfss(cur_depth+1,cur_size+weight[cur_depth],cur_value+value[cur_depth]);
}

int main(){
    cin>>n;
    memset(v,0,n);
    dfs(0);
    dfss(0,0,0);
    cout<<ans<<endl;
    return 0;
}
