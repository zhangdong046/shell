/*
树的深度是从根节点开始（其深度为1）自顶向下逐层累加的，而高度是从叶节点开始（其高度为1）自底向上逐层累加的。
虽然树的深度和高度一样，但是具体到树的某个节点，其深度和高度是不一样的。
*/
#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<cstring>
#include<queue>
#include<vector>
#include<stack>
#include<sys/wait.h>
using namespace std;

const int MAXS = 20;
typedef struct Treenode{
    char data;
    struct Treenode* left;
    struct Treenode* right;
}Node;

Node* create(const char* pre,int prelen,const char* mid,int midlen){
    int i=0;
    if(prelen == 0||midlen == 0)
        return NULL;
    if(prelen != midlen){
        cout<<"输入序列错误！"<<endl;
        exit(0);
    }
    for(i=0;i<prelen;i++)
        if(mid[i] == pre[0]) break;
    Node *atom = new Node;
    atom->data = pre[0];
    atom->left = create(pre+1,i,mid,i);
    atom->right = create(pre+i+1,prelen-i-1,mid+i+1,prelen-i-1);
    return atom;
}
int depth(const Node* t){
    if(t == NULL) return 0;
    else{
        int ldepth = depth(t->left) + 1;//左
        int rdepth = depth(t->right) + 1;//右
        return max(ldepth,rdepth);//根
    }
}
void del(Node* t){
    if(t->left != NULL) del(t->left);
    if(t->right != NULL) del(t->right);
    if(t != NULL)  delete t;
}
void lastsequence(const Node* t){
    if(t == NULL) return;
    const Node* p = t;
    stack< const Node*> temp;//const
    temp.push(p);
    const Node* flag = t;
    while(p != NULL){
        const Node* q = p;
        while(p->left != NULL&&p->right != flag&&p->left != flag)//排除从左右子树返回来的情况，然后继续往左分支走。
        {
            p = p->left;
            temp.push(p);
        }
        if(flag != p&&p->right == NULL)//左分支走到尽头，出栈回头。
        {
            cout<<p->data;
            flag = p;//每次出栈都要做好标记!!!!!!
            temp.pop();
        }
        if((p = temp.top())!=NULL)
        {
            if(p->right != NULL&&p->right != flag)//往右分支走一步
            {
                p = p->right;
                temp.push(p);
            }else//右分支也走到头了，出栈回头
            {
                flag = p;//做好标记
                cout<<p->data;
                temp.pop();
                if(temp.size() > 0)
                    p = temp.top();
                else{
                    cout<<endl;
                    return;
                }
            }
        }
    }
}
void dps(const Node* t){
    queue<const Node*> tmp;//const
    tmp.push(t);
    cout<<endl<<"该树的广度遍历序列为：";
    while(!tmp.empty()){
        const Node *p = tmp.front();//const
        cout<<p->data<<" ";
        if(p->left != NULL) tmp.push(p->left);
        if(p->right != NULL) tmp.push(p->right);
        tmp.pop();
    }
    cout<<endl;
}
void Distance(const Node* t,int flag,int level,vector<int>& s){
    if(t == NULL) return;
    int tmp = 0;
    s.push_back(int(t->data - '0'));
    int i;
    for(i=level;i>-1;i--){
        tmp+=s[i];
        if(tmp == flag){
            cout<<"一个等于"<<flag<<"的路径是："<<endl;
            int j;
            for(j=level;j>=i;j--)
                cout<<s[j];
            cout<<endl;
        } 
    }
    Distance(t->left,flag,level+1,s);
    Distance(t->right,flag,level+1,s);
    s.pop_back();
    level--;
}
typedef struct results{//定义返回结果
    int nMaxDistance;//最大距离
    int nMaxDepth;//最大深度
}RESULT;

RESULT GetMaximumDistance(Node* root){
    if(!root){
        RESULT empty={0,-1};//最大深度初始化为-1，是因为调用者要对其加1，然后变为0.
        return empty;
    }
    RESULT lhs=GetMaximumDistance(root->left);
    RESULT rhs=GetMaximumDistance(root->right);
    RESULT result;
    result.nMaxDepth=max(lhs.nMaxDepth+1,rhs.nMaxDepth+1);
    result.nMaxDistance=max(max(lhs.nMaxDistance,rhs.nMaxDistance),lhs.nMaxDepth+rhs.nMaxDepth+2);//当树只有两个结点时（距离）：max(max([-1]+[-1]+2=0,0),[-1]+0+2=1)=1
    return result;
}
//平衡二叉树可定义为它或者是一棵空树，或者是具有下列性质的二叉树：它的左子树和右子树都是平衡二叉树，且左子树和右子树的高度差绝对值不超过1.
bool isbalanced(Node* root){
    if(root == NULL)
        return true;
    int left = depth(root->left);
    int right = depth(root->right);
    int diff = left-right;
    if(diff>1||diff<-1)
        return false;
    return isbalanced(root->left)&&isbalanced(root->right);
}//前根遍历式处理

bool IsBalanced(Node* root,int* depth){
    if(root == NULL){
        *depth=0;
        return true;
    }
    int left,right;
    if(IsBalanced(root->left,&left)&&IsBalanced(root->right,&right)){//2
        int diff=left - right;
        if(diff<=1&&diff>=-1){
            *depth = 1+(left>right?left:right);
            return true;
        }
    }//此处使用了后根遍历，相比前根遍历，在遍历到一个结点前我们已经遍历了它的左右子树；而前序每个结点会被遍历多次。
    return false;//1
}

int maxDepth(Node* root){
    if(root == NULL) return 0;
    return 1+max(maxDepth(root->left),maxDepth(root->right));
}

int minDepth(Node* root){
    if(root == NULL) return 0;
    return 1+min(minDepth(root->left),minDepth(root->right));
}
bool isBanlance(Node * root){
    return (maxDepth(root) - minDepth(root) <= 1);
}
int main(){
    Node* T = NULL;
    vector<int> s;
    char pre[MAXS];
    char mid[MAXS];
    cout<<"请输入树的前序序列(长度<20)！"<<endl;
    cin>>pre;
    int prelen = strlen(pre);//string类对象才能使用length()
    cout<<"请输入树的中序序列(长度<20)!"<<endl;
    cin>>mid;
    int midlen = strlen(mid);
    T = create(pre,prelen,mid,midlen);
    int tdepth = depth(T);
    cout<<"树高为"<<tdepth<<endl;
    dps(T);
    Distance(T,6,0,s);//因为创建树的时候使用比较，故树的元素不能有相同元素字符。
    cout<<"该树的后序非递归遍历序列：";
    lastsequence(T);
    RESULT ps =GetMaximumDistance(T);
    cout<<"该树的最长距离是："<<ps.nMaxDistance<<endl;
    if(isBanlance(T)) cout<<"这是平衡二叉树!"<<endl;
    else if(!IsBalanced(T,&tdepth)) cout<<"这不是平衡二叉树!"<<endl; 
    del(T);
    return 0;
}
/*
1、向量<vector>,连续存储的元素.
    1.1、vector<int> a(10,1);//声明一个初始大小为10且初始值都为1的向量。
    1.2、vector<int> a; vector<int> a(10); vector<int> b(a);
    1.3、vector<int> b(a.begin(),a.begin()+3);//将a向量中从第0个到第2个作为向量b的初始值。
    1.4、int n[] = {1,2,3,4,5};/vector<int> a(n,n+5);将数组n的前5个元素作为向量a的初值/vector<int> a(&n[1],&n[4]);
    1.5、元素的输入和访问可以像操作普通的数组那样，用cin>>进行输入，cout<<a[n]进行输出。
2、列表<list>，由节点组成的双向链表。
3、双端队列<deque>,连续储存的指向不同元素的指针所组成的数组。
4、集合<set>,由节点组成的红黑树，每个节点都包含一个元素，节点之间以某种作用于元素对的谓词排列，没有两个不同的元素能够拥有相同的次序。
5、多重集合(multiset),允许存在两个次序相等的元素的集合。
6、栈<stack>,后进先出的值的排列。
7、队列<queue>,先进先出的值的排列。
8、优先队列(priority_queue),元素的次序是由作用于所存储的值对上的某种谓词决定的一种队列。
9、映射<map>,由{键，值}对组成的集合，以某种作用于键对上的谓词排列。
*/
