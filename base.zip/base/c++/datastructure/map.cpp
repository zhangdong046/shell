/*
map<Key,Data,Compare,Alloc>
map是一种关联容器，存储相结合形成的一个关键值和映射值得元素。它的值类型为pair<const Key,Data>。任何两个元素没有相同的key值。
map具有重要的属性，就是map对象中插入一个新元素，不指向现有元素的迭代器不会失效。从map上删除一个元素，也没有任何迭代器失效。
map内部自建一颗红黑树（一种非严格意义上的平衡二叉树），这棵树具有对数据自动排序的功能。所以在map内部所有的数据都是有序的。
*/
#include<map>
#include<cstring>
#include<string>
#include<iostream>
using namespace std;

bool fncomp(char lhs,char rhs)
{
    return lhs<rhs;
}
struct classcomp
{
    bool operator()(const char& lhs,const char& rhs)
    {
        return lhs<rhs;
    }
};
int main(){
    map<char,int,classcomp> first;
    bool(*fn_pt)(char,char) = fncomp;
    map<char,int,bool(*)(char,char)>second(fn_pt);
    map<int,string> mapStudent;
    mapStudent.insert(pair<int,string>(1,"student_one"));//用insert函数插入pair数据
    mapStudent.insert(map<int,string>::value_type(2,"student_two"));//用insert函数插入value_type数据
    mapStudent[3] = "student_three";//用数组方式插入数据
    map<int,string>::iterator iter;
    for(iter = mapStudent.begin();iter != mapStudent.end();iter++)
        cout<<iter->first<<" "<<iter->second<<endl;
/*
以上三种用法，虽然都可以实现数据的插入，但他们是有区别的，第1、2种在效果上是完全一样的，用insert函数插入数据，当map中已经有了这个关键字时，
insert函数是不能插入该数据的，但是使用数组方式，它可以覆盖以前该关键字对应的值。
1、可以用pair来获得是否插入成功，Pair<map<int,string>::iterator,bool> Insert_Pair;
2、Insert_Pair = mapStudent.insert(map<int,string>::value_type(1,"student_one"));
3、我们通过pair的第二个变量来知道是否插入成功，它的第一个变量返回的是一个map的迭代器，如果插入成功的话Insert_Pair.second应该是true,否则为false.
*/
    pair<map<int,string>::iterator,bool> Insert_Pair;
    Insert_Pair = mapStudent.insert(pair<int,string>(1,"student_two"));//返回pair类型的
    if(Insert_Pair.second == true){
        cout<<"Insert Successfully!"<<endl;
    }else{
        cout<<"Insert Failure!"<<endl;
    }
    mapStudent[1] = "student_ones";
    map<int,string>::iterator iter1;
    for(iter1 = mapStudent.begin();iter1 != mapStudent.end();iter1++)
        cout<<iter1->first<<","<<iter1->second<<endl;//前向迭代器遍历
    int nSize = mapStudent.size();//map的大小
    map<int,string>::reverse_iterator iter2;//反相迭代器
    for(iter2 = mapStudent.rbegin();iter2 != mapStudent.rend();iter2++)
        cout<<iter2->first<<"|"<<iter2->second<<endl;//反相迭代器遍历
    int nIndex;
    for(nIndex = 0;nIndex<nSize;nIndex++)
        cout<<mapStudent[nIndex]<<endl;//数组方式遍历
//第一种数据查找方法，用count函数，其缺点是无法定位数据出现位置，count的返回值或者是0，或者是1.
//第二种，用find函数来定位数据出现位置，它返回的一个迭代器，当数据出现时，它返回数据所在位置的迭代器，如果map中没有要查找的数据，它返回的迭代器等于end函数返回的迭代器。
    map<int,string>::iterator iter3;
    iter3 = mapStudent.find(2);
    if(iter3 != mapStudent.end()){
        cout<<"Find,the value is:"<<iter3->second<<endl;
    }else{
        cout<<"Do not Find"<<endl;
    }
//第三种，例如map中已经插入了1，2，3，4的话，如果lower_bound(2)的话，就返回迭代器2，而upper_bound(2)的话，返回的就是3.
//Equal_range函数返回一个pair,pair里面的第一个变量是lower_bound返回的迭代器，pair里面的第二个迭代器是upper_bound返回的迭代器，如果这两个迭代器相等的话，则说明map中不出现这个关键字。
    mapStudent[5] = "student_five";
    iter = mapStudent.lower_bound(4);
    cout<<"返回的是下界5的迭代器:"<<iter->second<<endl;
    iter = mapStudent.upper_bound(3);
    cout<<"返回的是上界5的迭代器:"<<iter->second<<endl;
    pair<map<int,string>::iterator,map<int,string>::iterator> mapPair;
    mapPair = mapStudent.equal_range(4);
    if(mapPair.first == mapPair.second)
        cout<<"Do not Find"<<endl;
//清空map中的数据可以使用clear()函数，判定map中是否有数据可以用empty()函数，它返回true则说明空map。数据的删除使用erase函数，它有三个重载函数。
    iter = mapStudent.find(5);
    mapStudent.erase(iter);//用迭代器删除
    int n = mapStudent.erase(3);//用关键字删除，成功返回1，否则返回0.
/*
用迭代器，成片地删除 mapStudent.erase(mapStudent.begin(),mapStudent.end());
需要注意，STL特性，删除区间是一个前闭后开的集合
*/
    map<int,string>::iterator iterl;
    for(iterl = mapStudent.begin();iterl != mapStudent.end();iterl++)
        cout<<iterl->first<<" "<<iterl->second<<endl;
    return 0;
}
/*
iterator begin()、iterator end()、const_iterator begin() const、const_iterator end() const;
reverse_iterator rbedin()、reverse_iterator rend()、const_reverse_iterator rbegin() const、const_reverse_iterator rend() const
key_compare key_comp() const 比较key的大小
//Returns a function pointer to the function that determines the order of elements in the controlled sequence.
value_compare value_comp() const  比较value的大小
//Returns a function pointer to the function that determines the order of elements in the controlled sequence (same as key_comp).
map& operator=(const map&)
void swap(map&)
pair<iterator,bool> insert(const value_type& x)
bool operator==(const map&,const map&)
bool operator<(const map&.const map&)
*/
