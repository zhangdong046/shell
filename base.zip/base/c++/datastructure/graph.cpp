#include<iostream>
#include<cstdio>
#include<cstdlib>//exit(0);
#include<cstring>
using namespace std;

const int INF = 0x3f3f3f3f;//int型可以如此赋值
typedef struct Graphs
{
    char vertex[35][4];
    int edges[35][35];
    int visited[35];
}Graph;

char s1[21][4] = {"A1","A2","A3","A4","A5","A6","A7","A8","A9","T1","A10","A11","A12","A13","T2","A14","A15","A16","A17","A18","A1"};
char s2[17][4] = {"B1","B2","B3","B4","B5","T1","B6","B7","B8","B9","B10","T2","B11","B12","B13","B14","B15"};
char v[35][4] = {"A1","A2","A3","A4","A5","A6","A7","A8","A9","T1","A10","A11","A12","A13","T2","A14","A15","A16","A17","A18","B1","B2","B3","B4","B5","B6","B7","B8","B9","B10","B11","B12","B13","B14","B15"};

void CreateGraph(Graph* G){
    int i,j,k;
    for(i=0;i<35;i++)
    {
        memcpy(G->vertex[i],v[i],sizeof(v[i]));
        G->visited[i] = 0;
    }
    for(i=0;i<35;i++){
        for(j=0;j<35;j++)
            G->edges[i][j] = INF;
    }
    for(k=0;k<20;k++){
        for(i=0;strcmp(s1[k],G->vertex[i])!=0;i++);//extern int strcmp(const char* s1,const char* s2);
        for(j=0;strcmp(s1[k+1],G->vertex[j])!= 0;j++);//k+1
        G->edges[i][j] = 1;
        G->edges[j][i] = 1;
    }
    for(k=0;k<16;k++){
        for(i=0;strcmp(s2[k],G->vertex[i])!= 0;i++);
        for(j=0;strcmp(s2[k+1],G->vertex[j])!= 0;j++);
        G->edges[i][j] = 1;
        G->edges[j][i] = 1;
    }
}

void Floyed(Graph* &G){
    int i,j,k;
    for(k=0;k<35;k++){
        for(i=0;i<35;i++){
            for(j=0;j<35;j++){
                if(G->edges[i][k]+G->edges[k][j] < G->edges[i][j])
                    G->edges[i][j] = G->edges[i][k]+G->edges[k][j];
            }
        }
    }
}

void Ace(Graph* G){
    char s1[4],s2[4];
    int i,j;
    cout<<"请输入起点站和终点站"<<endl;
    cin>>s1>>s2;
    for(i=0;strcmp(s1,G->vertex[i])!=0;i++);
    for(j=0;strcmp(s2,G->vertex[j])!=0;j++);
    if(i<35&&j<35)
        cout<<G->edges[i][j]+1<<endl;
    else
        exit(0);
}
int main(){
    Graph *G = new Graph;
    CreateGraph(G);
    Floyed(G);
    while(1){
        Ace(G);
    }
    return 0;
}
