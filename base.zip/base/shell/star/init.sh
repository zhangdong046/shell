#!/bin/bash

function starts()
{
    sh daemons.sh &
    shpid="$!"
    echo "$shpid">./test/sh.sid
}


function stops()
{
    shpid="`cat ./test/sh.sid`"
    kill $shpid
    echo "kill deamon.sh!"
    ps ax|grep daemons |grep -v grep |awk '{print $1}' |xargs kill
    sleep 2
    ps ax|grep daemons |grep -v grep |awk '{print $1}' |xargs kill
    echo "kill deamon done"
}

starts
sleep 10s
stops
exit 0
