#!/bin/bash

#�����ʼ����
#�������
if [ $# != 3 ]; then 
    echo "USAGE: $0 path env num" 
    echo " e.g.: $0 /home/map/taskmgr/ test.guoke.1 5" 
    exit 1
fi

mkdir -p $1
if [ $? != 0 ]; then
    echo "create path failed!"
    exit 1
else
    WORKPATH=$1
fi

if [ $2 == "guoke" -o $2 == "test.guoke.1" -o $2 == "test.guoke.2" ]; then
    ENV=$2
elif [ $2 == "qa_200" ]; then
    ENV=$2
else
    echo "unknown env!"
    exit 1
fi

if [ $3 -lt 1 -o $3 -gt 10 ]; then
    echo "invalid num! 1-10 is fine!"
    exit 1
else
    NUM=$3
fi

#��ʼ����
cnt=1
PW_DIR=$WORKPATH"processwork_"$ENV"_1" 
echo $PW_DIR
rm -rf $PW_DIR
mkdir -p $PW_DIR
tar -zxvf processworker.tar.gz -C $PW_DIR
mv $PW_DIR/output/* $PW_DIR/
rm $PW_DIR/output/ -rf
cd $PW_DIR/conf
CONF_SH=$ENV".py"
python $CONF_SH
cd ..
bash bin.sh processworker

#����num - 1��ʵ��
for((i=2; i<=$NUM; i++));
do 
    cd $WORKPATH
    PW_DIR_TMP=$WORKPATH"processwork_"$ENV"_"$i
    rm -rf $PW_DIR_TMP
    cp -r $PW_DIR $PW_DIR_TMP
    cd $PW_DIR_TMP 
    sh bin.sh processworker
done
