#!/bin/bash
#source function

#递归调用
function inputs()
{
read -p "press some key,then press return:" KEY
case $KEY in
    [a-z]|[A-Z])
        echo "It's a letter."
        ;;
    [0-9])
        echo "It's a digit."
        ;;
    *)
        echo "press one key,not some!"
        inputs
        ;;
esac
}

function switch()
{
case $1 in
    start| begin)
        echo "start!"
        ;;
    stop | end)
        echo "stop!"
        ;;
    *)
        echo "Ignorant"
        ;; 
esac
}

function check()
{

cat <<"EOT";
Usage: switch.sh -d path -f file_name -i num -n seq
     -d choose data dir
     -f touch new file
     -i The data type
        0 chmod 777
        1 rm new file
        2 write mysql
        3 read mysql
     -n the number of result
EOT


while getopts "d:f:i:n:" optname
do
    case "$optname" in
    "d")
        DIR=$OPTARG
        ;;
    "f")
        FILENAME=$OPTARG
        ;;
    "i")
        NUM=$OPTARG
        ;;
    "n")
        SEQ=$OPTARG
        ;;
    "?")
        echo "unknown option $OPTARG"
        ;;
    *)
        echo "unknown error while processing options"
        ;;
     esac
done

if [ -z "$DIR" ]
then
    echo "please input data dir!"
    exit 0
fi

echo $DIR
`cd $DIR>/dev/null 2>&1`
if [ $? != 0  ];then
    echo "File path error!"
    exit 1
fi

#字符串替换
declare -i length=${#DIR}
length=length-1

#echo ${DIR:$length:1}取最后一个字符
if [[ `echo ${DIR:$length:1}` != '/' ]];then
    DIR=$DIR"/"
fi

#[]实际上是bash中test命令的简写，即所有的[ expr ]等于 test expr
#对test命令来说，用-eq要进行数字比较，而你此时传入字符串，就会报错。
#[[ expr ]]是bash中真正的条件判断语句，语法更符合编程习惯

DIRS=$DIR$FILENAME
#此处必须添加双引号,且!与-f间需要空格
#（1）"["：逻辑与："-a"；逻辑或："-o":
#（2）"[["：逻辑与："&&"；逻辑或："||"
if [[ ! -f "$DIRS" ]];then
    touch $DIRS
fi

if [[ $NUM = "0"||$NUM = 0 ]];then
    chmod 777 $DIRS
elif [[ $NUM = "1"||$NUM = 1 ]];then
    rm $DIRS
elif [[ $NUM = "2"||$NUM = 2 ]];then
    select_sql="select rule_id,obj from rule_check_all where category = 'ROAD' and obj is not null limit $SEQ,1;"
    echo $select_sql
#shell中经常遇到一些问题，眼看着没有任何问题的句子就是执行不成功。
    mysql -h"127.0.0.1"   -P"3306"   -u"root" -p"123" "work" -e "${select_sql}">$DIRS
elif [[ $NUM = "3"||$NUM = 3 ]];then
    while read atom1 atom2
    do
        echo "atom1:"$atom1
        echo "atom2:"$atom2
    done<$DIRS
else
    read -p "parameter -i error, please try again:" NUM
    #DIR=${DIR%/*}
    check -d $DIR -f $FILENAME -i $NUM -n $SEQ 
fi
}

function Tcheck()
{

#参数检查
if [ $# != 3 ];then
    echo "Parameter: $0 file_name; seq; num."
    exit 1
fi

SEQ=$3
NUM=$2
if [[ $NUM != "2" ]];then
    check -d "/home/test_149/shell/star/test/" -f $1 -i $NUM -n $SEQ &
    sleep 1
else
    check -d "/home/test_149/shell/star/test/" -f $1 -i $NUM -n $SEQ &
    sleep 1
    NUM="3"
    check -d "/home/test_149/shell/star/test/" -f $1 -i $NUM -n $SEQ &
    sleep 1 
    NUM='2'
   
     read -p "press q(stop select) or SEQ(start select again),then press return:" KEY
    case $KEY in
        end|stop|q|quit)
            echo "select end!"
            exit 0
            ;;
        *)
            echo 
            if [[ "$KEY" = ~"^[0-9]+$" ]];then
                echo "Not a numbr"
                Tcheck $1 $NUM "q"
            else
                Tcheck $1 $NUM $KEY
            fi
            ;;
    esac
fi
} 
inputs
switch "begin"
check -d "/home/test_149/shell/star/test/" -f "test.txt" -i 2 -n 10 &
sleep 1
check -d "/home/test_149/shell/star/test/" -f "test.txt" -i 3 -n 10 &
sleep 1
check -d "/home/test_149/shell/star/test/" -f "test.txt" -i 1 -n 10 &
sleep 1

Tcheck "test.txt" 2 10 
Tcheck "test.txt" 1 1 
switch "stop"
