#!/bin/bash

#使用read命令读取一行数据
while read myline
do
    echo "LINE:"$myline
done<./test/test.txt

#使用read命令读取一行数据
cat ./test/test.txt | while read myline
do 
    echo "LINE:"$myline
Done

#读取一行数据
cat ./test/test.txt | while myline=$(line)
do 
    echo "LINE:"$myline
Done

#读取一行数据
while myline=$(line)
do 
    echo "LINE:"$myline
done<./test/test.txt

#使用read命令读取变量数据
cat ./test/test.txt | while read paraa parab parac
do
    echo "PARAA:"$paraa
    echo "PARAB:"$parab
    echo "PARAC:"$parac
Done

#使用read命令读取变量数据
while read paraa parab parac
do
    echo "PARAA:"$paraa
    echo "PARAB:"$parab
    echo "PARAC:"$parac
done < ./test/test.txt
