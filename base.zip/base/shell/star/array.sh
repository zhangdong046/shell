#!/bin/bash

#字符串
str="a b c"
for i in $str
do
    echo $i
done

#数组下标默认从0开始
array=($str)
for((i=0;i<${#array[@]};i++))
do
    echo ${array[$i]}
done

#字符串分割
str2="a#b#ci#--d"
#替换/替换+多个连续重复的缩为单个
a=($(echo $str2|tr '#' ' '|tr -s ' ' ' '))
length=${#a[@]}
echo $a
echo ${a[1]}
echo ${#a[3]}
#输出数组中下标为3的元素的长度
echo ${a[@]:1:3}
#输出数组中下标为1到3的元素
echo ${a[@]:2}
echo ${a[@]::2}
#下标大于/小于2

#定义数组
array1=(1 2 3 4 5)
array2[0]="nick1"
array2[1]="nick2"
#echo ${array[*]} = ${array[@]}清单形式打印数组
echo ${array2[*]}

#定义关联数组
declare -A arr1
declare -A arr2
arr1=([index1]='val1' [index2]='val2')
arr2[index1]='val1'
arr2[index2]='val2'
for key in ${!arr1[*]}
do
    echo "$key->${arr1[$key]}"
done

#列出索引
echo ${!arr1[*]}
echo ${!arr2[@]}
