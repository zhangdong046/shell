#！/bin/bash

function daemons()
{
    ./array.sh &
    chpid="$!"
    echo "$chpid">./test/ch.sid
    echo "child pid is $chpid"
    echo "status is $?"
    while((1<2))
    do
        wait $chpid
        exitstatus="$?"
        echo "child pid=$chpid is gone,$existtatus">>./test/cherror.log
        echo `date` >>./test/cherror.log
        echo "***********************************">>./test/cherror.log
        sleep 10
        ./array.sh &
        chpid="$!"
        echo "$chpid">./test/ch.sid
        echo "next child pid is $chpid"
        echo "next status is $?"
    done
}

daemons
