#!/bin/bash

#sh_dir=/usr/bin/
#crondir=${sh_dir}crontab
#source ${sh_dir}CONFIG
crondir=./test
hosts="127.0.0.1 192.168.56.102"
user="root"
mails="397286219@qq.com 13370172732@163.com"


let df_limit=85

for HOST in $hosts ;do

    flag_disk_file=$crondir/$HOST".disk"
    log=$crondir"/disk_error.log"
    capacity=`ssh -o ConnectTimeout=2 root@$HOST "df" | grep "/dev/" | sed 's/\%//' | awk '{print $5}'`
    let flags=0

#未成功连接，退出
    test -z "$capacity" && continue

#判断ssh命令返回结果
    for used in $capacity ;do
        if [ $used -ge $df_limit  ];then
            let flags=1
                break
        fi
    done

#如果磁盘超过限制,则发送报警邮件

    if [ "$flags" -eq 1 -a ! -f "$flag_disk_file" ];then
        for mail in $MAILS;do
            echo "$HOST disk will full" | mail -s "$HOST disk will full" $mail
        done

        date +'%F %T' >>$log
        echo "$HOST disk will full" >> $log
        echo "disk_error" >$flag_disk_file
    fi

#如果磁盘正常，则发邮件解除报警邮件

    if [ "$flags" -eq 0 -a  -f "$flag_disk_file" ];then
        for mail in $MAILS;do
            echo "$HOST disk ok" | mail -s "$HOST disk ok" $mail
        done

        date +'%F %T' >>$log
        echo "$HOST disk ok" >> $log
        rm -f $flag_disk_file
    fi 
done
