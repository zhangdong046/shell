1、linux设置开机服务自动启动
    1.1、chkconfig --list   显示开机可以自启动的服务
    1.2、chkconfig --add *** 添加开机自动启动***服务
    1.3、chkconfig --del *** 删除开机自动启动***服务
    1.4、/etc/rc.d/init.d/? start
    1.5、/etc/rc.d/? stop
    1.6、把启动命令放到/etc/rc.d/rc.local文件里这样就可以每次启动的时候自动启动服务。
    
2、logout后有效：
    2.1、修改~HOME/.bash_profile里的$PATH,加入此路径
        2.1.1、cd
        2.1.2、vi .bash_profile
        2.1.3、export PATH=$PATH:/pgsql/bin
    2.2、做个软链接到/usr/bin
        2.2.1、ln -s /pgsql/bin/psql /usr/bin/

3、添加服务。
    3.1、按一定规则编写服务脚本。
    3.2、将编写的脚本放到/etc/init.d/,将其的访问权限加上可执行。
    3.3、增加服务 chkconfig --add myserviced
    3.4、启停服务 service ** start/stop
    3.5、chkconfig --del **

4、防火墙&&sshd
    4.1、关闭防火墙 iptables -F
    4.2、service sshd start
    4.3、netstat -nltp|grep 22
    4.4、防火墙配置文件 /etc/sysconfig/SuSEfirewall2
        4.4.1、在 FW_SERVICES_EXT_TCP或 FW_SERVICES_EXT_UDP后加入端口号，端口:端口 或者服务名称, 单个端口号之间空格隔开。
    4.5、OPENSUSE中没有/etc/rc.d/rc.local文件，有/etc/init.d/boot.local,自启动程序可以在这里配置。

