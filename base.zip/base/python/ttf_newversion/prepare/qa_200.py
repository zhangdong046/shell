#!/usr/bin/python
import ConfigParser  
import re
import os

def updateProcessConfigIni():
    config = ConfigParser.ConfigParser()
    config.readfp(open("./common/process_config.ini","rw"))   
    
    config.set("regular_mysql","host","10.48.16.43") 
    config.set("regular_mysql","user","map")
    config.set("regular_mysql","password","123")
    config.set("regular_mysql","db_name","lbs_data_process_200")
    config.set("regular_mysql","port","3311")
    
    config.set("task_manager_mysql","host","10.48.16.43") 
    config.set("task_manager_mysql","user","map")
    config.set("task_manager_mysql","password","123")
    config.set("task_manager_mysql","db_name","lbs_data_dms_sw")
    config.set("task_manager_mysql","port","3311")

    config.set("PGSQL","host","cp01-testing-mapse18.cp01.baidu.com")
    config.set("PGSQL","user","map")  
    config.set("PGSQL","db_name","dataprocess")
    config.set("PGSQL","port","5432")
    
    config.write(open("./common/process_config.ini", "w"))
    os.system("sed -i \"s/=/:/g\" ./common/process_config.ini")

def updateProcessWorkerConf():
    config = ConfigParser.ConfigParser()
    config.readfp(open("./sdworker/processworker.conf","rw"))    

    config.set("client","service","2")  
    config.set(".schedule","port","6001")  
    
    config.write(open("./sdworker/processworker.conf", 'w'))
    os.system("sed -i \"s/=/:/g\" ./sdworker/processworker.conf")

def updateScheduleIp():
    os.system("sed -i \"s/127.0.0.1/nj02-map-tushang00.nj02/g\" ./sdworker/schedule.ip")

def updateTtfConfigIni():
    config = ConfigParser.ConfigParser()
    config.readfp(open("./ttfmodel/ttf_config.ini","rw")) 

    config.set("MK_REF_ROAD_PGSQL","host","10.48.16.43")  
    config.set("MK_REF_ROAD_PGSQL","db_name","ttf_sw13aut_gd_all")   
    config.set("MK_REF_ROAD_PGSQL","user","map")  
    config.set("MK_REF_ROAD_PGSQL","port","9123")  

    config.set("ORIGIN_REF_ROAD_PGSQL","host","10.48.16.43") 
    config.set("ORIGIN_REF_ROAD_PGSQL","db_name","ttf_sw13aut_gd_all")      
    config.set("ORIGIN_REF_ROAD_PGSQL","user","map")  
    config.set("ORIGIN_REF_ROAD_PGSQL","port","9123") 

    config.write(open("./ttfmodel/ttf_config.ini", 'w'))
    os.system("sed -i \"s/=/:/g\" ./ttfmodel/ttf_config.ini")
    
updateProcessConfigIni()
updateProcessWorkerConf()
#updateScheduleIp()
updateTtfConfigIni()
