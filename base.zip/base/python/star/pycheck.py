#coding=UTF-8

import os
import sys
import re
import glob

class Files:
    def __init__(self):
        self.result={}
    
    def Pyscheck(self,dir_path):
        self.result["error_code"] = 1
        self.result["error_info"] = []
        
        if not os.path.exists(dir_path):
            self.result["error_info"].append("文件目录不存在")
            return self.result
        
        check_dir = dir_path
        
        if dir_path[-1] != '/':
            check_dir = dir_path+"/"

        py_files = glob.glob(check_dir+"*.py")
        pyc_files = glob.glob(check_dir+"*.pyc")
        py_file_count = len(py_files)
        pyc_file_count = len(pyc_files)

        if py_file_count != pyc_file_count:
            self.result["error_info"].append("py/pyc文件数量不一致")
            return self.result

        tmp_count = 0
        for f in py_files:
            py_file_name=f[:-1]+"yc"
            if py_file_name in pyc_files:
                tmp_count += 1
        if tmp_count != py_file_count:
            self.result["error_info"].append("py/pyc文件没有一一匹配")
            return self.result

if __name__ == "__main__":
    test=Files()
    length=len(sys.argv)
    if length <= 1 or length >2:
        sys.exit()
    dirs=sys.argv[1]
    test.Pyscheck(dirs)
    e_num = 0
    if test.result["error_code"] == 1:
        for info in test.result["error_info"]:
            e_num += 1
            print dirs+info
    if e_num > 0:
        print "check_status_fail!"
    else:
        print "check_status_sucess!"
