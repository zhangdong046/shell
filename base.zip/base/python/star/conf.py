#encoding:utf-8
import MySQLdb
import ConfigParser
import re
import os
from error import SQLError

class Conf:
    def __init__(self):
        file=open('./conf/conf.ini','r')
        i=0
        rec={}
        for line in file:
            lines=line.strip().split(':')
            length=len(lines)
            if length >1:
                tmp=lines[0].strip()
                rec[i]=line.replace(tmp,"").strip()
                rec[i]=rec[i].replace(":","").strip()
                i=i+1
        file.close()
        self.ini=rec

class TConf(Conf):
    def __init__(self):
        Conf.__init__(self)
        res={}
        res['server']={}
        res['test']={}
        res['server']['host']=self.ini[0]
        res['server']['user']=self.ini[1]
        res['server']['password']=self.ini[2]
        res['server']['dbname']=self.ini[3]
        res['server']['port']=self.ini[4]
        res['test']['host']=self.ini[5]
        res['test']['user']=self.ini[6]
        res['test']['password']=self.ini[7]
        res['test']['dbname']=self.ini[8]
        res['test']['port']=self.ini[9]
        self.res=res
        self.cons = MySQLdb.connect(host=self.res['server']['host'], port=int(self.res['server']['port']), user=self.res['server']['user'], passwd=self.res['server']['password'], db=self.res['server']['dbname'],charset="utf8")
        self.cont = MySQLdb.connect(host=self.res['test']['host'], port=int(self.res['test']['port']), user=self.res['test']['user'], passwd=self.res['test']['password'], db=self.res['test']['dbname'],charset="utf8")

    def __del__(self):
        self.res={}
        try:
            self.cons.close()
            self.cont.close()
        except Exception,e:
            raise SQLError,"conf.ini error!"
        else:
            print "connection closed!"

class Setconf:
    def __init__(self):
        config=ConfigParser.ConfigParser()
        config.readfp(open("./conf/conf.ini","rw"))
        config.set("regular_mysql","host","192.168.56.102")
        config.set("regular_mysql","user","root")
        config.set("regular_mysql","password","123")
        config.set("regular_mysql","db_name","work")
        config.set("regular_mysql","port","3306")
        config.set("task_manager_mysql","host","192.168.56.102")
        config.set("task_manager_mysql","user","root")
        config.set("task_manager_mysql","password","123")
        config.set("task_manager_mysql","db_name","result")
        config.set("task_manager_mysql","port","3306")
        config.write(open("./conf/conf.ini","w"))
        os.system("sed -i \"s/=/:/g\" ./conf/conf.ini")

    def Read(self):
        config = ConfigParser.ConfigParser()
        config.readfp(open(raw_input("Input file name : "),"rb"))
        print config.get("regular_mysql","host")


if __name__ == "__main__":
    test=Setconf()
    test.Read()
    obj2=TConf()
    test2=obj2.res
    cur1=obj2.cons.cursor()
    cur2=obj2.cont.cursor()
    cur1.close()
    cur2.close()
    print test2
