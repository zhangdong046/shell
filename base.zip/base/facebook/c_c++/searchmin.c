//有一个循环有序数组，，不知道其最小值的位置，如何从这样的数组中寻找一个特定的元素。
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int search(int a[],int lower,int u,int x){//u为最后一个元素的下标，x为所要查找的值
    while(lower<=u){
        int m=(lower+u)/2;
        if(x == a[m]){return m;}
        else
            if(a[lower]<=a[m]){
                if(x>a[m]) lower=m+1;
                else
                    if(x>=a[lower]) u=m-1;
                    else lower=m+1;
            }else
            {
                if(x<a[m]) u=m-1;
                else
                if(x<=a[u]) lower=m+1;
                else u=m-1;
            }
    }
    return -1;
}
int Binary_Search(int* L,int len,int key){
    int low=0,high=len-1,mid;
    while(low<=high){
        mid=(low+high)/2;
        if(L[mid]==key)
            return mid;
        else if(L[mid]>key)
            high=mid-1;
        else
            low=mid+1;
    }
    return -1;
}
//描述折半查找过程的判定树，n个圆形结点（代表有序序列的n个元素）构成的树的深度与n个结点的完全二叉树的深度（高度）相等。
/*
1、查找成功的ASL与查找不成功的ASL。
*/
int main(){
    int A[10] = {7,8,9,0,1,2,3,4,5,6};
    int num1 = search(A,0,9,5);
    int num2 = Binary_Search(A,10,6);
    printf("%d\n%d\n",num1,num2);
    return 0;
}
