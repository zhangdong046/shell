#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<limits>//!!!
using namespace std;
enum Status{kValid = 0,kInvalid};//枚举自动+1
int g_nStatus = kValid;
int StrToInt(const char* str){
    g_nStatus = kInvalid;
    long long num = 0;
    if(str != NULL){
        const char* digit = str;
        bool minus =false;
        if(*digit == '+')
            digit++;//首先，你腾讯面试写的代码没有符号判断。
        else if(*digit == '-'){
            digit++;
            minus = true;
        }
        while(*digit!='\0'){
            if(*digit>='0'&&*digit<='9'){//这么重要的一个判断，你面试时候都把它给漏掉了。。。真的该死，面试失败只能怪自己，这种低级错误都犯。
                num=num*10+(*digit-'0');//腾讯面试时候，你这里是不是写反了，唉，为什么这么简单的代码，一到面试场都成了这个样子，我已经无力吐槽了。
                if(num>std::numeric_limits<int>::max())//溢出判断，腾讯面试时候，我不会写这个地方，ma de fucker!!!
                {
                    num=0;
                    break;
                }
                digit++;
            }else{
                num=0;
                break;
            }
        }
        if(*digit == '\0'){//
            g_nStatus = kValid;
            if(minus)
                num=0-num;
        }
    }
//这里最初声明的num是long long型，然后可以使用int的溢出判断，然后再把不溢出的num类型转换回int型！！！！！！！！！！！！！！！！！！！！！
    return static_cast<int>(num);//static_cast<int>(num)转换
}
int main(){
    const char* str1="0123";
    int num = StrToInt(str1);
    cout<<num<<endl;
    return 0;
}
