//深信服笔试，第一道代码题犯了低级错误，求字符串中单词个数，我是按照字母后面非字母统计的，但是这种方法漏掉了字符串末尾是字符的情况。
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<assert.h>
using namespace std;

int multiply(const char* a,const char* b){
    assert(a!=NULL&&b!=NULL);
    int i,j,ca,cb,*s;
    ca = strlen(a);
    cb = strlen(b);
    s=(int*)malloc(sizeof(int)*(ca+cb));//ca+cb!!99*99=9801
    for(i=0;i<ca+cb;i++)
        s[i]=0;//每个元素赋初值0
    for(i=0;i<ca;i++)
        for(j=0;j<cb;j++)
            if('0'<=a[i]<='9'&&'0'<=b[j]<='9'){
                s[i+j+1]+=(a[i]-'0')*(b[j]-'0');//i+j+1!!!!!s[0]用来存放最高的进位
            }else{
                return 1;
            }
    for(i=ca+cb-1;i>=0;i--)//ca+cb-1!!!ca+cb-1~0
        if(s[i]>=10){
            s[i-1]+=s[i]/10;
            s[i]%=10;//s[0]为初始的0.
        }
    char* c=(char*)malloc((ca+cb)*sizeof(char));
    i=0;
    while(s[i]==0) i++;
    for(j=0;i<ca+cb;i++,j++)
        c[j]=s[i]+'0';
    c[j]='\0';
    for(i=0;i<ca+cb;i++)
        cout<<c[i];
    cout<<endl;
    free(s);
    free(c);
   return 0;
}
int main(){
    const char* a="2536456457";
    const char* b="013124330";
    multiply(a,b);
    return 0;
}
