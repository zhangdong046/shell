<?php
include './database.php';
class Data_Process extends MySQLDB {
    
    public $port = "3306";
    public $starttime;
    public $endtime;
    public $spendtime;
    public $querycount;
    
    function __construct($host,$user,$password,$database){
        parent::__construct($host,$user,$password,$database);
        $this->starttime = $this->Getmicrotime();
    }
   
    function __destruct(){
        exit();
    }

    public function Close(){
        $this->stoptime = $this->Getmicrotime();
        MySQLDB::Close();
    }

    public function Query($queryStr){
        $res = MySQLDB::Query($queryStr);
        $this->querycount = $this->querycount + 1;
        return $res;
    }

    public function GetRows($res){
        $rows = MySQLDB::GetRows($res);
        return $rows;
    }
    
    public function Getmicrotime(){
        $times = explode(" ",microtime());
        return ((float)$times[0] + (float)$times[1]);
    } 

    public function Start(){
        $this->starttime = $this->Getmicrotime();
    }
    
    public function Display(){
        $this->endtime = $this->Getmicrotime();
        $this->speedtime = $this->endtime - $this->starttime;
        return round($this->spendtime,10);
    }
    
    public function Getquerynum(){
        return $this->querycount;
    }
    
    public function Begin(){
        mysql_query('begin');
    }
    
    public function Commit(){
        mysql_query('commit');
    }
    
    public function Rollback(){
        mysql_query('rollback');
    }

    public function Load($table, $id, $field='id'){
        $sql = "select * from `{$table}` where `{$field}`='{$id}'";
        $row = $this->get($sql);
        return $row;
    }

    public function Save($table, &$row){
        $sqlA = '';
        foreach($row as $k=>$v){
            $sqlA .= "`$k` = '$v',";
        }

        $sqlA = substr($sqlA, 0, strlen($sqlA)-1);
        $sql  = "insert into `{$table}` set $sqlA";
        $this->query($sql);
        if(is_object($row)){
            $row->id = $this->last_insert_id();
        }else if(is_array($row)){
            $row['id'] = $this->last_insert_id();
        }
    }

    public function Remove($table, $id, $field='id'){
        $sql  = "delete from `{$table}` where `{$field}`='{$id}'";
        return $this->query($sql);
    }
    
    public function Escape(&$val){
        if(is_object($val) || is_array($val)){
            $this->escape_row($val);
        }
    }

    public function Escape_row(&$row){
        if(is_object($row)){
            foreach($row as $k=>$v){
                $row->$k = mysql_real_escape_string($v);
            }
        }else if(is_array($row)){
            foreach($row as $k=>$v){
                $row[$k] = mysql_real_escape_string($v);
            }
        }
    }

    public function Escape_like_string($str){
        $find = array('%', '_');
        $replace = array('\%', '\_');
        $str = str_replace($find, $replace, $str);
        return $str;
    }
}

function Test($host,$user,$passwd,$dbname){
    
    $SqlDB = new Data_Process($host,$user,$passwd,$dbname);
    $sql = "select rule_id,obj from rule_check_all where category = 'ROAD' and obj like \"WITH%\" limit 10;";
    $result = $SqlDB->Query($sql);
    $rs=$SqlDB->GetRows($result);
    $num = $SqlDB->GetRowsNum($result);
    $name = $SqlDB->GetFields($result);
    $namenum = $SqlDB->GetFieldsNum($result);
    for($i = 0;$i < $num;$i++){
        echo($rs[$i]["rule_id"])."\n".($rs[$i]["obj"])."\n";
    }

    $count = $SqlDB->Getquerynum();
    printf("查询次数：%d\n",$count);
    $SqlDB->Close();
    $ttime = $SqlDB->Display();
    printf("查询耗时：%f\n",$ttime);
}
 
Test("127.0.0.1","root","123","work");
?>
