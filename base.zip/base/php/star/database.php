<?php
class MySQLDB 
{ 
    var $host; 
    var $user; 
    var $passwd; 
    var $database;
    var $conn; 

    public function __construct($host,$user,$password,$database){ 
        $this->host = $host; 
        $this->user = $user; 
        $this->passwd = $password; 
        $this->database = $database; 
        $this->conn=mysql_connect($this->host, $this->user,$this->passwd) or die("Could not connect to $this->host"); 
        mysql_select_db($this->database,$this->conn) or die("Could not switch to database $this->database"); 
        mysql_query("set names 'gbk'");
    } 

    public function Close(){ 
        MySQL_close($this->conn); 
    }

    public function Query($queryStr){   
        $res =Mysql_query($queryStr, $this->conn) or die("Could not query database");//die(status)函数输出一条消息，并退出当前脚本，该函数是exit()函数的别名。
        return $res; 
    }

    public function GetRows($res){ 
        $rowno = 0; 
        $rowno = MySQL_num_rows($res);
        if($rowno>0) 
        { 
            for($row=0;$row<$rowno;$row++ ) 
            { 
                $rows[$row]=MySQL_fetch_array($res);
            } 
            return $rows; 
        } 
    }

    public function GetRowsNum($res){ 
        $rowno = 0; 
        $rowno = mysql_num_rows($res); 
        return $rowno;
    }

    public function GetFieldsNum($res)
    {
        $fieldno = 0;
        $fieldno = mysql_num_fields($res);
        return $fieldno;
    }

    public function GetFields($res){
        $fno = $this->getFieldsNum($res);
        if($fno>0) 
        { 
            for($i=0;$i<$fno;$i++ ) 
            { 
                $fs[$i]=MySQL_field_name($res,$i);
            } 
            return $fs;
        } 
    } 
}
?>
