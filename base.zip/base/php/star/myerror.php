<?php
class MyException extends Exception{
    public function __construct($message,$code = 0){
        parent::__construct($message,$code);
    }

    public function __toString(){
        return __CLASS__.':['.$this->code.']:'.$this->message."\n";
    }
    
    public function ErrorFunction(){
        throw new Exception($message,$level);
    }
    
    public function ExceptionFunction($exception){
        ptint_r($exception->getTrace());
        echo 'Catch an Exception:'.$exception->getMessage();
    }
    
    public function ClassLoader($classname){
        if(!class_exists($classname)){
            $class_file = str_replace('_', DIRECTORY_SEPARATOR, $class_name).'.class.php';
            if(is_file($class_file)){
                require_once($class_file);
            }else{
                throw new Exception('Class Not Fond.');
            }
        }
    }
    
    public function ErrorMessage(){
        $errorMsg = $this->getMessage()."\n";
        return $errorMsg;
    }
}
/*trigger_error(error_message,error_types)
第2个参数可选规定错误消息的错误类型：
•E_USER_ERROR
•E_USER_WARNING
•E_USER_NOTICE
set_error_handler(error_function,error_types)
函数设置用户自定义的错误处理函数。
第2参数可选。规定在哪个错误报告级别会显示用户定义的错误。默认是 "E_ALL"。
*/
function CustomError($errno,$errstr,$errfile,$errline){
    echo "My Second Error:[".$errno."]".$errstr."\n";
    echo "Error on line $errline in $errfile\n";
    die("Ending Script\n");
}
function conn()
{
    try
    {
        try
        {
            throw new Exception('Test error!');//$conn = mysql_connect('127.0.0.1', 'root', '123456a');
        }catch(Exception $e) // 捕获异常
        {
            throw new MyException('My First Error!',1); // 抛出自定义异常
        }
    }catch(MyException $e)
    {
        echo strpos("Hello world!","wo","6")."\n";
        echo $e->ErrorMessage();
    }
}

conn(); // 调用
set_error_handler("CustomError");
trigger_error("A custom error has been triggered");
?>
