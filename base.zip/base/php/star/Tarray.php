<?php
class Tarray{
    private $cars;
    private $age;
    private $staff;
    var $speed;
    
    public function __construct(){
        $temp = range(0,220,20);
        $this->speed = $temp;
        $this->cars = array("Volvo","BMW","SAAB");
        $this->age = array("Bill"=>"35","Steve"=>"25","Peter"=>"15");
        $this->staff = array(
                              array("姓名","性别","年龄"),
                              array("小张","男",24),
                              array("小王","女",25),
                              array("小李","男",23)
                            );
    }

    public function Example1(){//索引数组
        $arrlength = count($this->cars);
        for($i = 0;$i<$arrlength;$i++){
            echo $this->cars[$i];
            echo "\n";
        }
        foreach($this->cars as $value){
            echo $value." ";
        }
        return $arrlength;
    }
    
    public function Example2(){//关联数组
        foreach($this->age as $index=>$atom){
            echo "Key=".$index.",Value=".$atom;
            printf("\n");
        }
    }

    public function Example3(){//多维索引数组
        while(list($key,$value) = each($this->staff)){//list(var1,var2...)函数用数组中的元素为一组变量赋值
            list($name,$sex,$age) = $value;
            echo "$name $sex $age\n";
        }
    }

    public function Example4(){//数组的指针操作
        echo current($this->speed);//输出当前位置的值（数组开头）
        $i = rand(1,11);
        while($i--){
            next($this->speed);//指针从当前位置后移一位
        }
        echo current($this->speed);
        echo prev($this->speed);//输出前一位置数组值
        echo reset($this->speed);//重置数组的指针，将指针指向起始位置
        echo end($this->speed);//输出最后位置的数组值
        $speeds = range(0,200,40);//each实现指针下移
        echo "0档的速度是".current(each($speeds))."\n";
        echo "1档的速度是".current(each($speeds))."\n";
        reset($speeds);
        while(list($key,$value)=each($speeds)){
            echo $key."=>".$value."\n";
        }
        
    }
    
    public function Example5(){
        $num = array(0=>80,1=>120,3=>160);
        $num = array_pad($num,4,200);//尾部添加成员
        print_r($num);
        $num = array_pad($num,-8,40);//首部填充4个40
        print_r($num);
        array_push($num,220,240,260);//入栈追加，直接加在数组结尾
        print_r($num);
        unset($num[4]);//unset()命令删除数组成员或数组
        unset($num);
    }
/*array_unshift()在开头添加数组成员,函数使用后数组的键值将会从0开始!
array_splice()函数删除数组成员
array_unique删除数组中的重复值
array_merge、array_merge_recursive合并数组：$result = array_merge_recursive($array1,$array2,$array3,$array4,$array5); 
in_array()检测数组中是否有某个值存在：if(in_array(9,$array)){}
key()取得数组当前的键名:$key = key($array);
array_flip()交换数组的键值和值: 
array_search()搜索数值: $result = array_search("red",$array); 未找到返回NULL.
sort()、rsort()/asort()、arsort()对数组排序
*/
}
$test = new Tarray();
$test->Example1();
$test->Example2();
$test->Example3();
$test->Example4();
$test->Example5();

?>
