<?php
class Files{
    
    private $now_dir = '';

    public function __construct($dir_path){
        $dir_cut = substr($dir_path,-1);
        if ($dir_cut == '/'){
            $length = strlen($dir_path);
            $dir_cuts = substr($dir_path,-2,1);
            if ($dir_cuts != '/'){
                $dir_cuts = substr($dir_path,0,-1);
                //$dir_cuts = substr($dir_path,0,$length-1);
                //该函数的第2、3个参数的意思是从第一元素（0）起截取len-1个元素。
            }
            else{
                throw new Exception("Dir_path error!");
            }
        }
        $this->now_dir = $dir_cuts;
    }

    public function Delete_path_file($paths){
        $d = dir($paths);
        while (false !== ($file = $d->read())){//===严格比较
            if($file != '.'&& $file != '..'){
                $file_path = $paths.'/'.$file;
                if(is_dir($file_path)){
                    $this->Delete_path_file($file_path);
                    @rmdir($file_path);
                }else{
                    unlink($file_path);
                }
            }
        }
        $d->close();
    }

    public function Begin_exe(){
        $this->now_dir = $this->now_dir.'/tmp.txt';
        if(file_exists($this->now_dir)){
            $this->Exe_msg('It Being executed!');
        }else{
            $fp = fopen($this->now_dir,"w");
            if(!$fp){
                echo '文件不存在,创建之!';
            }
            fwrite($fp,"测试内容!");
            echo '测试文件大小:'.filesize($this->now_dir)."\n";
            fclose($fp);
            $this->Exe_msg('begin executed!');
        }
    }
 
    public function Exe_msg($msg){
        $count = 0;
        $msg = trim($msg);
        str_replace('哈','ha',$msg,$count);
        printf("共替换%d次：\n",$count);
        $msg = substr_replace($msg,"he",2);
        print_r(str_split($msg));
    }

    public function Exit_exe($msg){
        @$fp = fopen($this->now_dir,'r');//@符号表示php将抑制所有由当前函数调用产生的错误
        if(!$fp){
            echo '文件不存在!';
            exit();
        }
        while(!feof($fp)){
            $atom = fgets($fp);
            echo $atom."\n";
        }
        fclose($fp);
        $all = readfile($this->now_dir);
        echo $all;
        unlink($this->now_dir);
        $this->Exe_msg($msg);
        $this->Exe_msg('exit!');
        exit();
    }
}
 
function Test($now_dir,$paths,$msg){
    $tmp = new Files($now_dir);
    $tmp->Delete_path_file($paths);
    $tmp->Begin_exe();
    $tmp->Exit_exe($msg);
}

Test('./test/','/home/test_149/php/star/test/test1',' 哈哈! ');
?>
